package com.personal.watchtranslate.ai

import com.personal.watchtranslate.audio.AudioCaptureService
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import okhttp3.*
import okio.ByteString.Companion.toByteString
import org.json.JSONObject

data class RecognizedSpeechSegment(
    val text: String,
    val startOffsetMs: Long,
    val endOffsetMs: Long,
    val isFinal: Boolean,
    val detectedLanguage: String?,
    val speakerId: Int?
)

class DeepgramStreamingSttEngine(
    private val httpClient: OkHttpClient = OkHttpClient()
) {
    private var webSocket: WebSocket? = null
    private var streamStartEpochMs: Long = 0L

    private val _segments = MutableSharedFlow<RecognizedSpeechSegment>(extraBufferCapacity = 64)
    val segments = _segments.asSharedFlow()

    private val _errors = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val errors = _errors.asSharedFlow()

    fun start(apiKey: String) {
        stop()
        streamStartEpochMs = System.currentTimeMillis()
        val url = "wss://api.deepgram.com/v1/listen" +
            "?model=nova-2" +
            "&encoding=linear16" +
            "&sample_rate=${AudioCaptureService.SAMPLE_RATE}" +
            "&channels=1" +
            "&punctuate=true" +
            "&smart_format=true" +
            "&diarize=true" +
            "&detect_language=true" +
            "&interim_results=true" +
            "&endpointing=350"

        val request = Request.Builder()
            .url(url)
            .addHeader("Authorization", "Token $apiKey")
            .build()

        webSocket = httpClient.newWebSocket(request, object : WebSocketListener() {
            override fun onMessage(webSocket: WebSocket, text: String) {
                parseDeepgramMessage(text)
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                _errors.tryEmit(t.localizedMessage ?: "STT WebSocket disconnected")
            }
        })
    }

    fun sendPcmChunk(pcm16Bytes: ByteArray) {
        webSocket?.send(pcm16Bytes.toByteString(0, pcm16Bytes.size))
    }

    fun getStreamStartEpochMs(): Long = streamStartEpochMs

    fun stop() {
        runCatching { webSocket?.close(1000, "Session ended") }
        webSocket = null
    }

    private fun parseDeepgramMessage(rawJson: String) {
        runCatching {
            val root = JSONObject(rawJson)
            if (root.optString("type") != "Results") return
            val isFinal = root.optBoolean("is_final", false)
            val channel = root.optJSONObject("channel") ?: return
            val alternatives = channel.optJSONArray("alternatives") ?: return
            if (alternatives.length() == 0) return

            val alt = alternatives.getJSONObject(0)
            val transcript = alt.optString("transcript", "").trim()
            if (transcript.isEmpty()) return

            val words = alt.optJSONArray("words")
            val startSec: Double
            val endSec: Double
            var speaker: Int? = null

            if (words != null && words.length() > 0) {
                val first = words.getJSONObject(0)
                val last = words.getJSONObject(words.length() - 1)
                startSec = first.optDouble("start", root.optDouble("start", 0.0))
                endSec = last.optDouble("end", startSec + root.optDouble("duration", 1.8))
                if (first.has("speaker")) speaker = first.optInt("speaker")
            } else {
                startSec = root.optDouble("start", 0.0)
                endSec = startSec + root.optDouble("duration", 1.8)
            }

            val lang = channel.optJSONArray("detected_language")?.optString(0)?.ifBlank { null }
                ?: channel.optString("detected_language", "").ifBlank { null }

            _segments.tryEmit(
                RecognizedSpeechSegment(
                    text = transcript,
                    startOffsetMs = (startSec * 1000).toLong(),
                    endOffsetMs = (endSec * 1000).toLong(),
                    isFinal = isFinal,
                    detectedLanguage = lang,
                    speakerId = speaker
                )
            )
        }
    }
}
