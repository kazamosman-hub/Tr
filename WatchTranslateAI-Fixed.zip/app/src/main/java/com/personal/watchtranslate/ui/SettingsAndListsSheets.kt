package com.personal.watchtranslate.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.personal.watchtranslate.data.local.LlmProvider
import com.personal.watchtranslate.data.model.BrowserTab
import com.personal.watchtranslate.data.model.TranslationMode
import com.personal.watchtranslate.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun SettingsDialog(
    viewModel: MainViewModel,
    currentMode: TranslationMode,
    adBlockerEnabled: Boolean,
    onDismiss: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var provider by remember { mutableStateOf(viewModel.keyStore.llmProvider) }
    var geminiKey by remember { mutableStateOf(viewModel.keyStore.geminiApiKey) }
    var openAiKey by remember { mutableStateOf(viewModel.keyStore.openAiApiKey) }
    var deepgramKey by remember { mutableStateOf(viewModel.keyStore.deepgramApiKey) }
    var customBlockDomain by remember { mutableStateOf("") }
    var statusMessage by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = CharcoalSurface,
        title = { Text("Settings & API Configuration") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("AI Translation Provider", fontSize = 12.sp, color = MutedSlate)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    LlmProvider.entries.forEach { p ->
                        FilterChip(selected = provider == p, onClick = { provider = p }, label = { Text(p.name) })
                    }
                }

                OutlinedTextField(
                    value = geminiKey,
                    onValueChange = { geminiKey = it },
                    label = { Text("Gemini API Key") },
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true
                )
                OutlinedTextField(
                    value = openAiKey,
                    onValueChange = { openAiKey = it },
                    label = { Text("OpenAI API Key (Optional)") },
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true
                )
                OutlinedTextField(
                    value = deepgramKey,
                    onValueChange = { deepgramKey = it },
                    label = { Text("Deepgram API Key (For Live Audio)") },
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true
                )

                Text("Translation Mode", fontSize = 12.sp, color = MutedSlate)
                TranslationMode.entries.forEach { mode ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = currentMode == mode, onClick = { viewModel.setTranslationMode(mode) })
                        Text(mode.label, fontSize = 13.sp)
                    }
                }

                HorizontalDivider()
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Ad Blocker Enabled")
                    Switch(checked = adBlockerEnabled, onCheckedChange = { viewModel.adBlocker.setEnabled(it) })
                }

                OutlinedTextField(
                    value = customBlockDomain,
                    onValueChange = { customBlockDomain = it },
                    label = { Text("Block Custom Domain (e.g., ads.site.com)") },
                    singleLine = true
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        viewModel.adBlocker.addCustomBlockedDomain(customBlockDomain)
                        customBlockDomain = ""
                        statusMessage = "Custom domain added."
                    }) { Text("Add Rule") }

                    OutlinedButton(onClick = {
                        scope.launch {
                            statusMessage = "Updating blocklist..."
                            val res = viewModel.adBlocker.updateBlocklistFromUrl()
                            statusMessage = res.fold(
                                onSuccess = { "Added $it domains." },
                                onFailure = { "Update failed: ${it.message}" }
                            )
                        }
                    }) { Text("Update Lists") }
                }

                TextButton(onClick = {
                    viewModel.clearAllBrowsingData()
                    statusMessage = "Local history & cache cleared."
                }) { Text("Clear Browsing Data & Cache", color = AlertAmber) }

                if (statusMessage.isNotBlank()) {
                    Text(statusMessage, color = SuccessGreen, fontSize = 12.sp)
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                viewModel.saveApiSettings(provider, geminiKey, openAiKey, deepgramKey)
                onDismiss()
            }) { Text("Save") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun TabsDialog(
    tabs: List<BrowserTab>,
    onSelect: (Int) -> Unit,
    onClose: (Int) -> Unit,
    onNewTab: (Boolean) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = CharcoalSurface,
        title = { Text("Tabs (${tabs.size})") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { onNewTab(false) }) { Text("+ New Tab") }
                    OutlinedButton(onClick = { onNewTab(true) }) { Text("+ Private") }
                }
                LazyColumn(modifier = Modifier.heightIn(max = 260.dp)) {
                    items(tabs.indices.toList()) { idx ->
                        val tab = tabs[idx]
                        Row(
                            modifier = Modifier.fillMaxWidth().clickable { onSelect(idx) }.padding(vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                (if (tab.isPrivate) "[Private] " else "") + tab.title,
                                maxLines = 1,
                                modifier = Modifier.weight(1f)
                            )
                            TextButton(onClick = { onClose(idx) }) { Text("Close") }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Done") } }
    )
}

@Composable
fun SimpleListDialog(
    title: String,
    items: List<Pair<String, String>>,
    onItemClick: (String) -> Unit,
    onClear: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = CharcoalSurface,
        title = { Text(title) },
        text = {
            if (items.isEmpty()) {
                Text("Nothing recorded yet.", color = MutedSlate)
            } else {
                LazyColumn(modifier = Modifier.heightIn(max = 320.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(items) { (label, url) ->
                        Column(modifier = Modifier.fillMaxWidth().clickable { onItemClick(url) }.padding(vertical = 4.dp)) {
                            Text(label, fontSize = 13.sp, color = SoftWhite)
                            Text(url, fontSize = 11.sp, color = MutedSlate, maxLines = 1)
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } },
        dismissButton = { TextButton(onClick = onClear) { Text("Clear All", color = AlertAmber) } }
    )
}
