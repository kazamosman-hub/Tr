package com.personal.watchtranslate.ai

import com.personal.watchtranslate.data.local.BrowserDao
import com.personal.watchtranslate.data.local.LlmProvider
import com.personal.watchtranslate.data.local.SecureKeyStore
import com.personal.watchtranslate.data.model.SubtitleExplanation
import com.personal.watchtranslate.data.model.TranslationCacheEntity
import com.personal.watchtranslate.data.model.TranslationStyle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.util.concurrent.TimeUnit

class TranslationEngine(
    private val keyStore: SecureKeyStore,
    private val dao: BrowserDao,
    val contextManager: DialogueContextManager
) {
    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    suspend fun translateLine(
        text: String,
        style: TranslationStyle,
        speakerLabel: String? = null
    ): Result<String> = withContext(Dispatchers.IO) {
        val clean = text.trim()
        if (clean.isEmpty()) return@withContext Result.success("")

        val cacheKey = hashKey("$clean|${style.name}")
        dao.getCachedTranslation(cacheKey)?.let { cached ->
            contextManager.record(clean, cached.translatedText, speakerLabel)
            return@withContext Result.success(cached.translatedText)
        }

        val systemPrompt = buildSystemPrompt(style)
        val userPrompt = buildString {
            append(contextManager.buildContextPromptBlock())
            append("\nTranslate ONLY the following movie/series subtitle line into ")
            append(style.displayName)
            append(". Return ONLY the final subtitle text (max 2 short lines, no quotes, no explanations):\n")
            if (speakerLabel != null) append("[$speakerLabel] ")
            append(clean)
        }

        callLlm(systemPrompt, userPrompt, jsonMode = false).map { translated ->
            val finalSub = translated.trim().removeSurrounding("\"")
            dao.saveCachedTranslation(
                TranslationCacheEntity(
                    cacheKey = cacheKey,
                    sourceText = clean,
                    translatedText = finalSub,
                    style = style.name
                )
            )
            contextManager.record(clean, finalSub, speakerLabel)
            finalSub
        }
    }

    suspend fun translateBatch(
        lines: List<String>,
        style: TranslationStyle
    ): Result<List<String>> = withContext(Dispatchers.IO) {
        if (lines.isEmpty()) return@withContext Result.success(emptyList())

        val results = MutableList<String?>(lines.size) { null }
        val missingIndices = mutableListOf<Int>()

        lines.forEachIndexed { idx, line ->
            val cached = dao.getCachedTranslation(hashKey("${line.trim()}|${style.name}"))
            if (cached != null) results[idx] = cached.translatedText
            else missingIndices.add(idx)
        }

        if (missingIndices.isEmpty()) {
            return@withContext Result.success(results.map { it.orEmpty() })
        }

        val payloadArray = JSONArray()
        missingIndices.forEach { idx ->
            payloadArray.put(JSONObject().put("i", idx).put("t", lines[idx]))
        }

        val systemPrompt = buildSystemPrompt(style)
        val userPrompt = """
            ${contextManager.buildContextPromptBlock()}
            Translate each movie subtitle item in this JSON array into ${style.displayName}.
            Keep translations natural, emotionally accurate, concise for on-screen reading, and consistent across lines.
            Return ONLY valid JSON: {"items":[{"i":0,"tr":"..."}]}
            Input: $payloadArray
        """.trimIndent()

        callLlm(systemPrompt, userPrompt, jsonMode = true).map { raw ->
            val parsed = JSONObject(extractJsonObject(raw)).getJSONArray("items")
            for (k in 0 until parsed.length()) {
                val item = parsed.getJSONObject(k)
                val idx = item.getInt("i")
                val tr = item.getString("tr").trim()
                if (idx in results.indices) {
                    results[idx] = tr
                    dao.saveCachedTranslation(
                        TranslationCacheEntity(
                            cacheKey = hashKey("${lines[idx].trim()}|${style.name}"),
                            sourceText = lines[idx].trim(),
                            translatedText = tr,
                            style = style.name
                        )
                    )
                    contextManager.record(lines[idx], tr)
                }
            }
            results.mapIndexed { idx, value -> value ?: lines[idx] }
        }
    }

    suspend fun explainSubtitle(
        sourceText: String,
        translatedText: String
    ): Result<SubtitleExplanation> = withContext(Dispatchers.IO) {
        val systemPrompt = "You are a bilingual cinema language coach fluent in English, Egyptian Arabic, and Modern Standard Arabic."
        val userPrompt = """
            ${contextManager.buildContextPromptBlock()}
            Analyze this movie dialogue line for an Arabic-speaking viewer:
            Original: "$sourceText"
            Subtitle shown: "$translatedText"

            Return ONLY valid JSON with these exact keys:
            {
              "meaningInContext": "Brief clear explanation in Arabic of what the character actually means here",
              "slangOrIdiomNotes": "Explain any slang, idiom, sarcasm, or cultural reference in Arabic (or 'لا توجد مصطلحات عامية معقدة')",
              "egyptianVersion": "How an Egyptian would naturally say this exact line",
              "alternatives": ["Natural alternative 1", "Natural alternative 2"],
              "pronunciationGuide": "Simple phonetic pronunciation guide of the original line"
            }
        """.trimIndent()

        callLlm(systemPrompt, userPrompt, jsonMode = true).map { raw ->
            val obj = JSONObject(extractJsonObject(raw))
            val altsJson = obj.optJSONArray("alternatives") ?: JSONArray()
            val alts = (0 until altsJson.length()).map { altsJson.getString(it) }
            SubtitleExplanation(
                original = sourceText,
                translation = translatedText,
                meaningInContext = obj.optString("meaningInContext"),
                slangOrIdiomNotes = obj.optString("slangOrIdiomNotes"),
                egyptianVersion = obj.optString("egyptianVersion"),
                alternatives = alts,
                pronunciationGuide = obj.optString("pronunciationGuide")
            )
        }
    }

    private fun buildSystemPrompt(style: TranslationStyle): String {
        val styleDirective = when (style) {
            TranslationStyle.EGYPTIAN_ARABIC ->
                "Translate into authentic, natural modern Egyptian Arabic (العامية المصرية الطبيعية) as spoken in Cairo cinema—capture idioms, sarcasm, humor, and emotional tone natively. Never translate idioms literally."
            TranslationStyle.MSA ->
                "Translate into crisp, cinematic Modern Standard Arabic (العربية الفصحى الحديثة السينمائية) used by top subtitle studios—smooth, expressive, never stiff or robotic."
            TranslationStyle.NATURAL_ARABIC ->
                "Translate into natural, effortless modern Arabic understood across the Arab world—concise, conversational, emotionally accurate."
            TranslationStyle.ENGLISH ->
                "Translate into natural, idiomatic cinematic English subtitles."
        }
        return """
            You are an elite film and TV subtitle translator.
            $styleDirective
            Strict subtitle rules:
            1. Keep subtitles concise and fast to read (ideally under 42 characters per line, max 2 lines).
            2. Match speaker gender/pronouns and keep character names consistent using provided context.
            3. Preserve humor, sarcasm, slang, and emotional weight instead of literal word-for-word rendering.
            4. Never invent dialogue that wasn't spoken. Never add notes, brackets, or translator commentary.
        """.trimIndent()
    }

    private fun callLlm(systemPrompt: String, userPrompt: String, jsonMode: Boolean): Result<String> {
        return runCatching {
            when (keyStore.llmProvider) {
                LlmProvider.GEMINI -> callGemini(systemPrompt, userPrompt, jsonMode)
                LlmProvider.OPENAI -> callOpenAi(systemPrompt, userPrompt, jsonMode)
            }
        }
    }

    @Volatile private var cachedGeminiModel: String? = null

    private fun discoverWorkingGeminiModel(apiKey: String): String {
        val url = "https://generativelanguage.googleapis.com/v1beta/models?key=$apiKey"
        val req = Request.Builder().url(url).build()
        httpClient.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) error("Gemini models list HTTP ${resp.code}")
            val models = JSONObject(resp.body?.string().orEmpty()).optJSONArray("models") ?: JSONArray()
            val candidates = mutableListOf<String>()
            for (i in 0 until models.length()) {
                val m = models.getJSONObject(i)
                val name = m.optString("name").removePrefix("models/")
                val methods = m.optJSONArray("supportedGenerationMethods")?.toString().orEmpty()
                if (methods.contains("generateContent") && name.contains("gemini", ignoreCase = true)) {
                    candidates.add(name)
                }
            }
            return candidates.firstOrNull { it.contains("flash", ignoreCase = true) && !it.contains("exp") }
                ?: candidates.firstOrNull { it.contains("flash", ignoreCase = true) }
                ?: candidates.firstOrNull()
                ?: error("No Gemini generateContent model available for this API key")
        }
    }

    private fun callGemini(systemPrompt: String, userPrompt: String, jsonMode: Boolean): String {
        val apiKey = keyStore.geminiApiKey.trim()
        require(apiKey.isNotBlank()) { "Gemini API key not configured" }

        val genConfig = JSONObject().put("temperature", 0.3)
        if (jsonMode) genConfig.put("responseMimeType", "application/json")

        val bodyJson = JSONObject()
            .put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemPrompt))))
            .put("contents", JSONArray().put(
                JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", userPrompt)))
            ))
            .put("generationConfig", genConfig)
            .toString()

        val modelsToTry = buildList {
            cachedGeminiModel?.let { add(it) }
            add("gemini-2.5-flash")
            add("gemini-2.0-flash")
            add("gemini-flash-latest")
        }.distinct()

        var lastError = ""
        for (model in modelsToTry) {
            val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey"
            val request = Request.Builder()
                .url(url)
                .post(bodyJson.toRequestBody(jsonMediaType))
                .build()

            httpClient.newCall(request).execute().use { resp ->
                val body = resp.body?.string().orEmpty()
                if (resp.isSuccessful) {
                    cachedGeminiModel = model
                    val json = JSONObject(body)
                    return json.getJSONArray("candidates")
                        .getJSONObject(0)
                        .getJSONObject("content")
                        .getJSONArray("parts")
                        .getJSONObject(0)
                        .getString("text")
                }
                lastError = "Gemini ($model) HTTP ${resp.code}"
                if (resp.code != 404) error("$lastError: $body")
            }
        }

        // All hardcoded names returned 404 -> dynamically discover an active model from user's account
        val discovered = discoverWorkingGeminiModel(apiKey)
        val fallbackUrl = "https://generativelanguage.googleapis.com/v1beta/models/$discovered:generateContent?key=$apiKey"
        val fallbackReq = Request.Builder()
            .url(fallbackUrl)
            .post(bodyJson.toRequestBody(jsonMediaType))
            .build()
        httpClient.newCall(fallbackReq).execute().use { resp ->
            val body = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) error("Gemini ($discovered) HTTP ${resp.code}: $body")
            cachedGeminiModel = discovered
            val json = JSONObject(body)
            return json.getJSONArray("candidates")
                .getJSONObject(0)
                .getJSONObject("content")
                .getJSONArray("parts")
                .getJSONObject(0)
                .getString("text")
        }
    }

    private fun callOpenAi(systemPrompt: String, userPrompt: String, jsonMode: Boolean): String {
        val apiKey = keyStore.openAiApiKey
        require(apiKey.isNotBlank()) { "OpenAI API key not configured" }

        val bodyJson = JSONObject()
            .put("model", "gpt-4o-mini")
            .put("temperature", 0.3)
            .put("messages", JSONArray()
                .put(JSONObject().put("role", "system").put("content", systemPrompt))
                .put(JSONObject().put("role", "user").put("content", userPrompt))
            )
        if (jsonMode) {
            bodyJson.put("response_format", JSONObject().put("type", "json_object"))
        }

        val request = Request.Builder()
            .url("https://api.openai.com/v1/chat/completions")
            .addHeader("Authorization", "Bearer $apiKey")
            .post(bodyJson.toString().toRequestBody(jsonMediaType))
            .build()

        httpClient.newCall(request).execute().use { resp ->
            val body = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) error("OpenAI HTTP ${resp.code}: $body")
            return JSONObject(body)
                .getJSONArray("choices")
                .getJSONObject(0)
                .getJSONObject("message")
                .getString("content")
        }
    }

    private fun extractJsonObject(raw: String): String {
        val start = raw.indexOf('{')
        val end = raw.lastIndexOf('}')
        return if (start != -1 && end > start) raw.substring(start, end + 1) else raw
    }

    private fun hashKey(input: String): String =
        MessageDigest.getInstance("SHA-256")
            .digest(input.toByteArray())
            .joinToString("") { "%02x".format(it) }
}
