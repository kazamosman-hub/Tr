package com.personal.watchtranslate.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

enum class TranslationStyle(val displayName: String, val arabicLabel: String) {
    EGYPTIAN_ARABIC("Egyptian Arabic", "عامية مصرية طبيعية"),
    MSA("Modern Standard Arabic", "فصحى سينمائية"),
    NATURAL_ARABIC("Natural Arabic", "عربي طبيعي سلس"),
    ENGLISH("English", "إنجليزي")
}

enum class TranslationMode(val label: String) {
    AUTO("Auto (Captions → Live AI)"),
    SUBTITLE_ONLY("Website Captions Only"),
    LIVE_AUDIO("AI Live Audio")
}

enum class EngineStatus(val message: String, val isError: Boolean = false) {
    IDLE("Ready"),
    DETECTING_VIDEO("Scanning for video..."),
    CAPTIONS_ACTIVE("Translating website captions"),
    LIVE_AUDIO_ACTIVE("Live AI translating audio"),
    PAUSED("Translation paused"),
    DRM_OR_SILENCE("Audio capture blocked by DRM/site. Trying captions only.", isError = true),
    NO_API_KEY("أضف مفتاح Gemini في الإعدادات أولاً", isError = true),
    NO_DEEPGRAM_KEY("أضف مفتاح Deepgram في الإعدادات للترجمة الصوتية", isError = true),
    NETWORK_ERROR("Network interrupted. Retrying...", isError = true)
}

data class SubtitleCue(
    val id: String = UUID.randomUUID().toString(),
    val startMs: Long,
    val endMs: Long,
    val sourceText: String,
    val translatedText: String,
    val speakerLabel: String? = null,
    val isFromWebsiteCaption: Boolean = false
)

data class SubtitleExplanation(
    val original: String,
    val translation: String,
    val meaningInContext: String,
    val slangOrIdiomNotes: String,
    val egyptianVersion: String,
    val alternatives: List<String>,
    val pronunciationGuide: String
)

data class SubtitleStyleConfig(
    val fontSizeSp: Float = 20f,
    val textColorHex: Long = 0xFFFFFFFF,
    val bgOpacity: Float = 0.72f,
    val verticalPositionBias: Float = 0.84f,
    val delayOffsetMs: Long = 0L,
    val speedMultiplier: Float = 1.0f,
    val showOriginalText: Boolean = false
)

data class VideoPlaybackState(
    val detected: Boolean = false,
    val isPlaying: Boolean = false,
    val currentTimeMs: Long = 0L,
    val durationMs: Long = 0L,
    val playbackRate: Float = 1.0f,
    val hasAccessibleCaptions: Boolean = false,
    val pageTitle: String = "",
    val pageUrl: String = ""
)

data class BrowserTab(
    val id: String = UUID.randomUUID().toString(),
    val url: String = "about:home",
    val title: String = "Home",
    val isPrivate: Boolean = false,
    val isDesktopMode: Boolean = false,
    val blockedCount: Int = 0
)

@Entity(tableName = "bookmarks")
data class BookmarkEntity(
    @PrimaryKey val url: String,
    val title: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "history")
data class HistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val url: String,
    val title: String,
    val visitedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "translation_cache")
data class TranslationCacheEntity(
    @PrimaryKey val cacheKey: String,
    val sourceText: String,
    val translatedText: String,
    val style: String,
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "translation_history")
data class TranslationHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val pageTitle: String,
    val pageUrl: String,
    val sourceSnippet: String,
    val translatedSnippet: String,
    val style: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "adblock_rules")
data class AdBlockRuleEntity(
    @PrimaryKey val domain: String,
    val isWhitelist: Boolean
)
