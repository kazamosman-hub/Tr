package com.personal.watchtranslate.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.personal.watchtranslate.data.model.BookmarkEntity
import com.personal.watchtranslate.data.model.HistoryEntity
import com.personal.watchtranslate.ui.theme.*

@Composable
fun HomeScreen(
    bookmarks: List<BookmarkEntity>,
    recentHistory: List<HistoryEntity>,
    adBlockerEnabled: Boolean,
    totalBlockedAds: Int,
    aiTranslationReady: Boolean,
    onNavigate: (String) -> Unit,
    onToggleAdBlocker: (Boolean) -> Unit,
    onOpenSettings: () -> Unit,
    onOpenTranslationHistory: () -> Unit
) {
    var query by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepBlack)
            .padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp),
        contentPadding = PaddingValues(top = 32.dp, bottom = 40.dp)
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = "WatchTranslate AI",
                    fontSize = 26.sp,
                    fontWeight = FontWeight.Bold,
                    color = SoftWhite
                )
                Text(
                    text = "Watch directly. Instant Arabic subtitles.",
                    fontSize = 13.sp,
                    color = MutedSlate
                )
            }
        }

        item {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                placeholder = { Text("Search or enter video website URL", color = MutedSlate) },
                leadingIcon = { Icon(Icons.Rounded.Search, null, tint = ElectricPurple) },
                trailingIcon = {
                    if (query.isNotBlank()) {
                        IconButton(onClick = { onNavigate(query) }) {
                            Icon(Icons.AutoMirrored.Rounded.ArrowForward, null, tint = VividBlue)
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = CharcoalSurface,
                    unfocusedContainerColor = CharcoalSurface,
                    focusedBorderColor = ElectricPurple,
                    unfocusedBorderColor = ElevatedCharcoal
                ),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                keyboardActions = KeyboardActions(onGo = { if (query.isNotBlank()) onNavigate(query) }),
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = CharcoalSurface,
                    modifier = Modifier.weight(1f)
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Ad Blocker", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            Text("$totalBlockedAds blocked", color = MutedSlate, fontSize = 11.sp)
                        }
                        Switch(checked = adBlockerEnabled, onCheckedChange = onToggleAdBlocker)
                    }
                }

                Surface(
                    onClick = onOpenSettings,
                    shape = RoundedCornerShape(16.dp),
                    color = CharcoalSurface,
                    modifier = Modifier.weight(1f)
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("AI Engine", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            Text(
                                if (aiTranslationReady) "Ready" else "Set API Key",
                                color = if (aiTranslationReady) SuccessGreen else AlertAmber,
                                fontSize = 11.sp
                            )
                        }
                        Icon(Icons.Rounded.Tune, null, tint = ElectricPurple)
                    }
                }
            }
        }

        if (bookmarks.isNotEmpty()) {
            item {
                Text("Bookmarks", fontWeight = FontWeight.SemiBold, color = SoftWhite, fontSize = 15.sp)
                Spacer(Modifier.height(10.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(bookmarks) { bm ->
                        Surface(
                            onClick = { onNavigate(bm.url) },
                            shape = RoundedCornerShape(14.dp),
                            color = ElevatedCharcoal,
                            modifier = Modifier.widthIn(min = 100.dp, max = 160.dp)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Icon(Icons.Rounded.Bookmark, null, tint = VividBlue, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.height(6.dp))
                                Text(bm.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 13.sp)
                            }
                        }
                    }
                }
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                AssistChip(
                    onClick = onOpenTranslationHistory,
                    label = { Text("Translation History") },
                    leadingIcon = { Icon(Icons.Rounded.History, null, modifier = Modifier.size(16.dp)) }
                )
                AssistChip(
                    onClick = onOpenSettings,
                    label = { Text("Translation Settings") },
                    leadingIcon = { Icon(Icons.Rounded.Settings, null, modifier = Modifier.size(16.dp)) }
                )
            }
        }

        if (recentHistory.isNotEmpty()) {
            item {
                Text("Continue Browsing", fontWeight = FontWeight.SemiBold, color = SoftWhite, fontSize = 15.sp)
            }
            items(recentHistory.distinctBy { it.url }.take(8)) { entry ->
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = CharcoalSurface,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onNavigate(entry.url) }
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(Icons.Rounded.Language, null, tint = MutedSlate)
                        Column(modifier = Modifier.weight(1f)) {
                            Text(entry.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 14.sp)
                            Text(entry.url, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 11.sp, color = MutedSlate)
                        }
                    }
                }
            }
        }
    }
}
