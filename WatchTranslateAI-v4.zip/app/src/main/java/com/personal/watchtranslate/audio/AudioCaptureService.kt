package com.personal.watchtranslate.audio

import android.annotation.SuppressLint
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.*
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.os.Process
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.sqrt

data class AudioFrame(
    val pcm16Bytes: ByteArray,
    val capturedAtEpochMs: Long,
    val rmsEnergy: Double
)

object AudioCaptureBus {
    private val _audioFrames = MutableSharedFlow<AudioFrame>(extraBufferCapacity = 64)
    val audioFrames = _audioFrames.asSharedFlow()

    private val _isCapturing = MutableStateFlow(false)
    val isCapturing = _isCapturing.asStateFlow()

    private val _drmSilenceDetected = MutableStateFlow(false)
    val drmSilenceDetected = _drmSilenceDetected.asStateFlow()

    internal fun emitFrame(frame: AudioFrame) { _audioFrames.tryEmit(frame) }
    internal fun setCapturing(active: Boolean) { _isCapturing.value = active }
    internal fun setDrmSilence(detected: Boolean) { _drmSilenceDetected.value = detected }
}

class AudioCaptureService : Service() {

    companion object {
        const val CHANNEL_ID = "watchtranslate_live_audio"
        const val NOTIFICATION_ID = 4201
        const val ACTION_START = "ACTION_START_CAPTURE"
        const val ACTION_STOP = "ACTION_STOP_CAPTURE"
        const val EXTRA_RESULT_CODE = "EXTRA_RESULT_CODE"
        const val EXTRA_RESULT_DATA = "EXTRA_RESULT_DATA"
        const val SAMPLE_RATE = 16000
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var mediaProjection: MediaProjection? = null
    private var audioRecord: AudioRecord? = null
    private var captureJob: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopCapture()
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_START -> {
                startForegroundWithNotification()
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
                val resultData: Intent? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra(EXTRA_RESULT_DATA)
                }
                if (resultCode == Activity.RESULT_OK && resultData != null) {
                    startCapture(resultCode, resultData)
                } else {
                    stopSelf()
                }
            }
        }
        return START_NOT_STICKY
    }

    private fun startForegroundWithNotification() {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channel = NotificationChannel(
            CHANNEL_ID,
            "AI Live Audio Translation",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Captures in-browser video audio for real-time Arabic subtitles"
        }
        manager.createNotificationChannel(channel)

        val stopIntent = PendingIntent.getService(
            this, 0,
            Intent(this, AudioCaptureService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("WatchTranslate AI Active")
            .setContentText("Listening to browser video audio for live Arabic subtitles")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_media_pause, "Stop", stopIntent)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    @SuppressLint("MissingPermission")
    private fun startCapture(resultCode: Int, resultData: Intent) {
        stopCapture()
        val projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val projection = projectionManager.getMediaProjection(resultCode, resultData) ?: run {
            stopSelf()
            return
        }
        mediaProjection = projection

        projection.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                stopCapture()
                stopSelf()
            }
        }, null)

        val config = AudioPlaybackCaptureConfiguration.Builder(projection)
            .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
            .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
            .addMatchingUid(Process.myUid())
            .build()

        val format = AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(SAMPLE_RATE)
            .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
            .build()

        val minBuf = AudioRecord.getMinBufferSize(
            SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        val chunkBytes = SAMPLE_RATE * 2 / 5
        val bufferSize = maxOf(minBuf * 2, chunkBytes * 2)

        try {
            audioRecord = AudioRecord.Builder()
                .setAudioFormat(format)
                .setBufferSizeInBytes(bufferSize)
                .setAudioPlaybackCaptureConfig(config)
                .build()
        } catch (e: SecurityException) {
            stopSelf()
            return
        }

        audioRecord?.startRecording()
        AudioCaptureBus.setCapturing(true)
        AudioCaptureBus.setDrmSilence(false)

        captureJob = serviceScope.launch {
            val readBuffer = ByteArray(chunkBytes)
            var consecutiveZeroFrames = 0

            while (isActive && audioRecord?.recordingState == AudioRecord.RECORDSTATE_RECORDING) {
                val read = audioRecord?.read(readBuffer, 0, readBuffer.size) ?: -1
                if (read > 0) {
                    val copy = readBuffer.copyOf(read)
                    val rms = computeRms(copy)
                    if (rms == 0.0) {
                        consecutiveZeroFrames++
                        if (consecutiveZeroFrames >= 25) {
                            AudioCaptureBus.setDrmSilence(true)
                        }
                    } else {
                        consecutiveZeroFrames = 0
                        AudioCaptureBus.setDrmSilence(false)
                    }
                    AudioCaptureBus.emitFrame(
                        AudioFrame(
                            pcm16Bytes = copy,
                            capturedAtEpochMs = System.currentTimeMillis(),
                            rmsEnergy = rms
                        )
                    )
                }
            }
        }
    }

    private fun computeRms(pcm16: ByteArray): Double {
        var sum = 0.0
        val samples = pcm16.size / 2
        if (samples == 0) return 0.0
        for (i in 0 until samples) {
            val low = pcm16[i * 2].toInt() and 0xFF
            val high = pcm16[i * 2 + 1].toInt()
            val sample = (high shl 8) or low
            sum += sample * sample
        }
        return sqrt(sum / samples)
    }

    private fun stopCapture() {
        captureJob?.cancel()
        captureJob = null
        runCatching {
            audioRecord?.stop()
            audioRecord?.release()
        }
        audioRecord = null
        runCatching { mediaProjection?.stop() }
        mediaProjection = null
        AudioCaptureBus.setCapturing(false)
    }

    override fun onDestroy() {
        stopCapture()
        serviceScope.cancel()
        super.onDestroy()
    }
}
