package com.personal.watchtranslate.ai

import com.personal.watchtranslate.data.model.SubtitleCue
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.abs

class SubtitleSyncEngine {
    private val cues = ArrayList<SubtitleCue>()

    private val _activeCue = MutableStateFlow<SubtitleCue?>(null)
    val activeCue = _activeCue.asStateFlow()

    @Volatile private var delayOffsetMs: Long = 0L
    @Volatile private var speedMultiplier: Float = 1.0f
    @Volatile private var liveAnchorEpochMs: Long = 0L
    @Volatile private var liveAnchorVideoMs: Long = 0L
    @Volatile private var lastLiveCueShownAtEpochMs: Long = 0L
    @Volatile private var lastLiveCueDurationMs: Long = 4000L

    fun updateTimingControls(delayMs: Long, speed: Float) {
        delayOffsetMs = delayMs
        speedMultiplier = speed.coerceIn(0.5f, 2.0f)
    }

    fun resetSync() {
        delayOffsetMs = 0L
        speedMultiplier = 1.0f
    }

    fun anchorLiveStream(streamStartEpochMs: Long, videoTimeAtStartMs: Long) {
        liveAnchorEpochMs = streamStartEpochMs
        liveAnchorVideoMs = videoTimeAtStartMs
    }

    fun addCue(cue: SubtitleCue) {
        val minDurationMs = (1200f / speedMultiplier).toLong()
        val maxDurationMs = (6500f / speedMultiplier).toLong()
        val rawDuration = (cue.endMs - cue.startMs).coerceIn(minDurationMs, maxDurationMs)
        val normalized = cue.copy(endMs = cue.startMs + rawDuration)

        synchronized(cues) {
            for (i in cues.indices.reversed()) {
                val prev = cues[i]
                if (prev.startMs < normalized.startMs && prev.endMs > normalized.startMs) {
                    cues[i] = prev.copy(endMs = normalized.startMs - 40L)
                    break
                }
            }
            cues.removeAll { abs(it.startMs - normalized.startMs) < 180L }
            cues.add(normalized)
            cues.sortBy { it.startMs }

            if (cues.size > 600) {
                cues.removeAt(0)
            }
        }
    }

    /** Displays live STT cues immediately (works for both direct <video> and cross-origin <iframe> players). */
    fun addLiveCueFromStt(
        sttStartOffsetMs: Long,
        sttEndOffsetMs: Long,
        sourceText: String,
        translatedText: String,
        speakerLabel: String?,
        currentVideoTimeMs: Long
    ) {
        val duration = (sttEndOffsetMs - sttStartOffsetMs).coerceIn(2200L, 6000L)
        val effectiveStart = if (currentVideoTimeMs > 0L) {
            currentVideoTimeMs
        } else {
            sttStartOffsetMs
        }
        val cue = SubtitleCue(
            startMs = effectiveStart,
            endMs = effectiveStart + duration,
            sourceText = sourceText,
            translatedText = translatedText,
            speakerLabel = speakerLabel,
            isFromWebsiteCaption = false
        )
        addCue(cue)
        // Immediately emit to UI so cross-origin iframe videos never stay blank
        lastLiveCueShownAtEpochMs = System.currentTimeMillis()
        lastLiveCueDurationMs = duration
        _activeCue.value = cue
    }

    /** Called every ~120ms from JS video.currentTime tick. */
    fun onVideoTimeUpdate(videoTimeMs: Long, playbackRate: Float) {
        val effectiveTimeMs = videoTimeMs + delayOffsetMs
        val rate = playbackRate.coerceAtLeast(0.5f) * speedMultiplier
        val match = synchronized(cues) {
            cues.lastOrNull { cue ->
                val adjustedEnd = cue.startMs + ((cue.endMs - cue.startMs) / rate).toLong()
                effectiveTimeMs in cue.startMs..adjustedEnd
            }
        }
        if (match != null) {
            _activeCue.value = match
        } else {
            // Keep live cue visible for its wall-clock window if it just arrived
            val current = _activeCue.value
            if (current != null && !current.isFromWebsiteCaption) {
                if (System.currentTimeMillis() - lastLiveCueShownAtEpochMs > lastLiveCueDurationMs) {
                    _activeCue.value = null
                }
            } else {
                _activeCue.value = null
            }
        }
    }

    /** Wall-clock auto-expiry when video is inside a cross-origin iframe without JS TIME_TICK. */
    fun onWallClockTick() {
        val current = _activeCue.value ?: return
        if (!current.isFromWebsiteCaption) {
            if (System.currentTimeMillis() - lastLiveCueShownAtEpochMs > lastLiveCueDurationMs) {
                _activeCue.value = null
            }
        }
    }

    fun onSeek(newVideoTimeMs: Long) {
        val match = synchronized(cues) {
            cues.removeAll { !it.isFromWebsiteCaption }
            liveAnchorEpochMs = System.currentTimeMillis()
            liveAnchorVideoMs = newVideoTimeMs
            cues.lastOrNull { newVideoTimeMs in it.startMs..it.endMs }
        }
        _activeCue.value = match
    }

    fun clearAll() {
        synchronized(cues) {
            cues.clear()
        }
        _activeCue.value = null
    }
}
