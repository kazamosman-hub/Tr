(function() {
  if (window.__watchTranslateInjected) return;
  window.__watchTranslateInjected = true;

  let activeVideo = null;
  let lastReportedTime = -1;
  let attachedTracks = new WeakSet();

  function postEvent(type, payload) {
    try {
      if (window.WatchTranslateBridge) {
        window.WatchTranslateBridge.onJsEvent(type, JSON.stringify(payload));
      }
    } catch (e) {}
  }

  function findPrimaryVideo() {
    const videos = Array.from(document.querySelectorAll('video'));
    if (videos.length === 0) return null;
    const playing = videos.find(v => !v.paused && !v.ended && v.readyState > 1);
    if (playing) return playing;
    return videos.sort((a, b) => (b.clientWidth * b.clientHeight) - (a.clientWidth * a.clientHeight))[0];
  }

  function extractTextTracks(video) {
    if (!video || !video.textTracks) return false;
    let found = false;
    for (let i = 0; i < video.textTracks.length; i++) {
      const track = video.textTracks[i];
      if (track.kind === 'subtitles' || track.kind === 'captions') {
        found = true;
        if (track.mode === 'disabled') {
          track.mode = 'hidden';
        }
        if (!attachedTracks.has(track)) {
          attachedTracks.add(track);
          const emitCues = () => {
            if (!track.cues || track.cues.length === 0) return;
            const cues = [];
            for (let j = 0; j < track.cues.length; j++) {
              const c = track.cues[j];
              const cleanText = (c.text || '').replace(/<[^>]*>/g, '').trim();
              if (cleanText) {
                cues.push({
                  startMs: Math.round(c.startTime * 1000),
                  endMs: Math.round(c.endTime * 1000),
                  text: cleanText
                });
              }
            }
            if (cues.length > 0) {
              postEvent('TRACK_CUES', { language: track.language || 'auto', cues: cues });
            }
          };
          track.addEventListener('cuechange', () => {
            if (track.activeCues && track.activeCues.length > 0) {
              const active = Array.from(track.activeCues).map(c => ({
                startMs: Math.round(c.startTime * 1000),
                endMs: Math.round(c.endTime * 1000),
                text: (c.text || '').replace(/<[^>]*>/g, '').trim()
              })).filter(c => c.text.length > 0);
              if (active.length > 0) {
                postEvent('ACTIVE_CUES', { cues: active });
              }
            }
          });
          setTimeout(emitCues, 600);
        }
      }
    }
    return found;
  }

  function bindVideo(video) {
    if (!video || video === activeVideo) return;
    activeVideo = video;

    const sendState = (eventName) => {
      if (!activeVideo) return;
      const hasTracks = extractTextTracks(activeVideo);
      postEvent(eventName, {
        detected: true,
        isPlaying: !activeVideo.paused && !activeVideo.ended,
        currentTimeMs: Math.round((activeVideo.currentTime || 0) * 1000),
        durationMs: Math.round((activeVideo.duration || 0) * 1000),
        playbackRate: activeVideo.playbackRate || 1.0,
        hasAccessibleCaptions: hasTracks,
        pageTitle: document.title || '',
        pageUrl: location.href
      });
    };

    ['play', 'pause', 'ratechange', 'loadedmetadata'].forEach(ev => {
      video.addEventListener(ev, () => sendState('VIDEO_STATE'), { passive: true });
    });
    video.addEventListener('seeking', () => sendState('VIDEO_SEEKING'), { passive: true });
    video.addEventListener('seeked', () => sendState('VIDEO_SEEKED'), { passive: true });

    sendState('VIDEO_STATE');
  }

  const origFetch = window.fetch;
  window.fetch = async function(...args) {
    const response = await origFetch.apply(this, args);
    try {
      const url = typeof args[0] === 'string' ? args[0] : (args[0] && args[0].url) || '';
      const contentType = response.headers.get('content-type') || '';
      if (/\.(vtt|srt)(\?|$)/i.test(url) || contentType.includes('text/vtt')) {
        const cloned = response.clone();
        cloned.text().then(body => {
          if (body && body.length > 10) {
            postEvent('RAW_SUBTITLE_FILE', { url: url, content: body });
          }
        }).catch(() => {});
      }
    } catch (e) {}
    return response;
  };

  setInterval(() => {
    const candidate = findPrimaryVideo();
    if (candidate && candidate !== activeVideo) {
      bindVideo(candidate);
    }
    if (activeVideo) {
      const nowMs = Math.round((activeVideo.currentTime || 0) * 1000);
      if (Math.abs(nowMs - lastReportedTime) >= 80 || !activeVideo.paused) {
        lastReportedTime = nowMs;
        postEvent('TIME_TICK', {
          isPlaying: !activeVideo.paused && !activeVideo.ended,
          currentTimeMs: nowMs,
          playbackRate: activeVideo.playbackRate || 1.0,
          hasAccessibleCaptions: extractTextTracks(activeVideo)
        });
      }
    }
  }, 120);

  window.__watchTranslatePause = () => { if (activeVideo && !activeVideo.paused) activeVideo.pause(); };
  window.__watchTranslatePlay = () => { if (activeVideo && activeVideo.paused) activeVideo.play(); };
})();
