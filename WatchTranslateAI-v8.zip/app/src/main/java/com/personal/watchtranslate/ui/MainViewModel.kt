package com.personal.watchtranslate.ui

import android.app.Application
import android.content.Intent
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.personal.watchtranslate.ai.*
import com.personal.watchtranslate.audio.AudioCaptureBus
import com.personal.watchtranslate.audio.AudioCaptureService
import com.personal.watchtranslate.browser.AdBlockerEngine
import com.personal.watchtranslate.data.local.AppDatabase
import com.personal.watchtranslate.data.local.LlmProvider
import com.personal.watchtranslate.data.local.SecureKeyStore
import com.personal.watchtranslate.data.model.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import java.net.URLEncoder
import java.util.concurrent.ConcurrentHashMap

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val appContext = application.applicationContext
    val db = AppDatabase.getInstance(appContext)
    val dao = db.browserDao()
    val keyStore = SecureKeyStore(appContext)
    val adBlocker = AdBlockerEngine(appContext, dao, viewModelScope)

    private val contextManager = DialogueContextManager()
    val translationEngine = TranslationEngine(keyStore, dao, contextManager)
    val syncEngine = SubtitleSyncEngine()
    private val sttEngine = DeepgramStreamingSttEngine()

    private val _tabs = MutableStateFlow(listOf(BrowserTab()))
    val tabs = _tabs.asStateFlow()

    private val _activeTabIndex = MutableStateFlow(0)
    val activeTabIndex = _activeTabIndex.asStateFlow()

    val currentTab: StateFlow<BrowserTab> = combine(_tabs, _activeTabIndex) { list, idx ->
        list.getOrElse(idx) { list.first() }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, BrowserTab())

    private val _videoState = MutableStateFlow(VideoPlaybackState())
    val videoState = _videoState.asStateFlow()

    private val _engineStatus = MutableStateFlow(EngineStatus.IDLE)
    val engineStatus = _engineStatus.asStateFlow()

    private val _lastErrorDetail = MutableStateFlow<String?>(null)
    val lastErrorDetail = _lastErrorDetail.asStateFlow()

    private val _isTranslationEnabled = MutableStateFlow(false)
    val isTranslationEnabled = _isTranslationEnabled.asStateFlow()

    private val _isTranslationPaused = MutableStateFlow(false)
    val isTranslationPaused = _isTranslationPaused.asStateFlow()

    private val _translationStyle = MutableStateFlow(TranslationStyle.NATURAL_ARABIC)
    val translationStyle = _translationStyle.asStateFlow()

    private val _translationMode = MutableStateFlow(TranslationMode.AUTO)
    val translationMode = _translationMode.asStateFlow()

    private val _subtitleStyle = MutableStateFlow(SubtitleStyleConfig())
    val subtitleStyle = _subtitleStyle.asStateFlow()

    private val _explanationLoading = MutableStateFlow(false)
    val explanationLoading = _explanationLoading.asStateFlow()

    private val _currentExplanation = MutableStateFlow<SubtitleExplanation?>(null)
    val currentExplanation = _currentExplanation.asStateFlow()

    val bookmarks = dao.observeBookmarks().stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val history = dao.observeHistory().stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val translationHistory = dao.observeTranslationHistory().stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    private val websiteRawCues = mutableListOf<RawCaptionCue>()
    private val translatedCueStarts = ConcurrentHashMap.newKeySet<Long>()
    private var lastBatchJob: Job? = null
    private var lastSpeakerId: Int? = null
    private var lastSegmentEpochMs: Long = 0L
    private var silentFrameCount: Int = 0

    init {
        observeLiveAudioPipeline()
        viewModelScope.launch {
            while (isActive) {
                delay(300)
                if (_isTranslationEnabled.value && !_isTranslationPaused.value) {
                    syncEngine.onWallClockTick()
                }
            }
        }
    }

    private fun observeLiveAudioPipeline() {
        viewModelScope.launch {
            AudioCaptureBus.audioFrames.collect { frame ->
                if (_isTranslationEnabled.value && !_isTranslationPaused.value &&
                    _engineStatus.value == EngineStatus.LIVE_AUDIO_ACTIVE
                ) {
                    sttEngine.sendPcmChunk(frame.pcm16Bytes)
                    if (frame.rmsEnergy < 75.0) {
                        silentFrameCount++
                        if (silentFrameCount >= 8) { // ~1.6s of real silence
                            syncEngine.onAudioSilenceDetected()
                        }
                    } else {
                        silentFrameCount = 0
                    }
                }
            }
        }

        viewModelScope.launch {
            AudioCaptureBus.drmSilenceDetected.collect { silence ->
                if (silence && _videoState.value.isPlaying && _engineStatus.value == EngineStatus.LIVE_AUDIO_ACTIVE) {
                    _engineStatus.value = EngineStatus.DRM_OR_SILENCE
                }
            }
        }

        viewModelScope.launch {
            sttEngine.segments.collect { seg ->
                if (!_isTranslationEnabled.value || _isTranslationPaused.value || !seg.isFinal) return@collect
                val now = System.currentTimeMillis()
                val speakerChanged = seg.speakerId != null && lastSpeakerId != null &&
                    seg.speakerId != lastSpeakerId && (now - lastSegmentEpochMs) < 3500L
                lastSpeakerId = seg.speakerId
                lastSegmentEpochMs = now

                val speakerLabel = seg.speakerId?.let { "Speaker ${it + 1}" }
                val res = translationEngine.translateLine(seg.text, _translationStyle.value, speakerLabel)
                res.onSuccess { translated ->
                    val displaySub = if (speakerChanged && !translated.startsWith("-")) "- $translated" else translated
                    syncEngine.addLiveCueFromStt(
                        sttStartOffsetMs = seg.startOffsetMs,
                        sttEndOffsetMs = seg.endOffsetMs,
                        sourceText = seg.text,
                        translatedText = displaySub,
                        speakerLabel = speakerLabel,
                        currentVideoTimeMs = _videoState.value.currentTimeMs
                    )
                    logTranslationHistory(seg.text, displaySub)
                }.onFailure { err ->
                    _lastErrorDetail.value = "Translation: ${err.localizedMessage ?: "Error"}"
                    _engineStatus.value = EngineStatus.NETWORK_ERROR
                }
            }
        }

        viewModelScope.launch {
            sttEngine.errors.collect { errMsg ->
                _lastErrorDetail.value = errMsg
                if (_engineStatus.value == EngineStatus.LIVE_AUDIO_ACTIVE) {
                    _engineStatus.value = EngineStatus.NETWORK_ERROR
                }
            }
        }
    }

    fun navigateTo(rawInput: String) {
        val trimmed = rawInput.trim()
        if (trimmed.isEmpty()) return
        val resolvedUrl = when {
            trimmed == "about:home" -> "about:home"
            trimmed.startsWith("http://") || trimmed.startsWith("https://") -> trimmed
            trimmed.contains(".") && !trimmed.contains(" ") -> "https://$trimmed"
            else -> "https://www.google.com/search?q=${URLEncoder.encode(trimmed, "UTF-8")}"
        }
        updateCurrentTab { it.copy(url = resolvedUrl) }
        resetPageTranslationState()
    }

    fun onPageMetadataUpdated(url: String, title: String) {
        updateCurrentTab { it.copy(url = url, title = title.ifBlank { url }) }
        contextManager.mediaTitle = title
        val tab = currentTab.value
        if (!tab.isPrivate && url.startsWith("http")) {
            viewModelScope.launch(Dispatchers.IO) {
                dao.insertHistory(HistoryEntity(url = url, title = title.ifBlank { url }))
            }
        }
    }

    fun addNewTab(isPrivate: Boolean = false) {
        val updated = _tabs.value + BrowserTab(isPrivate = isPrivate)
        _tabs.value = updated
        _activeTabIndex.value = updated.lastIndex
        resetPageTranslationState()
    }

    fun selectTab(index: Int) {
        if (index in _tabs.value.indices) {
            _activeTabIndex.value = index
            resetPageTranslationState()
        }
    }

    fun closeTab(index: Int) {
        val list = _tabs.value.toMutableList()
        if (list.size <= 1) {
            list[0] = BrowserTab()
            _tabs.value = list
            _activeTabIndex.value = 0
        } else {
            list.removeAt(index)
            _tabs.value = list
            _activeTabIndex.value = _activeTabIndex.value.coerceAtMost(list.lastIndex)
        }
        resetPageTranslationState()
    }

    fun toggleDesktopMode() {
        updateCurrentTab { it.copy(isDesktopMode = !it.isDesktopMode) }
    }

    fun toggleBookmarkCurrentPage() {
        val tab = currentTab.value
        if (!tab.url.startsWith("http")) return
        viewModelScope.launch(Dispatchers.IO) {
            val exists = bookmarks.value.any { it.url == tab.url }
            if (exists) dao.deleteBookmark(tab.url)
            else dao.upsertBookmark(BookmarkEntity(url = tab.url, title = tab.title))
        }
    }

    fun clearAllBrowsingData() {
        viewModelScope.launch(Dispatchers.IO) {
            dao.clearHistory()
            dao.clearTranslationCache()
            dao.clearTranslationHistory()
        }
    }

    private fun updateCurrentTab(transform: (BrowserTab) -> BrowserTab) {
        val idx = _activeTabIndex.value
        val list = _tabs.value.toMutableList()
        if (idx in list.indices) {
            list[idx] = transform(list[idx])
            _tabs.value = list
        }
    }

    fun onJsBridgeEvent(type: String, payloadJson: String) {
        runCatching {
            val json = JSONObject(payloadJson)
            when (type) {
                "VIDEO_STATE" -> {
                    val state = VideoPlaybackState(
                        detected = json.optBoolean("detected"),
                        isPlaying = json.optBoolean("isPlaying"),
                        currentTimeMs = json.optLong("currentTimeMs"),
                        durationMs = json.optLong("durationMs"),
                        playbackRate = json.optDouble("playbackRate", 1.0).toFloat(),
                        hasAccessibleCaptions = json.optBoolean("hasAccessibleCaptions"),
                        pageTitle = json.optString("pageTitle"),
                        pageUrl = json.optString("pageUrl")
                    )
                    _videoState.value = state
                    if (state.pageTitle.isNotBlank()) contextManager.mediaTitle = state.pageTitle
                }
                "TIME_TICK" -> {
                    val currentMs = json.optLong("currentTimeMs")
                    val rate = json.optDouble("playbackRate", 1.0).toFloat()
                    val isPlaying = json.optBoolean("isPlaying")
                    val hasCaps = json.optBoolean("hasAccessibleCaptions")
                    _videoState.value = _videoState.value.copy(
                        detected = true,
                        isPlaying = isPlaying,
                        currentTimeMs = currentMs,
                        playbackRate = rate,
                        hasAccessibleCaptions = hasCaps || websiteRawCues.isNotEmpty()
                    )
                    if (_isTranslationEnabled.value && !_isTranslationPaused.value) {
                        syncEngine.onVideoTimeUpdate(currentMs, rate)
                        if (websiteRawCues.isNotEmpty() && _translationMode.value != TranslationMode.LIVE_AUDIO) {
                            scheduleLookaheadCaptionTranslation(currentMs)
                        }
                    }
                }
                "VIDEO_SEEKING", "VIDEO_SEEKED" -> {
                    val pos = json.optLong("currentTimeMs")
                    syncEngine.onSeek(pos)
                    if (websiteRawCues.isNotEmpty()) scheduleLookaheadCaptionTranslation(pos)
                }
                "RAW_SUBTITLE_FILE" -> {
                    val parsed = SubtitleParser.parseVttOrSrt(json.optString("content"))
                    if (parsed.isNotEmpty()) {
                        websiteRawCues.clear()
                        websiteRawCues.addAll(parsed)
                        translatedCueStarts.clear()
                        _videoState.value = _videoState.value.copy(hasAccessibleCaptions = true)
                        if (_isTranslationEnabled.value && _translationMode.value != TranslationMode.LIVE_AUDIO) {
                            _engineStatus.value = EngineStatus.CAPTIONS_ACTIVE
                            scheduleLookaheadCaptionTranslation(_videoState.value.currentTimeMs)
                        }
                    }
                }
                "TRACK_CUES" -> {
                    val arr = json.getJSONArray("cues")
                    val parsed = (0 until arr.length()).map { i ->
                        val o = arr.getJSONObject(i)
                        RawCaptionCue(o.getLong("startMs"), o.getLong("endMs"), o.getString("text"))
                    }
                    if (parsed.isNotEmpty()) {
                        websiteRawCues.clear()
                        websiteRawCues.addAll(parsed)
                        translatedCueStarts.clear()
                        _videoState.value = _videoState.value.copy(hasAccessibleCaptions = true)
                        if (_isTranslationEnabled.value && _translationMode.value != TranslationMode.LIVE_AUDIO) {
                            _engineStatus.value = EngineStatus.CAPTIONS_ACTIVE
                            scheduleLookaheadCaptionTranslation(_videoState.value.currentTimeMs)
                        }
                    }
                }
                "ACTIVE_CUES" -> {
                    if (!_isTranslationEnabled.value || _isTranslationPaused.value) return
                    val arr = json.getJSONArray("cues")
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        val startMs = o.getLong("startMs")
                        val endMs = o.getLong("endMs")
                        val text = o.getString("text")
                        if (translatedCueStarts.add(startMs)) {
                            viewModelScope.launch {
                                translationEngine.translateLine(text, _translationStyle.value).onSuccess { tr ->
                                    syncEngine.addCue(
                                        SubtitleCue(
                                            startMs = startMs, endMs = endMs,
                                            sourceText = text, translatedText = tr,
                                            isFromWebsiteCaption = true
                                        )
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    private fun scheduleLookaheadCaptionTranslation(currentMs: Long) {
        if (lastBatchJob?.isActive == true) return
        val upcoming = websiteRawCues
            .filter { it.endMs >= currentMs - 500L && !translatedCueStarts.contains(it.startMs) }
            .take(8)
        if (upcoming.isEmpty()) return

        upcoming.forEach { translatedCueStarts.add(it.startMs) }
        lastBatchJob = viewModelScope.launch {
            val res = translationEngine.translateBatch(upcoming.map { it.text }, _translationStyle.value)
            res.onSuccess { translatedList ->
                upcoming.forEachIndexed { idx, raw ->
                    val tr = translatedList.getOrElse(idx) { raw.text }
                    syncEngine.addCue(
                        SubtitleCue(
                            startMs = raw.startMs,
                            endMs = raw.endMs,
                            sourceText = raw.text,
                            translatedText = tr,
                            isFromWebsiteCaption = true
                        )
                    )
                }
                _engineStatus.value = EngineStatus.CAPTIONS_ACTIVE
            }.onFailure {
                upcoming.forEach { translatedCueStarts.remove(it.startMs) }
                _engineStatus.value = EngineStatus.NETWORK_ERROR
            }
        }
    }

    fun requestStartTranslation(): Boolean {
        if (!keyStore.hasTranslationKey()) {
            _engineStatus.value = EngineStatus.NO_API_KEY
            return false
        }
        _lastErrorDetail.value = null
        _isTranslationEnabled.value = true
        _isTranslationPaused.value = false

        val canUseCaptions = websiteRawCues.isNotEmpty() || _videoState.value.hasAccessibleCaptions
        if (canUseCaptions && _translationMode.value != TranslationMode.LIVE_AUDIO) {
            _engineStatus.value = EngineStatus.CAPTIONS_ACTIVE
            scheduleLookaheadCaptionTranslation(_videoState.value.currentTimeMs)
            return false
        }

        if (_translationMode.value == TranslationMode.SUBTITLE_ONLY) {
            _engineStatus.value = EngineStatus.DETECTING_VIDEO
            return false
        }

        if (!keyStore.hasLiveSttKey()) {
            _engineStatus.value = EngineStatus.NO_DEEPGRAM_KEY
            return false
        }
        return !AudioCaptureBus.isCapturing.value
    }

    fun onMediaProjectionGranted(resultCode: Int, data: Intent) {
        val serviceIntent = Intent(appContext, AudioCaptureService::class.java).apply {
            action = AudioCaptureService.ACTION_START
            putExtra(AudioCaptureService.EXTRA_RESULT_CODE, resultCode)
            putExtra(AudioCaptureService.EXTRA_RESULT_DATA, data)
        }
        appContext.startForegroundService(serviceIntent)

        sttEngine.start(keyStore.deepgramApiKey)
        syncEngine.anchorLiveStream(sttEngine.getStreamStartEpochMs(), _videoState.value.currentTimeMs)
        _engineStatus.value = EngineStatus.LIVE_AUDIO_ACTIVE
    }

    fun togglePauseTranslation() {
        val paused = !_isTranslationPaused.value
        _isTranslationPaused.value = paused
        _engineStatus.value = if (paused) EngineStatus.PAUSED else {
            if (AudioCaptureBus.isCapturing.value) EngineStatus.LIVE_AUDIO_ACTIVE else EngineStatus.CAPTIONS_ACTIVE
        }
    }

    fun stopTranslation() {
        _isTranslationEnabled.value = false
        _isTranslationPaused.value = false
        _lastErrorDetail.value = null
        _engineStatus.value = EngineStatus.IDLE
        sttEngine.stop()
        appContext.startService(
            Intent(appContext, AudioCaptureService::class.java).apply {
                action = AudioCaptureService.ACTION_STOP
            }
        )
        syncEngine.clearAll()
    }

    fun setTranslationStyle(style: TranslationStyle) {
        _translationStyle.value = style
        translatedCueStarts.clear()
        syncEngine.clearAll()
        if (_isTranslationEnabled.value && websiteRawCues.isNotEmpty()) {
            scheduleLookaheadCaptionTranslation(_videoState.value.currentTimeMs)
        }
    }

    fun setTranslationMode(mode: TranslationMode) {
        _translationMode.value = mode
    }

    fun updateSubtitleStyle(transform: (SubtitleStyleConfig) -> SubtitleStyleConfig) {
        val updated = transform(_subtitleStyle.value)
        _subtitleStyle.value = updated
        syncEngine.updateTimingControls(updated.delayOffsetMs, updated.speedMultiplier)
    }

    fun resetSynchronization() {
        updateSubtitleStyle { it.copy(delayOffsetMs = 0L, speedMultiplier = 1.0f) }
        syncEngine.resetSync()
    }

    fun requestExplainSubtitle(cue: SubtitleCue) {
        _explanationLoading.value = true
        _currentExplanation.value = null
        viewModelScope.launch {
            translationEngine.explainSubtitle(cue.sourceText, cue.translatedText)
                .onSuccess { _currentExplanation.value = it }
            _explanationLoading.value = false
        }
    }

    fun dismissExplanation() {
        _currentExplanation.value = null
        _explanationLoading.value = false
    }

    fun saveApiSettings(provider: LlmProvider, geminiKey: String, groqKey: String, openAiKey: String, deepgramKey: String) {
        keyStore.llmProvider = provider
        keyStore.geminiApiKey = geminiKey
        keyStore.groqApiKey = groqKey
        keyStore.openAiApiKey = openAiKey
        keyStore.deepgramApiKey = deepgramKey
        if (_engineStatus.value == EngineStatus.NO_API_KEY && keyStore.hasTranslationKey()) {
            _engineStatus.value = EngineStatus.IDLE
        }
    }

    private fun logTranslationHistory(source: String, translated: String) {
        if (currentTab.value.isPrivate) return
        viewModelScope.launch(Dispatchers.IO) {
            dao.insertTranslationHistory(
                TranslationHistoryEntity(
                    pageTitle = _videoState.value.pageTitle.ifBlank { currentTab.value.title },
                    pageUrl = currentTab.value.url,
                    sourceSnippet = source,
                    translatedSnippet = translated,
                    style = _translationStyle.value.arabicLabel
                )
            )
        }
    }

    private fun resetPageTranslationState() {
        websiteRawCues.clear()
        translatedCueStarts.clear()
        contextManager.reset()
        syncEngine.clearAll()
        _videoState.value = VideoPlaybackState()
    }

    suspend fun testApiKeys(
        provider: LlmProvider,
        geminiKey: String,
        groqKey: String,
        openAiKey: String,
        deepgramKey: String
    ): String = withContext(Dispatchers.IO) {
        val client = OkHttpClient.Builder()
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .build()
        val lines = mutableListOf<String>()

        // 1. Test selected LLM key
        when (provider) {
            LlmProvider.GEMINI -> {
                val key = geminiKey.trim()
                if (key.isBlank()) {
                    lines.add("Gemini: ⚠️ لم يتم إدخال المفتاح")
                } else {
                    val res = runCatching {
                        val listUrl = "https://generativelanguage.googleapis.com/v1beta/models?key=$key"
                        val discovered = client.newCall(Request.Builder().url(listUrl).build()).execute().use { resp ->
                            if (!resp.isSuccessful) error("HTTP ${resp.code}")
                            val models = JSONObject(resp.body?.string().orEmpty()).optJSONArray("models") ?: JSONArray()
                            val valid = mutableListOf<String>()
                            for (i in 0 until models.length()) {
                                val m = models.getJSONObject(i)
                                val name = m.optString("name").removePrefix("models/")
                                val methods = m.optJSONArray("supportedGenerationMethods")?.toString().orEmpty()
                                if (methods.contains("generateContent") && name.contains("gemini", ignoreCase = true) && !name.contains("vision") && !name.contains("tts") && !name.contains("image")) {
                                    valid.add(name)
                                }
                            }
                            valid
                        }
                        val toTry = (listOf("gemini-2.5-flash-lite", "gemini-2.0-flash-lite", "gemini-2.0-flash", "gemini-flash-latest") + discovered).distinct()
                        val body = JSONObject().put(
                            "contents",
                            JSONArray().put(
                                JSONObject().put("parts", JSONArray().put(JSONObject().put("text", "OK")))
                            )
                        ).toString()

                        var workingResult: String? = null
                        var lastErr = "لا يوجد موديل متاح"
                        for (model in toTry.take(8)) {
                            val testUrl = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$key"
                            client.newCall(
                                Request.Builder().url(testUrl).post(body.toRequestBody("application/json; charset=utf-8".toMediaType())).build()
                            ).execute().use { resp ->
                                if (resp.isSuccessful) {
                                    workingResult = "Gemini: ✅ شغال بنجاح ($model)"
                                } else {
                                    lastErr = "خطأ (${resp.code}) على $model"
                                }
                            }
                            if (workingResult != null) break
                        }
                        workingResult ?: "Gemini: ❌ $lastErr"
                    }.getOrElse { "Gemini: ❌ خطأ (${it.localizedMessage})" }
                    lines.add(res)
                }
            }
            LlmProvider.GROQ -> {
                val key = groqKey.trim()
                if (key.isBlank()) {
                    lines.add("Groq: ⚠️ لم يتم إدخال المفتاح")
                } else {
                    val res = runCatching {
                        val body = JSONObject()
                            .put("model", "llama-3.3-70b-versatile")
                            .put("max_tokens", 5)
                            .put("messages", JSONArray().put(
                                JSONObject().put("role", "user").put("content", "OK")
                            ))
                            .toString()
                            .toRequestBody("application/json; charset=utf-8".toMediaType())
                        val req = Request.Builder()
                            .url("https://api.groq.com/openai/v1/chat/completions")
                            .addHeader("Authorization", "Bearer $key")
                            .post(body)
                            .build()
                        client.newCall(req).execute().use { resp ->
                            if (resp.isSuccessful) "Groq: ✅ شغال بنجاح (llama-3.3-70b-versatile)"
                            else "Groq: ❌ خطأ (${resp.code}) - تأكد من صحة المفتاح"
                        }
                    }.getOrElse { "Groq: ❌ فشل الاتصال (${it.localizedMessage})" }
                    lines.add(res)
                }
            }
            LlmProvider.OPENAI -> {
                val key = openAiKey.trim()
                if (key.isBlank()) {
                    lines.add("OpenAI: ⚠️ لم يتم إدخال المفتاح")
                } else {
                    val res = runCatching {
                        val req = Request.Builder()
                            .url("https://api.openai.com/v1/models")
                            .addHeader("Authorization", "Bearer $key")
                            .build()
                        client.newCall(req).execute().use { resp ->
                            if (resp.isSuccessful) "OpenAI: ✅ شغال بنجاح"
                            else "OpenAI: ❌ خطأ (${resp.code}) - المفتاح غير صحيح أو منتهي"
                        }
                    }.getOrElse { "OpenAI: ❌ فشل الاتصال (${it.localizedMessage})" }
                    lines.add(res)
                }
            }
        }

        // 2. Test Deepgram key
        val dgKey = deepgramKey.trim()
        if (dgKey.isBlank()) {
            lines.add("Deepgram: ⚠️ لم يتم إدخال المفتاح (مطلوب للترجمة الصوتية)")
        } else {
            val res = runCatching {
                val req = Request.Builder()
                    .url("https://api.deepgram.com/v1/projects")
                    .addHeader("Authorization", "Token $dgKey")
                    .build()
                client.newCall(req).execute().use { resp ->
                    if (resp.isSuccessful) "Deepgram: ✅ شغال بنجاح"
                    else "Deepgram: ❌ خطأ (${resp.code}) - المفتاح غير صحيح"
                }
            }.getOrElse { "Deepgram: ❌ فشل الاتصال (${it.localizedMessage})" }
            lines.add(res)
        }

        lines.joinToString("\n")
    }
}
