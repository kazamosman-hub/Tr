package com.personal.watchtranslate.ai

import com.personal.watchtranslate.data.model.SubtitleCue
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.abs

class SubtitleSyncEngine {
    private val cues = ArrayList<SubtitleCue>()

    private val _activeCue = MutableStateFlow<SubtitleCue?>(null)
    val activeCue = _activeCue.asStateFlow()

    @Volatile private var delayOffsetMs: Long = 0L
    @Volatile private var speedMultiplier: Float = 1.0f
    @Volatile private var liveAnchorEpochMs: Long = 0L
    @Volatile private var liveAnchorVideoMs: Long = 0L
    @Volatile private var lastLiveCueShownAtEpochMs: Long = 0L
    @Volatile private var lastLiveCueDurationMs: Long = 3500L

    fun updateTimingControls(delayMs: Long, speed: Float) {
        delayOffsetMs = delayMs
        speedMultiplier = speed.coerceIn(0.5f, 2.0f)
    }

    fun resetSync() {
        delayOffsetMs = 0L
        speedMultiplier = 1.0f
    }

    fun anchorLiveStream(streamStartEpochMs: Long, videoTimeAtStartMs: Long) {
        liveAnchorEpochMs = streamStartEpochMs
        liveAnchorVideoMs = videoTimeAtStartMs
    }

    /** Netflix-standard CPS (Characters Per Second ~18 chars/sec) optimal reading duration. */
    private fun computeSmartReadingDurationMs(text: String, rawDurationMs: Long): Long {
        val cpsMs = ((text.length / 18.0) * 1000.0).toLong() + 700L
        val target = maxOf(rawDurationMs, cpsMs)
        val minMs = (1400f / speedMultiplier).toLong()
        val maxMs = (5500f / speedMultiplier).toLong()
        return target.coerceIn(minMs, maxMs)
    }

    /** Splits long subtitles into 2 visually balanced lines (max ~42 chars/line) like Netflix. */
    fun formatNetflixLines(rawText: String): String {
        val clean = rawText.trim().replace(Regex("[ \t]+"), " ")
        if (clean.contains("\n") || clean.length <= 38) return clean
        val words = clean.split(" ")
        if (words.size < 4) return clean

        val targetMid = clean.length / 2
        var bestSplitIdx = words.size / 2
        var bestDiff = Int.MAX_VALUE
        var runningLen = 0
        for (i in 0 until words.size - 1) {
            runningLen += words[i].length + (if (i > 0) 1 else 0)
            val diff = abs(runningLen - targetMid)
            if (diff < bestDiff) {
                bestDiff = diff
                bestSplitIdx = i + 1
            }
        }
        val line1 = words.subList(0, bestSplitIdx).joinToString(" ")
        val line2 = words.subList(bestSplitIdx, words.size).joinToString(" ")
        return "$line1\n$line2"
    }

    fun addCue(cue: SubtitleCue) {
        val formattedText = formatNetflixLines(cue.translatedText)
        val smartDuration = computeSmartReadingDurationMs(formattedText, cue.endMs - cue.startMs)
        val normalized = cue.copy(
            translatedText = formattedText,
            endMs = cue.startMs + smartDuration
        )

        synchronized(cues) {
            for (i in cues.indices.reversed()) {
                val prev = cues[i]
                if (prev.startMs < normalized.startMs && prev.endMs > normalized.startMs) {
                    cues[i] = prev.copy(endMs = normalized.startMs - 40L)
                    break
                }
            }
            cues.removeAll { abs(it.startMs - normalized.startMs) < 180L }
            cues.add(normalized)
            cues.sortBy { it.startMs }

            if (cues.size > 600) {
                cues.removeAt(0)
            }
        }
    }

    fun addLiveCueFromStt(
        sttStartOffsetMs: Long,
        sttEndOffsetMs: Long,
        sourceText: String,
        translatedText: String,
        speakerLabel: String?,
        currentVideoTimeMs: Long
    ) {
        val formatted = formatNetflixLines(translatedText)
        val duration = computeSmartReadingDurationMs(formatted, sttEndOffsetMs - sttStartOffsetMs)
        val effectiveStart = if (currentVideoTimeMs > 0L) currentVideoTimeMs else sttStartOffsetMs
        val cue = SubtitleCue(
            startMs = effectiveStart,
            endMs = effectiveStart + duration,
            sourceText = sourceText,
            translatedText = formatted,
            speakerLabel = speakerLabel,
            isFromWebsiteCaption = false
        )
        addCue(cue)
        lastLiveCueShownAtEpochMs = System.currentTimeMillis()
        lastLiveCueDurationMs = duration
        _activeCue.value = cue
    }

    fun onVideoTimeUpdate(videoTimeMs: Long, playbackRate: Float) {
        val effectiveTimeMs = videoTimeMs + delayOffsetMs
        val rate = playbackRate.coerceAtLeast(0.5f) * speedMultiplier
        val match = synchronized(cues) {
            cues.lastOrNull { cue ->
                val adjustedEnd = cue.startMs + ((cue.endMs - cue.startMs) / rate).toLong()
                effectiveTimeMs in cue.startMs..adjustedEnd
            }
        }
        if (match != null) {
            _activeCue.value = match
        } else {
            val current = _activeCue.value
            if (current != null && !current.isFromWebsiteCaption) {
                if (System.currentTimeMillis() - lastLiveCueShownAtEpochMs > lastLiveCueDurationMs) {
                    _activeCue.value = null
                }
            } else {
                _activeCue.value = null
            }
        }
    }

    fun onWallClockTick() {
        val current = _activeCue.value ?: return
        if (!current.isFromWebsiteCaption) {
            if (System.currentTimeMillis() - lastLiveCueShownAtEpochMs > lastLiveCueDurationMs) {
                _activeCue.value = null
            }
        }
    }

    /** Smoothly clears lingering live subtitle when audio goes silent for >1.6s. */
    fun onAudioSilenceDetected() {
        val current = _activeCue.value ?: return
        if (!current.isFromWebsiteCaption) {
            val elapsed = System.currentTimeMillis() - lastLiveCueShownAtEpochMs
            if (elapsed >= 1500L) {
                _activeCue.value = null
            }
        }
    }

    fun onSeek(newVideoTimeMs: Long) {
        val match = synchronized(cues) {
            cues.removeAll { !it.isFromWebsiteCaption }
            liveAnchorEpochMs = System.currentTimeMillis()
            liveAnchorVideoMs = newVideoTimeMs
            cues.lastOrNull { newVideoTimeMs in it.startMs..it.endMs }
        }
        _activeCue.value = match
    }

    fun clearAll() {
        synchronized(cues) {
            cues.clear()
        }
        _activeCue.value = null
    }
}
