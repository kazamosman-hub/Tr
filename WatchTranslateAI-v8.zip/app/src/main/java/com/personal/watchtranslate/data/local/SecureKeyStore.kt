package com.personal.watchtranslate.data.local

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

enum class LlmProvider(val label: String) {
    GEMINI("Google Gemini"),
    GROQ("Groq (Fast)"),
    OPENAI("OpenAI GPT-4o-mini")
}

class SecureKeyStore(context: Context) {
    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val prefs = EncryptedSharedPreferences.create(
        context,
        "watchtranslate_secure_keys",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    var llmProvider: LlmProvider
        get() = runCatching {
            LlmProvider.valueOf(prefs.getString("llm_provider", LlmProvider.GEMINI.name) ?: LlmProvider.GEMINI.name)
        }.getOrDefault(LlmProvider.GEMINI)
        set(value) = prefs.edit().putString("llm_provider", value.name).apply()

    var geminiApiKey: String
        get() = prefs.getString("gemini_key", "") ?: ""
        set(value) = prefs.edit().putString("gemini_key", value.trim()).apply()

    var groqApiKey: String
        get() = prefs.getString("groq_key", "") ?: ""
        set(value) = prefs.edit().putString("groq_key", value.trim()).apply()

    var openAiApiKey: String
        get() = prefs.getString("openai_key", "") ?: ""
        set(value) = prefs.edit().putString("openai_key", value.trim()).apply()

    var deepgramApiKey: String
        get() = prefs.getString("deepgram_key", "") ?: ""
        set(value) = prefs.edit().putString("deepgram_key", value.trim()).apply()

    fun hasTranslationKey(): Boolean = when (llmProvider) {
        LlmProvider.GEMINI -> geminiApiKey.isNotBlank()
        LlmProvider.GROQ -> groqApiKey.isNotBlank()
        LlmProvider.OPENAI -> openAiApiKey.isNotBlank()
    }

    fun hasLiveSttKey(): Boolean = deepgramApiKey.isNotBlank()
}
