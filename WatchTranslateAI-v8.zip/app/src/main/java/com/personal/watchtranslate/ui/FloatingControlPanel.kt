package com.personal.watchtranslate.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.personal.watchtranslate.data.model.*
import com.personal.watchtranslate.ui.theme.*
import kotlin.math.roundToInt

@Composable
fun FloatingTranslationControls(
    isEnabled: Boolean,
    isPaused: Boolean,
    status: EngineStatus,
    errorDetail: String?,
    videoDetected: Boolean,
    currentStyle: TranslationStyle,
    subtitleStyle: SubtitleStyleConfig,
    hasActiveCue: Boolean,
    onStart: () -> Unit,
    onPauseToggle: () -> Unit,
    onStop: () -> Unit,
    onStyleSelected: (TranslationStyle) -> Unit,
    onUpdateSubtitleStyle: ((SubtitleStyleConfig) -> SubtitleStyleConfig) -> Unit,
    onResetSync: () -> Unit,
    onExplainCurrent: () -> Unit,
    modifier: Modifier = Modifier
) {
    var expanded by remember { mutableStateOf(false) }
    var offsetX by remember { mutableFloatStateOf(24f) }
    var offsetY by remember { mutableFloatStateOf(140f) }

    Box(
        modifier = modifier
            .offset { IntOffset(offsetX.roundToInt(), offsetY.roundToInt()) }
            .pointerInput(Unit) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    offsetX = (offsetX + dragAmount.x).coerceIn(8f, 800f)
                    offsetY = (offsetY + dragAmount.y).coerceIn(60f, 1600f)
                }
            }
    ) {
        if (!expanded) {
            Surface(
                onClick = { expanded = true },
                shape = CircleShape,
                color = CharcoalSurface.copy(alpha = 0.92f),
                shadowElevation = 8.dp
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .background(
                            if (isEnabled) Brush.horizontalGradient(listOf(ElectricPurple, VividBlue))
                            else Brush.horizontalGradient(listOf(ElevatedCharcoal, ElevatedCharcoal))
                        )
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Translate,
                        contentDescription = "AI Translate",
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = when {
                            isEnabled && isPaused -> "Paused"
                            isEnabled -> "AI Live"
                            videoDetected -> "AI Translate"
                            else -> "AI"
                        },
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        } else {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = CharcoalSurface.copy(alpha = 0.96f),
                shadowElevation = 14.dp,
                modifier = Modifier.width(308.dp)
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(
                                        when {
                                            status.isError -> AlertAmber
                                            isEnabled && !isPaused -> SuccessGreen
                                            else -> MutedSlate
                                        }
                                    )
                            )
                            Text("WatchTranslate AI", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                        IconButton(onClick = { expanded = false }, modifier = Modifier.size(28.dp)) {
                            Icon(Icons.Rounded.Close, contentDescription = "Collapse", tint = MutedSlate)
                        }
                    }

                    Text(
                        text = if (status.isError && !errorDetail.isNullOrBlank()) "${status.message}\n$errorDetail" else status.message,
                        color = if (status.isError) AlertAmber else MutedSlate,
                        fontSize = 12.sp
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        if (!isEnabled) {
                            Button(
                                onClick = onStart,
                                colors = ButtonDefaults.buttonColors(containerColor = ElectricPurple),
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.Rounded.PlayArrow, null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("Start AI Translate")
                            }
                        } else {
                            FilledTonalButton(
                                onClick = onPauseToggle,
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(if (isPaused) Icons.Rounded.PlayArrow else Icons.Rounded.Pause, null)
                                Spacer(Modifier.width(4.dp))
                                Text(if (isPaused) "Resume" else "Pause")
                            }
                            OutlinedButton(
                                onClick = onStop,
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.Rounded.Stop, null)
                                Spacer(Modifier.width(4.dp))
                                Text("Stop")
                            }
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                        TranslationStyle.entries.forEach { style ->
                            val selected = style == currentStyle
                            FilterChip(
                                selected = selected,
                                onClick = { onStyleSelected(style) },
                                label = {
                                    Text(
                                        when (style) {
                                            TranslationStyle.NATURAL_ARABIC -> "طبيعي"
                                            TranslationStyle.MSA -> "فصحى"
                                            TranslationStyle.ENGLISH -> "EN"
                                        },
                                        fontSize = 11.sp
                                    )
                                },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Sync: ${subtitleStyle.delayOffsetMs}ms", fontSize = 12.sp, color = MutedSlate)
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            SmallSyncChip("-0.5s") { onUpdateSubtitleStyle { it.copy(delayOffsetMs = it.delayOffsetMs - 500) } }
                            SmallSyncChip("+0.5s") { onUpdateSubtitleStyle { it.copy(delayOffsetMs = it.delayOffsetMs + 500) } }
                            SmallSyncChip("Reset") { onResetSync() }
                        }
                    }

                    Text("Text Size: ${subtitleStyle.fontSizeSp.toInt()}sp", fontSize = 11.sp, color = MutedSlate)
                    Slider(
                        value = subtitleStyle.fontSizeSp,
                        onValueChange = { sz -> onUpdateSubtitleStyle { it.copy(fontSizeSp = sz) } },
                        valueRange = 14f..32f,
                        modifier = Modifier.height(26.dp)
                    )

                    Text("Vertical Position", fontSize = 11.sp, color = MutedSlate)
                    Slider(
                        value = subtitleStyle.verticalPositionBias,
                        onValueChange = { pos -> onUpdateSubtitleStyle { it.copy(verticalPositionBias = pos) } },
                        valueRange = 0.15f..0.88f,
                        modifier = Modifier.height(26.dp)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        FilterChip(
                            selected = subtitleStyle.netflixStyle,
                            onClick = { onUpdateSubtitleStyle { it.copy(netflixStyle = !it.netflixStyle) } },
                            label = { Text("Netflix Style", fontSize = 11.sp) },
                            modifier = Modifier.weight(1f)
                        )
                        FilterChip(
                            selected = subtitleStyle.useYellowText,
                            onClick = { onUpdateSubtitleStyle { it.copy(useYellowText = !it.useYellowText) } },
                            label = { Text(if (subtitleStyle.useYellowText) "أصفر" else "أبيض", fontSize = 11.sp) },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextButton(onClick = { onUpdateSubtitleStyle { it.copy(showOriginalText = !it.showOriginalText) } }) {
                            Text(if (subtitleStyle.showOriginalText) "Hide Source" else "Show Source", fontSize = 12.sp)
                        }
                        FilledTonalButton(
                            onClick = {
                                expanded = false
                                onExplainCurrent()
                            },
                            enabled = hasActiveCue,
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Rounded.AutoAwesome, null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("AI Explain", fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SmallSyncChip(label: String, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(8.dp),
        color = ElevatedCharcoal
    ) {
        Text(label, fontSize = 11.sp, color = SoftWhite, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
    }
}
