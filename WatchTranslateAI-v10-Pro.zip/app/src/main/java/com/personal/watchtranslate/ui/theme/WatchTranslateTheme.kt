package com.personal.watchtranslate.ui.theme

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val DeepBlack = Color(0xFF0A0A0F)
val CharcoalSurface = Color(0xFF14141F)
val ElevatedCharcoal = Color(0xFF1D1D2D)
val ElectricPurple = Color(0xFF8B5CF6)
val VividBlue = Color(0xFF3B82F6)
val SoftWhite = Color(0xFFF3F4F6)
val MutedSlate = Color(0xFF9CA3AF)
val SuccessGreen = Color(0xFF10B981)
val AlertAmber = Color(0xFFF59E0B)

private val DarkColorScheme = darkColorScheme(
    primary = ElectricPurple,
    secondary = VividBlue,
    background = DeepBlack,
    surface = CharcoalSurface,
    surfaceVariant = ElevatedCharcoal,
    onPrimary = Color.White,
    onSecondary = Color.White,
    onBackground = SoftWhite,
    onSurface = SoftWhite,
    onSurfaceVariant = MutedSlate
)

@Composable
fun WatchTranslateTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography(),
        content = content
    )
}
