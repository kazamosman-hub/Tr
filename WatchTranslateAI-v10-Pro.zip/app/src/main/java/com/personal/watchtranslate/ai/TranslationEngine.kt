package com.personal.watchtranslate.ai

import com.personal.watchtranslate.data.local.BrowserDao
import com.personal.watchtranslate.data.local.LlmProvider
import com.personal.watchtranslate.data.local.SecureKeyStore
import com.personal.watchtranslate.data.model.SubtitleExplanation
import com.personal.watchtranslate.data.model.TranslationCacheEntity
import com.personal.watchtranslate.data.model.TranslationStyle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.security.MessageDigest
import java.util.concurrent.TimeUnit

data class TranslationOutcome(
    val text: String,
    val engineName: String,
    val latencyMs: Long
)

class TranslationEngine(
    private val keyStore: SecureKeyStore,
    private val dao: BrowserDao,
    val contextManager: DialogueContextManager
) {
    private val liveHttpClient = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(7, TimeUnit.SECONDS)
        .writeTimeout(5, TimeUnit.SECONDS)
        .build()

    private val batchHttpClient = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(18, TimeUnit.SECONDS)
        .writeTimeout(8, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    @Volatile private var cachedGeminiModel: String? = null
    @Volatile private var discoveredGeminiModels: List<String> = emptyList()

    fun isAlreadyArabic(text: String): Boolean {
        var arabicCount = 0
        var letterCount = 0
        for (ch in text) {
            if (ch.isLetter()) {
                letterCount++
                if (ch in '\u0600'..'\u06FF' || ch in '\u0750'..'\u077F' || ch in '\u08A0'..'\u08FF') {
                    arabicCount++
                }
            }
        }
        return letterCount >= 3 && arabicCount * 10 >= letterCount * 6
    }

    suspend fun translateLine(
        text: String,
        style: TranslationStyle,
        speakerLabel: String? = null,
        ultraFast: Boolean = true
    ): Result<TranslationOutcome> = withContext(Dispatchers.IO) {
        val clean = text.trim()
        if (clean.isEmpty()) return@withContext Result.success(TranslationOutcome("", "Skip", 0L))

        val t0 = System.currentTimeMillis()

        if (style != TranslationStyle.ENGLISH && isAlreadyArabic(clean)) {
            contextManager.record(clean, clean, speakerLabel)
            return@withContext Result.success(TranslationOutcome(clean, "Direct AR", 0L))
        }

        val cacheKey = hashKey("$clean|${style.name}")
        dao.getCachedTranslation(cacheKey)?.let { cached ->
            contextManager.record(clean, cached.translatedText, speakerLabel)
            return@withContext Result.success(
                TranslationOutcome(cached.translatedText, "Cache", System.currentTimeMillis() - t0)
            )
        }

        val systemPrompt = buildSystemPrompt(style)
        val userPrompt = buildString {
            append(contextManager.buildContextPromptBlock())
            append("\nTranslate ONLY the following movie/series subtitle line into ")
            append(style.displayName)
            append(". Return ONLY the final subtitle text (concise, max 2 short lines, no quotes, no prefixes, no explanations):\n")
            if (speakerLabel != null) append("[$speakerLabel] ")
            append(clean)
        }

        val outcome = runCascadeSingleLine(clean, style, systemPrompt, userPrompt, ultraFast)
        outcome.map { (rawText, engineUsed) ->
            val finalSub = sanitizeSubtitleOutput(rawText)
            dao.saveCachedTranslation(
                TranslationCacheEntity(
                    cacheKey = cacheKey,
                    sourceText = clean,
                    translatedText = finalSub,
                    style = style.name
                )
            )
            contextManager.record(clean, finalSub, speakerLabel)
            TranslationOutcome(finalSub, engineUsed, System.currentTimeMillis() - t0)
        }
    }

    suspend fun translateBatch(
        lines: List<String>,
        style: TranslationStyle,
        ultraFast: Boolean = true
    ): Result<Pair<List<String>, String>> = withContext(Dispatchers.IO) {
        if (lines.isEmpty()) return@withContext Result.success(emptyList<String>() to "Empty")

        val results = MutableList<String?>(lines.size) { null }
        val missingIndices = mutableListOf<Int>()

        lines.forEachIndexed { idx, line ->
            val clean = line.trim()
            if (clean.isEmpty()) {
                results[idx] = ""
            } else if (style != TranslationStyle.ENGLISH && isAlreadyArabic(clean)) {
                results[idx] = clean
            } else {
                val cached = dao.getCachedTranslation(hashKey("$clean|${style.name}"))
                if (cached != null) results[idx] = cached.translatedText
                else missingIndices.add(idx)
            }
        }

        if (missingIndices.isEmpty()) {
            return@withContext Result.success(results.map { it.orEmpty() } to "Cache")
        }

        if (keyStore.llmProvider == LlmProvider.GOOGLE_FREE) {
            return@withContext translateBatchViaGoogleFree(lines, missingIndices, results, style)
        }

        val payloadArray = JSONArray()
        missingIndices.forEach { idx ->
            payloadArray.put(JSONObject().put("i", idx).put("t", lines[idx]))
        }

        val systemPrompt = buildSystemPrompt(style)
        val userPrompt = """
            ${contextManager.buildContextPromptBlock()}
            Translate each movie subtitle item in this JSON array into ${style.displayName}.
            Keep translations smooth, natural, emotionally accurate, concise for on-screen reading, and consistent across lines.
            Return ONLY valid JSON: {"items":[{"i":0,"tr":"..."}]}
            Input: $payloadArray
        """.trimIndent()

        val cascade = runCascadeLlm(systemPrompt, userPrompt, jsonMode = true, ultraFast = ultraFast, isBatch = true)
        if (cascade.isSuccess) {
            val (raw, engineUsed) = cascade.getOrThrow()
            val parsedResult = runCatching {
                val parsed = JSONObject(extractJsonObject(raw)).getJSONArray("items")
                for (k in 0 until parsed.length()) {
                    val item = parsed.getJSONObject(k)
                    val idx = item.getInt("i")
                    val tr = sanitizeSubtitleOutput(item.getString("tr"))
                    if (idx in results.indices && tr.isNotEmpty()) {
                        results[idx] = tr
                        dao.saveCachedTranslation(
                            TranslationCacheEntity(
                                cacheKey = hashKey("${lines[idx].trim()}|${style.name}"),
                                sourceText = lines[idx].trim(),
                                translatedText = tr,
                                style = style.name
                            )
                        )
                        contextManager.record(lines[idx], tr)
                    }
                }
                results.mapIndexed { idx, value -> value ?: lines[idx] } to engineUsed
            }
            if (parsedResult.isSuccess) return@withContext parsedResult
        }

        translateBatchViaGoogleFree(lines, missingIndices, results, style)
    }

    private suspend fun translateBatchViaGoogleFree(
        lines: List<String>,
        missingIndices: List<Int>,
        results: MutableList<String?>,
        style: TranslationStyle
    ): Result<Pair<List<String>, String>> = runCatching {
        val combined = missingIndices.joinToString("\n") { lines[it].replace("\n", " ").trim() }
        val translatedJoined = callGoogleTranslateFree(combined, style, batchHttpClient)
        val splitLines = translatedJoined.split("\n")

        if (splitLines.size == missingIndices.size) {
            missingIndices.forEachIndexed { pos, idx ->
                val tr = sanitizeSubtitleOutput(splitLines[pos])
                results[idx] = tr
                dao.saveCachedTranslation(
                    TranslationCacheEntity(
                        cacheKey = hashKey("${lines[idx].trim()}|${style.name}"),
                        sourceText = lines[idx].trim(),
                        translatedText = tr,
                        style = style.name
                    )
                )
                contextManager.record(lines[idx], tr)
            }
        } else {
            missingIndices.forEach { idx ->
                val tr = sanitizeSubtitleOutput(callGoogleTranslateFree(lines[idx], style, liveHttpClient))
                results[idx] = tr
                dao.saveCachedTranslation(
                    TranslationCacheEntity(
                        cacheKey = hashKey("${lines[idx].trim()}|${style.name}"),
                        sourceText = lines[idx].trim(),
                        translatedText = tr,
                        style = style.name
                    )
                )
                contextManager.record(lines[idx], tr)
            }
        }
        results.mapIndexed { idx, value -> value ?: lines[idx] } to "Google Free"
    }

    suspend fun explainSubtitle(
        sourceText: String,
        translatedText: String
    ): Result<SubtitleExplanation> = withContext(Dispatchers.IO) {
        val systemPrompt = "You are a bilingual cinema language coach fluent in English and natural Modern Arabic."
        val userPrompt = """
            ${contextManager.buildContextPromptBlock()}
            Analyze this movie dialogue line for an Arabic-speaking viewer:
            Original: "$sourceText"
            Subtitle shown: "$translatedText"

            Return ONLY valid JSON with these exact keys:
            {
              "meaningInContext": "شرح واضح ومختصر بالعربي الطبيعي لمعنى الجملة في سياق المشهد",
              "slangOrIdiomNotes": "شرح أي تعبير مجازي أو سخرية أو مصطلح سينمائي في الجملة بالعربي (أو 'لا توجد تعبيرات معقدة')",
              "naturalArabicVersion": "أفضل صياغة عربية سينمائية طبيعية سلسة لهذه الجملة",
              "alternatives": ["صياغة بديلة 1", "صياغة بديلة 2"],
              "pronunciationGuide": "دليل نطق بسيط للجملة الأصلية"
            }
        """.trimIndent()

        runCascadeLlm(systemPrompt, userPrompt, jsonMode = true, ultraFast = false, isBatch = true).map { (raw, _) ->
            val obj = JSONObject(extractJsonObject(raw))
            val altsJson = obj.optJSONArray("alternatives") ?: JSONArray()
            val alts = (0 until altsJson.length()).map { altsJson.getString(it) }
            SubtitleExplanation(
                original = sourceText,
                translation = translatedText,
                meaningInContext = obj.optString("meaningInContext"),
                slangOrIdiomNotes = obj.optString("slangOrIdiomNotes"),
                naturalArabicVersion = obj.optString("naturalArabicVersion"),
                alternatives = alts,
                pronunciationGuide = obj.optString("pronunciationGuide")
            )
        }
    }

    private fun runCascadeSingleLine(
        cleanSource: String,
        style: TranslationStyle,
        systemPrompt: String,
        userPrompt: String,
        ultraFast: Boolean
    ): Result<Pair<String, String>> {
        if (keyStore.llmProvider == LlmProvider.GOOGLE_FREE) {
            return runCatching { callGoogleTranslateFree(cleanSource, style, liveHttpClient) to "Google Free" }
        }

        val llmAttempt = runCascadeLlm(systemPrompt, userPrompt, jsonMode = false, ultraFast = ultraFast, isBatch = false)
        if (llmAttempt.isSuccess) return llmAttempt

        return runCatching {
            callGoogleTranslateFree(cleanSource, style, liveHttpClient) to "Google Auto"
        }
    }

    private fun runCascadeLlm(
        systemPrompt: String,
        userPrompt: String,
        jsonMode: Boolean,
        ultraFast: Boolean,
        isBatch: Boolean
    ): Result<Pair<String, String>> {
        val client = if (isBatch) batchHttpClient else liveHttpClient
        val order = buildList {
            add(keyStore.llmProvider)
            if (keyStore.groqApiKey.isNotBlank()) add(LlmProvider.GROQ)
            if (keyStore.geminiApiKey.isNotBlank()) add(LlmProvider.GEMINI)
            if (keyStore.openAiApiKey.isNotBlank()) add(LlmProvider.OPENAI)
        }.distinct().filter { it != LlmProvider.GOOGLE_FREE }

        var lastFailure: Throwable = IllegalStateException("No AI provider configured")
        for (provider in order) {
            val res = runCatching {
                when (provider) {
                    LlmProvider.GROQ -> callGroq(systemPrompt, userPrompt, jsonMode, ultraFast, client) to "Groq"
                    LlmProvider.GEMINI -> callGemini(systemPrompt, userPrompt, jsonMode, client) to "Gemini"
                    LlmProvider.OPENAI -> callOpenAi(systemPrompt, userPrompt, jsonMode, client) to "OpenAI"
                    LlmProvider.GOOGLE_FREE -> error("Skip")
                }
            }
            if (res.isSuccess) return res
            lastFailure = res.exceptionOrNull() ?: lastFailure
        }
        return Result.failure(lastFailure)
    }

    private fun buildSystemPrompt(style: TranslationStyle): String {
        val styleDirective = when (style) {
            TranslationStyle.MSA ->
                "Translate into crisp, cinematic Modern Standard Arabic (العربية الفصحى السينمائية) used by Netflix & top subtitle studios—smooth, expressive, never stiff or robotic."
            TranslationStyle.NATURAL_ARABIC ->
                "Translate into natural, smooth, cinematic modern Arabic (عربي طبيعي سلس مثل ترجمة نتفلكس)—capture idioms, sarcasm, humor, and emotional tone natively without literal wording and without local Egyptian/Gulf slang."
            TranslationStyle.ENGLISH ->
                "Translate into natural, idiomatic cinematic English subtitles."
        }
        return """
            You are an elite Netflix film and TV subtitle translator.
            $styleDirective
            Strict subtitle rules:
            1. Keep subtitles concise and easy to read at movie speed (max 2 short lines, ideally under 42 characters per line).
            2. Match speaker gender/pronouns and keep character names consistent using provided dialogue context.
            3. Preserve humor, sarcasm, idioms, and emotional weight instead of literal word-for-word rendering.
            4. Never invent dialogue that wasn't spoken. Never add notes, brackets, quotation marks, or translator commentary.
        """.trimIndent()
    }

    private fun sanitizeSubtitleOutput(raw: String): String {
        return raw.trim()
            .removePrefix("الترجمة:")
            .removePrefix("Translation:")
            .trim()
            .removeSurrounding("\"")
            .removeSurrounding("«", "»")
            .trim()
    }

    private fun discoverWorkingGeminiModels(apiKey: String, client: OkHttpClient): List<String> {
        if (discoveredGeminiModels.isNotEmpty()) return discoveredGeminiModels
        val url = "https://generativelanguage.googleapis.com/v1beta/models?key=$apiKey"
        val req = Request.Builder().url(url).build()
        return runCatching {
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@use emptyList<String>()
                val models = JSONObject(resp.body?.string().orEmpty()).optJSONArray("models") ?: JSONArray()
                val candidates = mutableListOf<String>()
                for (i in 0 until models.length()) {
                    val m = models.getJSONObject(i)
                    val name = m.optString("name").removePrefix("models/")
                    val methods = m.optJSONArray("supportedGenerationMethods")?.toString().orEmpty()
                    if (methods.contains("generateContent") && name.contains("gemini", ignoreCase = true) &&
                        !name.contains("vision") && !name.contains("tts") && !name.contains("image")
                    ) {
                        candidates.add(name)
                    }
                }
                val sorted = candidates.sortedBy {
                    when {
                        it.contains("flash-lite", ignoreCase = true) -> 0
                        it.contains("flash", ignoreCase = true) && !it.contains("exp") -> 1
                        it.contains("flash", ignoreCase = true) -> 2
                        else -> 3
                    }
                }
                discoveredGeminiModels = sorted
                sorted
            }
        }.getOrDefault(emptyList())
    }

    private fun callGemini(systemPrompt: String, userPrompt: String, jsonMode: Boolean, client: OkHttpClient): String {
        val apiKey = keyStore.geminiApiKey.trim()
        require(apiKey.isNotBlank()) { "Gemini API key not configured" }

        val genConfig = JSONObject().put("temperature", 0.25)
        if (jsonMode) genConfig.put("responseMimeType", "application/json")

        val bodyJson = JSONObject()
            .put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemPrompt))))
            .put("contents", JSONArray().put(
                JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", userPrompt)))
            ))
            .put("generationConfig", genConfig)
            .toString()

        val baseModels = buildList {
            cachedGeminiModel?.let { add(it) }
            add("gemini-2.5-flash-lite")
            add("gemini-2.0-flash-lite")
            add("gemini-2.0-flash")
            add("gemini-flash-latest")
            add("gemini-2.5-flash")
        }
        val allModels = (baseModels + discoverWorkingGeminiModels(apiKey, client)).distinct().take(5)

        var lastError = "Gemini unavailable"
        for (model in allModels) {
            val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey"
            val request = Request.Builder()
                .url(url)
                .post(bodyJson.toRequestBody(jsonMediaType))
                .build()

            client.newCall(request).execute().use { resp ->
                val body = resp.body?.string().orEmpty()
                if (resp.isSuccessful) {
                    cachedGeminiModel = model
                    val json = JSONObject(body)
                    return json.getJSONArray("candidates")
                        .getJSONObject(0)
                        .getJSONObject("content")
                        .getJSONArray("parts")
                        .getJSONObject(0)
                        .getString("text")
                }
                lastError = "Gemini ($model) HTTP ${resp.code}"
                if (resp.code !in listOf(404, 429, 500, 503)) {
                    error("$lastError: $body")
                }
            }
        }
        error(lastError)
    }

    private fun callGroq(
        systemPrompt: String,
        userPrompt: String,
        jsonMode: Boolean,
        ultraFast: Boolean,
        client: OkHttpClient
    ): String {
        val apiKey = keyStore.groqApiKey.trim()
        require(apiKey.isNotBlank()) { "Groq API key not configured" }

        val models = if (ultraFast) {
            listOf("llama-3.1-8b-instant", "llama-3.3-70b-versatile")
        } else {
            listOf("llama-3.3-70b-versatile", "llama-3.1-8b-instant")
        }
        var lastError = "Groq unavailable"

        for (model in models) {
            val bodyJson = JSONObject()
                .put("model", model)
                .put("temperature", 0.25)
                .put("messages", JSONArray()
                    .put(JSONObject().put("role", "system").put("content", systemPrompt))
                    .put(JSONObject().put("role", "user").put("content", userPrompt))
                )
            if (jsonMode) {
                bodyJson.put("response_format", JSONObject().put("type", "json_object"))
            }

            val request = Request.Builder()
                .url("https://api.groq.com/openai/v1/chat/completions")
                .addHeader("Authorization", "Bearer $apiKey")
                .post(bodyJson.toString().toRequestBody(jsonMediaType))
                .build()

            client.newCall(request).execute().use { resp ->
                val body = resp.body?.string().orEmpty()
                if (resp.isSuccessful) {
                    return JSONObject(body)
                        .getJSONArray("choices")
                        .getJSONObject(0)
                        .getJSONObject("message")
                        .getString("content")
                }
                lastError = "Groq ($model) HTTP ${resp.code}"
                if (resp.code !in listOf(404, 429, 500, 503)) {
                    error("$lastError: $body")
                }
            }
        }
        error(lastError)
    }

    private fun callGoogleTranslateFree(text: String, style: TranslationStyle, client: OkHttpClient): String {
        val targetLang = if (style == TranslationStyle.ENGLISH) "en" else "ar"
        val encoded = URLEncoder.encode(text, "UTF-8")

        val primary = runCatching {
            val url = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=$targetLang&dt=t&q=$encoded"
            val req = Request.Builder().url(url).addHeader("User-Agent", "Mozilla/5.0").build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) error("HTTP ${resp.code}")
                val sentences = JSONArray(resp.body?.string().orEmpty()).getJSONArray(0)
                buildString {
                    for (i in 0 until sentences.length()) {
                        append(sentences.optJSONArray(i)?.optString(0).orEmpty())
                    }
                }.trim()
            }
        }
        if (primary.isSuccess && primary.getOrNull()?.isNotBlank() == true) {
            return primary.getOrThrow()
        }

        val backupUrl = "https://clients5.google.com/translate_a/t?client=dict-chrome-ex&sl=auto&tl=$targetLang&q=$encoded"
        val backupReq = Request.Builder().url(backupUrl).addHeader("User-Agent", "Mozilla/5.0").build()
        client.newCall(backupReq).execute().use { resp ->
            val body = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) error("Google Translate HTTP ${resp.code}")
            val arr = JSONArray(body)
            val first = arr.opt(0)
            return when (first) {
                is JSONArray -> first.optString(0, text)
                is String -> first
                else -> text
            }.trim().ifBlank { text }
        }
    }

    private fun callOpenAi(systemPrompt: String, userPrompt: String, jsonMode: Boolean, client: OkHttpClient): String {
        val apiKey = keyStore.openAiApiKey.trim()
        require(apiKey.isNotBlank()) { "OpenAI API key not configured" }

        val bodyJson = JSONObject()
            .put("model", "gpt-4o-mini")
            .put("temperature", 0.25)
            .put("messages", JSONArray()
                .put(JSONObject().put("role", "system").put("content", systemPrompt))
                .put(JSONObject().put("role", "user").put("content", userPrompt))
            )
        if (jsonMode) {
            bodyJson.put("response_format", JSONObject().put("type", "json_object"))
        }

        val request = Request.Builder()
            .url("https://api.openai.com/v1/chat/completions")
            .addHeader("Authorization", "Bearer $apiKey")
            .post(bodyJson.toString().toRequestBody(jsonMediaType))
            .build()

        client.newCall(request).execute().use { resp ->
            val body = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) error("OpenAI HTTP ${resp.code}: $body")
            return JSONObject(body)
                .getJSONArray("choices")
                .getJSONObject(0)
                .getJSONObject("message")
                .getString("content")
        }
    }

    private fun extractJsonObject(raw: String): String {
        val start = raw.indexOf('{')
        val end = raw.lastIndexOf('}')
        return if (start != -1 && end > start) raw.substring(start, end + 1) else raw
    }

    private fun hashKey(input: String): String =
        MessageDigest.getInstance("SHA-256")
            .digest(input.toByteArray())
            .joinToString("") { "%02x".format(it) }
}
