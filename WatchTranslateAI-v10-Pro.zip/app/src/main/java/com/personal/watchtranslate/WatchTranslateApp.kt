package com.personal.watchtranslate

import android.app.Application

class WatchTranslateApp : Application()
