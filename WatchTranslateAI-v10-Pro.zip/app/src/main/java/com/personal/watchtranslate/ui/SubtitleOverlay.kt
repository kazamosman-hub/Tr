package com.personal.watchtranslate.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.personal.watchtranslate.data.model.SubtitleCue
import com.personal.watchtranslate.data.model.SubtitleExplanation
import com.personal.watchtranslate.data.model.SubtitleStyleConfig
import com.personal.watchtranslate.ui.theme.*

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun SubtitleOverlay(
    activeCue: SubtitleCue?,
    style: SubtitleStyleConfig,
    onDragVerticalBias: (Float) -> Unit,
    onLongPressCue: (SubtitleCue) -> Unit,
    modifier: Modifier = Modifier
) {
    val textColor = if (style.useYellowText) Color(0xFFFFE55C) else Color(style.textColorHex)
    val density = LocalDensity.current

    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        val screenHeightPx = with(density) { maxHeight.toPx().coerceAtLeast(1f) }
        val clampedBias = style.verticalPositionBias.coerceIn(0.12f, 0.90f)
        val latestBias by rememberUpdatedState(clampedBias)
        val topPadding = (maxHeight * clampedBias) - 52.dp

        Box(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = topPadding.coerceAtLeast(12.dp), start = 16.dp, end = 16.dp)
                .then(
                    if (activeCue != null) {
                        Modifier.pointerInput(screenHeightPx) {
                            detectVerticalDragGestures { change, dragAmount ->
                                change.consume()
                                val deltaBias = dragAmount / screenHeightPx
                                onDragVerticalBias((latestBias + deltaBias).coerceIn(0.12f, 0.90f))
                            }
                        }
                    } else Modifier
                )
        ) {
            AnimatedContent(
                targetState = activeCue,
                transitionSpec = {
                    fadeIn(animationSpec = tween(130)) togetherWith fadeOut(animationSpec = tween(160))
                },
                label = "NetflixSubtitleTransition"
            ) { cue ->
                if (cue != null) {
                    val containerModifier = if (style.netflixStyle) {
                        Modifier
                            .combinedClickable(
                                onClick = {},
                                onLongClick = { onLongPressCue(cue) }
                            )
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    } else {
                        Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color.Black.copy(alpha = style.bgOpacity))
                            .combinedClickable(
                                onClick = {},
                                onLongClick = { onLongPressCue(cue) }
                            )
                            .padding(horizontal = 16.dp, vertical = 10.dp)
                    }

                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = containerModifier
                    ) {
                        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                            if (style.netflixStyle) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(
                                        text = cue.translatedText,
                                        color = Color.Black,
                                        fontSize = style.fontSizeSp.sp,
                                        lineHeight = (style.fontSizeSp * 1.38f).sp,
                                        fontWeight = FontWeight.Bold,
                                        textAlign = TextAlign.Center,
                                        style = TextStyle(
                                            drawStyle = Stroke(
                                                width = 6.5f,
                                                join = StrokeJoin.Round
                                            )
                                        )
                                    )
                                    Text(
                                        text = cue.translatedText,
                                        color = textColor,
                                        fontSize = style.fontSizeSp.sp,
                                        lineHeight = (style.fontSizeSp * 1.38f).sp,
                                        fontWeight = FontWeight.Bold,
                                        textAlign = TextAlign.Center,
                                        style = TextStyle(
                                            shadow = Shadow(
                                                color = Color.Black.copy(alpha = 0.92f),
                                                offset = Offset(2f, 3f),
                                                blurRadius = 7f
                                            )
                                        )
                                    )
                                }
                            } else {
                                Text(
                                    text = cue.translatedText,
                                    color = textColor,
                                    fontSize = style.fontSizeSp.sp,
                                    lineHeight = (style.fontSizeSp * 1.36f).sp,
                                    fontWeight = FontWeight.SemiBold,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }

                        if (style.showOriginalText && cue.sourceText.isNotBlank()) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = cue.sourceText,
                                color = if (style.netflixStyle) Color.White.copy(alpha = 0.88f) else MutedSlate,
                                fontSize = (style.fontSizeSp * 0.65f).sp,
                                textAlign = TextAlign.Center,
                                style = if (style.netflixStyle) {
                                    TextStyle(
                                        shadow = Shadow(
                                            color = Color.Black,
                                            offset = Offset(1f, 2f),
                                            blurRadius = 5f
                                        )
                                    )
                                } else TextStyle.Default
                            )
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiExplanationBottomSheet(
    isLoading: Boolean,
    explanation: SubtitleExplanation?,
    onDismiss: () -> Unit
) {
    if (!isLoading && explanation == null) return

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = CharcoalSurface,
        contentColor = SoftWhite
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp)
                .navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "شرح الجملة بالذكاء الاصطناعي",
                style = MaterialTheme.typography.titleMedium,
                color = ElectricPurple,
                fontWeight = FontWeight.Bold
            )

            if (isLoading) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.padding(vertical = 24.dp)
                ) {
                    CircularProgressIndicator(color = ElectricPurple, modifier = Modifier.size(22.dp))
                    Text("جاري تحليل المعنى والتعبيرات في سياق المشهد...", color = MutedSlate)
                }
            } else if (explanation != null) {
                Surface(color = ElevatedCharcoal, shape = RoundedCornerShape(12.dp)) {
                    Column(modifier = Modifier.fillMaxWidth().padding(14.dp)) {
                        Text(explanation.original, color = SoftWhite, fontWeight = FontWeight.Medium)
                        Spacer(Modifier.height(6.dp))
                        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                            Text(
                                explanation.translation,
                                color = VividBlue,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }

                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    ExplanationBlock("المعنى في السياق", explanation.meaningInContext)
                    ExplanationBlock("التعبيرات والسخرية", explanation.slangOrIdiomNotes)
                    ExplanationBlock("بالعربي السينمائي الطبيعي", explanation.naturalArabicVersion)
                    if (explanation.alternatives.isNotEmpty()) {
                        ExplanationBlock("صياغات بديلة", explanation.alternatives.joinToString("\n• ", prefix = "• "))
                    }
                }
                ExplanationBlock("النطق", explanation.pronunciationGuide)
                Spacer(Modifier.height(8.dp))
            }
        }
    }
}

@Composable
private fun ExplanationBlock(label: String, content: String) {
    if (content.isBlank()) return
    Column(modifier = Modifier.fillMaxWidth()) {
        Text(label, color = MutedSlate, style = MaterialTheme.typography.labelMedium)
        Spacer(Modifier.height(2.dp))
        Text(content, color = SoftWhite, style = MaterialTheme.typography.bodyMedium)
    }
}
