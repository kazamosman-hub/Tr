package com.personal.watchtranslate.ai

import com.personal.watchtranslate.audio.AudioCaptureService
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import okhttp3.*
import okio.ByteString.Companion.toByteString
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class RecognizedSpeechSegment(
    val text: String,
    val startOffsetMs: Long,
    val endOffsetMs: Long,
    val isFinal: Boolean,
    val speechFinal: Boolean,
    val detectedLanguage: String?,
    val speakerId: Int?
)

enum class SttConnectionState { DISCONNECTED, CONNECTING, CONNECTED, RECONNECTING }

class DeepgramStreamingSttEngine(
    private val httpClient: OkHttpClient = OkHttpClient.Builder()
        .pingInterval(15, TimeUnit.SECONDS)
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .build()
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    @Volatile private var webSocket: WebSocket? = null
    @Volatile private var streamStartEpochMs: Long = 0L
    @Volatile private var isManuallyStopped: Boolean = true
    @Volatile private var activeApiKey: String = ""
    @Volatile private var activeLanguage: String = "multi"
    @Volatile private var activeEndpointingMs: Int = 180
    @Volatile private var lastAudioSentEpochMs: Long = 0L
    @Volatile private var reconnectAttempt: Int = 0

    private var keepAliveJob: Job? = null
    private var reconnectJob: Job? = null

    private val _segments = MutableSharedFlow<RecognizedSpeechSegment>(extraBufferCapacity = 96)
    val segments = _segments.asSharedFlow()

    private val _utteranceEnded = MutableSharedFlow<Unit>(extraBufferCapacity = 16)
    val utteranceEnded = _utteranceEnded.asSharedFlow()

    private val _errors = MutableSharedFlow<String>(extraBufferCapacity = 16)
    val errors = _errors.asSharedFlow()

    private val _connectionState = MutableStateFlow(SttConnectionState.DISCONNECTED)
    val connectionState = _connectionState.asStateFlow()

    fun start(apiKey: String, languageCode: String = "multi", ultraFast: Boolean = true) {
        stopInternal(manual = false)
        activeApiKey = apiKey.trim()
        activeLanguage = languageCode.ifBlank { "multi" }
        activeEndpointingMs = if (ultraFast) 180 else 320
        isManuallyStopped = false
        reconnectAttempt = 0
        streamStartEpochMs = System.currentTimeMillis()
        connectWebSocket()
        startKeepAliveLoop()
    }

    private fun connectWebSocket() {
        if (isManuallyStopped || activeApiKey.isBlank()) return
        _connectionState.value = if (reconnectAttempt == 0) SttConnectionState.CONNECTING else SttConnectionState.RECONNECTING

        val url = "wss://api.deepgram.com/v1/listen" +
            "?model=nova-2" +
            "&language=$activeLanguage" +
            "&encoding=linear16" +
            "&sample_rate=${AudioCaptureService.SAMPLE_RATE}" +
            "&channels=1" +
            "&punctuate=true" +
            "&smart_format=true" +
            "&diarize=true" +
            "&interim_results=true" +
            "&utterance_end_ms=1000" +
            "&endpointing=$activeEndpointingMs"

        val request = Request.Builder()
            .url(url)
            .addHeader("Authorization", "Token $activeApiKey")
            .build()

        webSocket = httpClient.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(ws: WebSocket, response: Response) {
                reconnectAttempt = 0
                lastAudioSentEpochMs = System.currentTimeMillis()
                _connectionState.value = SttConnectionState.CONNECTED
            }

            override fun onMessage(ws: WebSocket, text: String) {
                parseDeepgramMessage(text)
            }

            override fun onClosing(ws: WebSocket, code: Int, reason: String) {
                ws.close(1000, null)
            }

            override fun onClosed(ws: WebSocket, code: Int, reason: String) {
                if (!isManuallyStopped) {
                    scheduleReconnect("Deepgram closed ($code)")
                } else {
                    _connectionState.value = SttConnectionState.DISCONNECTED
                }
            }

            override fun onFailure(ws: WebSocket, t: Throwable, response: Response?) {
                if (isManuallyStopped) {
                    _connectionState.value = SttConnectionState.DISCONNECTED
                    return
                }
                val codeInfo = response?.let { "HTTP ${it.code}" } ?: ""
                val errMsg = listOf("Deepgram", codeInfo, t.localizedMessage.orEmpty())
                    .filter { it.isNotBlank() }
                    .joinToString(" - ")

                if (response?.code == 401 || response?.code == 403) {
                    _connectionState.value = SttConnectionState.DISCONNECTED
                    _errors.tryEmit("مفتاح Deepgram غير صحيح (${response.code})")
                    return
                }
                scheduleReconnect(errMsg)
            }
        })
    }

    private fun scheduleReconnect(reason: String) {
        if (isManuallyStopped) return
        _connectionState.value = SttConnectionState.RECONNECTING
        reconnectAttempt++
        if (reconnectAttempt >= 3) {
            _errors.tryEmit(reason)
        }
        val delayMs = when (reconnectAttempt) {
            1 -> 1000L
            2 -> 2500L
            else -> 4500L
        }
        reconnectJob?.cancel()
        reconnectJob = scope.launch {
            delay(delayMs)
            if (!isManuallyStopped) {
                runCatching { webSocket?.cancel() }
                connectWebSocket()
            }
        }
    }

    private fun startKeepAliveLoop() {
        keepAliveJob?.cancel()
        keepAliveJob = scope.launch {
            while (isActive && !isManuallyStopped) {
                delay(4500L)
                val ws = webSocket
                if (ws != null && _connectionState.value == SttConnectionState.CONNECTED) {
                    val idleMs = System.currentTimeMillis() - lastAudioSentEpochMs
                    if (idleMs >= 3500L) {
                        ws.send("{\"type\":\"KeepAlive\"}")
                    }
                }
            }
        }
    }

    fun sendPcmChunk(pcm16Bytes: ByteArray) {
        val ws = webSocket ?: return
        if (_connectionState.value == SttConnectionState.CONNECTED) {
            lastAudioSentEpochMs = System.currentTimeMillis()
            ws.send(pcm16Bytes.toByteString(0, pcm16Bytes.size))
        }
    }

    fun getStreamStartEpochMs(): Long = streamStartEpochMs

    fun stop() {
        stopInternal(manual = true)
    }

    private fun stopInternal(manual: Boolean) {
        isManuallyStopped = manual
        keepAliveJob?.cancel()
        keepAliveJob = null
        reconnectJob?.cancel()
        reconnectJob = null
        runCatching {
            webSocket?.send("{\"type\":\"CloseStream\"}")
            webSocket?.close(1000, "Session ended")
        }
        webSocket = null
        if (manual) {
            _connectionState.value = SttConnectionState.DISCONNECTED
        }
    }

    private fun parseDeepgramMessage(rawJson: String) {
        runCatching {
            val root = JSONObject(rawJson)
            val msgType = root.optString("type")
            if (msgType == "UtteranceEnd") {
                _utteranceEnded.tryEmit(Unit)
                return
            }
            if (msgType != "Results") return

            val isFinal = root.optBoolean("is_final", false)
            val speechFinal = root.optBoolean("speech_final", false)
            val channel = root.optJSONObject("channel") ?: return
            val alternatives = channel.optJSONArray("alternatives") ?: return
            if (alternatives.length() == 0) return

            val alt = alternatives.getJSONObject(0)
            val transcript = alt.optString("transcript", "").trim()
            if (transcript.isEmpty()) {
                if (speechFinal) _utteranceEnded.tryEmit(Unit)
                return
            }

            val words = alt.optJSONArray("words")
            val startSec: Double
            val endSec: Double
            var speaker: Int? = null

            if (words != null && words.length() > 0) {
                val first = words.getJSONObject(0)
                val last = words.getJSONObject(words.length() - 1)
                startSec = first.optDouble("start", root.optDouble("start", 0.0))
                endSec = last.optDouble("end", startSec + root.optDouble("duration", 1.8))
                if (first.has("speaker")) speaker = first.optInt("speaker")
            } else {
                startSec = root.optDouble("start", 0.0)
                endSec = startSec + root.optDouble("duration", 1.8)
            }

            val lang = alt.optJSONArray("languages")?.optString(0)?.ifBlank { null }

            _segments.tryEmit(
                RecognizedSpeechSegment(
                    text = transcript,
                    startOffsetMs = (startSec * 1000).toLong(),
                    endOffsetMs = (endSec * 1000).toLong(),
                    isFinal = isFinal,
                    speechFinal = speechFinal,
                    detectedLanguage = lang,
                    speakerId = speaker
                )
            )
        }
    }
}
