package com.personal.watchtranslate.ai

import com.personal.watchtranslate.data.model.SubtitleCue
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.abs

class SubtitleSyncEngine {
    private val captionCues = ArrayList<SubtitleCue>()

    private val _activeCue = MutableStateFlow<SubtitleCue?>(null)
    val activeCue = _activeCue.asStateFlow()

    @Volatile private var delayOffsetMs: Long = 0L
    @Volatile private var speedMultiplier: Float = 1.0f
    @Volatile private var liveAnchorEpochMs: Long = 0L
    @Volatile private var liveAnchorVideoMs: Long = 0L
    @Volatile private var lastLiveCueShownAtEpochMs: Long = 0L
    @Volatile private var lastLiveCueDurationMs: Long = 3400L
    @Volatile private var latestDisplayedLiveSeq: Long = 0L
    @Volatile private var isLiveModeActive: Boolean = false

    fun updateTimingControls(delayMs: Long, speed: Float) {
        delayOffsetMs = delayMs
        speedMultiplier = speed.coerceIn(0.5f, 2.0f)
    }

    fun resetSync() {
        delayOffsetMs = 0L
        speedMultiplier = 1.0f
    }

    fun anchorLiveStream(streamStartEpochMs: Long, videoTimeAtStartMs: Long) {
        liveAnchorEpochMs = streamStartEpochMs
        liveAnchorVideoMs = videoTimeAtStartMs
        isLiveModeActive = true
    }

    private fun computeSmartReadingDurationMs(text: String, rawDurationMs: Long): Long {
        val charCount = text.replace("\n", "").length
        val cpsMs = ((charCount / 18.0) * 1000.0).toLong() + 750L
        val target = maxOf(rawDurationMs, cpsMs)
        val minMs = (1450f / speedMultiplier).toLong()
        val maxMs = (5400f / speedMultiplier).toLong()
        return target.coerceIn(minMs, maxMs)
    }

    fun formatNetflixLines(rawText: String): String {
        val clean = rawText.trim().replace(Regex("[ \t]+"), " ")
        if (clean.contains("\n")) {
            val parts = clean.lines().map { it.trim() }.filter { it.isNotEmpty() }.take(2)
            return parts.joinToString("\n")
        }
        if (clean.length <= 38) return clean
        val words = clean.split(" ")
        if (words.size < 4) return clean

        val targetMid = clean.length / 2
        var bestSplitIdx = words.size / 2
        var bestDiff = Int.MAX_VALUE
        var runningLen = 0
        for (i in 0 until words.size - 1) {
            runningLen += words[i].length + (if (i > 0) 1 else 0)
            val diff = abs(runningLen - targetMid)
            if (diff < bestDiff) {
                bestDiff = diff
                bestSplitIdx = i + 1
            }
        }
        val line1 = words.subList(0, bestSplitIdx).joinToString(" ")
        val line2 = words.subList(bestSplitIdx, words.size).joinToString(" ")
        return "$line1\n$line2"
    }

    fun addCaptionCue(cue: SubtitleCue) {
        isLiveModeActive = false
        val formattedText = formatNetflixLines(cue.translatedText)
        val normalized = cue.copy(
            translatedText = formattedText,
            isFromWebsiteCaption = true
        )

        synchronized(captionCues) {
            for (i in captionCues.indices.reversed()) {
                val prev = captionCues[i]
                if (prev.startMs < normalized.startMs && prev.endMs > normalized.startMs) {
                    captionCues[i] = prev.copy(endMs = normalized.startMs - 30L)
                    break
                }
            }
            captionCues.removeAll { abs(it.startMs - normalized.startMs) < 120L }
            captionCues.add(normalized)
            captionCues.sortBy { it.startMs }
            if (captionCues.size > 2000) {
                captionCues.removeAt(0)
            }
        }
    }

    fun publishLiveCue(
        sequenceId: Long,
        sttStartOffsetMs: Long,
        sttEndOffsetMs: Long,
        sourceText: String,
        translatedText: String,
        speakerLabel: String?,
        currentVideoTimeMs: Long
    ) {
        if (sequenceId < latestDisplayedLiveSeq) return
        latestDisplayedLiveSeq = sequenceId
        isLiveModeActive = true

        val formatted = formatNetflixLines(translatedText)
        val rawDur = (sttEndOffsetMs - sttStartOffsetMs).coerceIn(1000L, 4500L)
        val duration = (computeSmartReadingDurationMs(formatted, rawDur) + delayOffsetMs).coerceIn(1200L, 6500L)
        val effectiveStart = if (currentVideoTimeMs > 0L) currentVideoTimeMs else sttStartOffsetMs

        val cue = SubtitleCue(
            startMs = effectiveStart,
            endMs = effectiveStart + duration,
            sourceText = sourceText,
            translatedText = formatted,
            speakerLabel = speakerLabel,
            isFromWebsiteCaption = false
        )
        lastLiveCueShownAtEpochMs = System.currentTimeMillis()
        lastLiveCueDurationMs = duration
        _activeCue.value = cue
    }

    fun onVideoTimeUpdate(videoTimeMs: Long, playbackRate: Float) {
        if (isLiveModeActive && captionCues.isEmpty()) {
            onWallClockTick()
            return
        }

        val effectiveTimeMs = videoTimeMs - delayOffsetMs
        val rate = playbackRate.coerceAtLeast(0.5f) * speedMultiplier
        val match = synchronized(captionCues) {
            captionCues.lastOrNull { cue ->
                val rawDur = (cue.endMs - cue.startMs).coerceAtLeast(800L)
                val adjustedEnd = cue.startMs + (rawDur / rate).toLong()
                effectiveTimeMs in cue.startMs..adjustedEnd
            }
        }
        if (match != null) {
            _activeCue.value = match
        } else if (!isLiveModeActive) {
            _activeCue.value = null
        }
    }

    fun onWallClockTick() {
        val current = _activeCue.value ?: return
        if (!current.isFromWebsiteCaption) {
            if (System.currentTimeMillis() - lastLiveCueShownAtEpochMs > lastLiveCueDurationMs) {
                _activeCue.value = null
            }
        }
    }

    fun onAudioSilenceDetected() {
        val current = _activeCue.value ?: return
        if (!current.isFromWebsiteCaption) {
            val elapsed = System.currentTimeMillis() - lastLiveCueShownAtEpochMs
            if (elapsed >= 1650L) {
                _activeCue.value = null
            }
        }
    }

    fun onSeek(newVideoTimeMs: Long) {
        if (isLiveModeActive && captionCues.isEmpty()) {
            _activeCue.value = null
            liveAnchorEpochMs = System.currentTimeMillis()
            liveAnchorVideoMs = newVideoTimeMs
            return
        }
        val effectiveTimeMs = newVideoTimeMs - delayOffsetMs
        val match = synchronized(captionCues) {
            captionCues.lastOrNull { effectiveTimeMs in it.startMs..it.endMs }
        }
        _activeCue.value = match
    }

    fun clearAll() {
        synchronized(captionCues) {
            captionCues.clear()
        }
        latestDisplayedLiveSeq = 0L
        _activeCue.value = null
    }
}
