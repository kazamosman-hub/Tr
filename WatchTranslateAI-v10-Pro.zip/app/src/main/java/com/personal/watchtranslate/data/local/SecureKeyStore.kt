package com.personal.watchtranslate.data.local

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.personal.watchtranslate.data.model.SourceLanguage
import com.personal.watchtranslate.data.model.SubtitleStyleConfig
import com.personal.watchtranslate.data.model.TranslationMode
import com.personal.watchtranslate.data.model.TranslationStyle

enum class LlmProvider(val label: String) {
    GROQ("Groq (سريع)"),
    GEMINI("Gemini"),
    GOOGLE_FREE("Google (مجاني)"),
    OPENAI("OpenAI")
}

class SecureKeyStore(context: Context) {
    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val prefs = EncryptedSharedPreferences.create(
        context,
        "watchtranslate_secure_keys",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    private val uiPrefs = context.getSharedPreferences("watchtranslate_ui_prefs", Context.MODE_PRIVATE)

    var llmProvider: LlmProvider
        get() = runCatching {
            val saved = prefs.getString("llm_provider", null)
            if (saved != null) LlmProvider.valueOf(saved)
            else if (groqApiKey.isNotBlank()) LlmProvider.GROQ
            else if (geminiApiKey.isNotBlank()) LlmProvider.GEMINI
            else LlmProvider.GOOGLE_FREE
        }.getOrDefault(LlmProvider.GOOGLE_FREE)
        set(value) = prefs.edit().putString("llm_provider", value.name).apply()

    var geminiApiKey: String
        get() = prefs.getString("gemini_key", "") ?: ""
        set(value) = prefs.edit().putString("gemini_key", value.trim()).apply()

    var groqApiKey: String
        get() = prefs.getString("groq_key", "") ?: ""
        set(value) = prefs.edit().putString("groq_key", value.trim()).apply()

    var openAiApiKey: String
        get() = prefs.getString("openai_key", "") ?: ""
        set(value) = prefs.edit().putString("openai_key", value.trim()).apply()

    var deepgramApiKey: String
        get() = prefs.getString("deepgram_key", "") ?: ""
        set(value) = prefs.edit().putString("deepgram_key", value.trim()).apply()

    var savedTranslationStyle: TranslationStyle
        get() = runCatching {
            TranslationStyle.valueOf(uiPrefs.getString("tr_style", TranslationStyle.NATURAL_ARABIC.name) ?: TranslationStyle.NATURAL_ARABIC.name)
        }.getOrDefault(TranslationStyle.NATURAL_ARABIC)
        set(value) = uiPrefs.edit().putString("tr_style", value.name).apply()

    var savedTranslationMode: TranslationMode
        get() = runCatching {
            TranslationMode.valueOf(uiPrefs.getString("tr_mode", TranslationMode.AUTO.name) ?: TranslationMode.AUTO.name)
        }.getOrDefault(TranslationMode.AUTO)
        set(value) = uiPrefs.edit().putString("tr_mode", value.name).apply()

    var savedSourceLanguage: SourceLanguage
        get() = runCatching {
            SourceLanguage.valueOf(uiPrefs.getString("src_lang", SourceLanguage.AUTO.name) ?: SourceLanguage.AUTO.name)
        }.getOrDefault(SourceLanguage.AUTO)
        set(value) = uiPrefs.edit().putString("src_lang", value.name).apply()

    fun loadSubtitleStyle(): SubtitleStyleConfig = SubtitleStyleConfig(
        fontSizeSp = uiPrefs.getFloat("sub_font_size", 21f).coerceIn(14f, 34f),
        verticalPositionBias = uiPrefs.getFloat("sub_pos_bias", 0.85f).coerceIn(0.12f, 0.90f),
        showOriginalText = uiPrefs.getBoolean("sub_show_src", false),
        netflixStyle = uiPrefs.getBoolean("sub_netflix", true),
        useYellowText = uiPrefs.getBoolean("sub_yellow", false),
        ultraFastSync = uiPrefs.getBoolean("sub_ultrafast", true)
    )

    fun saveSubtitleStyle(cfg: SubtitleStyleConfig) {
        uiPrefs.edit()
            .putFloat("sub_font_size", cfg.fontSizeSp)
            .putFloat("sub_pos_bias", cfg.verticalPositionBias)
            .putBoolean("sub_show_src", cfg.showOriginalText)
            .putBoolean("sub_netflix", cfg.netflixStyle)
            .putBoolean("sub_yellow", cfg.useYellowText)
            .putBoolean("sub_ultrafast", cfg.ultraFastSync)
            .apply()
    }

    fun hasTranslationKey(): Boolean = when (llmProvider) {
        LlmProvider.GOOGLE_FREE -> true
        LlmProvider.GEMINI -> geminiApiKey.isNotBlank()
        LlmProvider.GROQ -> groqApiKey.isNotBlank()
        LlmProvider.OPENAI -> openAiApiKey.isNotBlank()
    }

    fun hasLiveSttKey(): Boolean = deepgramApiKey.isNotBlank()
}
