package com.personal.watchtranslate.browser

import android.content.Context
import android.net.Uri
import android.webkit.WebResourceResponse
import com.personal.watchtranslate.data.local.BrowserDao
import com.personal.watchtranslate.data.model.AdBlockRuleEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.ByteArrayInputStream
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger

class AdBlockerEngine(
    private val context: Context,
    private val dao: BrowserDao,
    private val scope: CoroutineScope
) {
    private val blockedDomains = ConcurrentHashMap.newKeySet<String>()
    private val customBlockedDomains = ConcurrentHashMap.newKeySet<String>()
    private val whitelistedSites = ConcurrentHashMap.newKeySet<String>()
    private val httpClient = OkHttpClient()

    private val _isEnabled = MutableStateFlow(true)
    val isEnabled = _isEnabled.asStateFlow()

    private val _totalBlocked = MutableStateFlow(0)
    val totalBlocked = _totalBlocked.asStateFlow()

    private val counter = AtomicInteger(0)

    private val blockedUrlPatterns = listOf(
        "/pagead/", "/popunder", "popunder.js", "/adserver", "vast.xml",
        "vpaid", "/ads/banner", "ad_banner", "doubleclick", "googlesyndication",
        "show_ads.js", "adsbygoogle", "prebid", "popads", "adsterra", "propeller",
        "clickadu", "exoclick", "monetag", "admaven", "hilltopads", "juicyads",
        "/advert", "/banner_ad", "ad_click", "track_click", "1xbet", "melbet",
        "linebet", "mostbet", "betwinner", "casino", "popup.js", "pop.js"
    )

    init {
        loadBundledBlocklist()
        scope.launch(Dispatchers.IO) {
            dao.observeAdBlockRules().collect { rules ->
                whitelistedSites.clear()
                customBlockedDomains.clear()
                rules.forEach { rule ->
                    if (rule.isWhitelist) whitelistedSites.add(rule.domain.lowercase())
                    else customBlockedDomains.add(rule.domain.lowercase())
                }
            }
        }
    }

    private fun loadBundledBlocklist() {
        runCatching {
            context.assets.open("default_adblock_domains.txt").bufferedReader().useLines { lines ->
                lines.map { it.trim().lowercase() }
                    .filter { it.isNotEmpty() && !it.startsWith("#") }
                    .forEach { blockedDomains.add(it) }
            }
        }
    }

    fun setEnabled(enabled: Boolean) {
        _isEnabled.value = enabled
    }

    fun isSiteWhitelisted(pageUrl: String?): Boolean {
        val host = extractHost(pageUrl) ?: return false
        return matchesDomainSet(host, whitelistedSites)
    }

    fun toggleSiteWhitelist(pageUrl: String) {
        val host = extractHost(pageUrl) ?: return
        scope.launch(Dispatchers.IO) {
            if (whitelistedSites.contains(host)) {
                dao.deleteAdBlockRule(host)
            } else {
                dao.upsertAdBlockRule(AdBlockRuleEntity(domain = host, isWhitelist = true))
            }
        }
    }

    fun addCustomBlockedDomain(domain: String) {
        val clean = domain.trim().lowercase()
            .removePrefix("https://")
            .removePrefix("http://")
            .substringBefore("/")
        if (clean.contains(".")) {
            scope.launch(Dispatchers.IO) {
                dao.upsertAdBlockRule(AdBlockRuleEntity(domain = clean, isWhitelist = false))
            }
        }
    }

    suspend fun updateBlocklistFromUrl(
        listUrl: String = "https://pgl.yoyo.org/adservers/serverlist.php?hostformat=nohtml&showintro=0"
    ): Result<Int> {
        return runCatching {
            val req = Request.Builder().url(listUrl).build()
            httpClient.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) error("HTTP ${resp.code}")
                val body = resp.body?.string().orEmpty()
                var added = 0
                body.lineSequence().forEach { raw ->
                    val line = raw.trim().lowercase()
                    if (line.isNotEmpty() && !line.startsWith("#") && !line.startsWith("!")) {
                        val domain = line.removePrefix("0.0.0.0 ").removePrefix("127.0.0.1 ").trim()
                        if (domain.contains(".") && blockedDomains.add(domain)) added++
                    }
                }
                added
            }
        }
    }

    fun shouldBlockRequest(requestUrl: String, currentPageUrl: String?): Boolean {
        if (!_isEnabled.value) return false
        if (isSiteWhitelisted(currentPageUrl)) return false

        val reqHost = extractHost(requestUrl) ?: return false
        val pageHost = extractHost(currentPageUrl)
        val lowerUrl = requestUrl.lowercase()

        // Never break actual video streams or caption tracks
        if (lowerUrl.contains(".m3u8") || lowerUrl.contains(".mp4") ||
            lowerUrl.contains(".webm") || lowerUrl.contains(".ts?") ||
            lowerUrl.endsWith(".ts") || lowerUrl.contains(".m4s") ||
            lowerUrl.contains(".vtt") || lowerUrl.contains(".srt")
        ) {
            return false
        }

        val isSameOrigin = pageHost != null && (reqHost == pageHost || reqHost.endsWith(".$pageHost"))
        val domainBlocked = matchesDomainSet(reqHost, blockedDomains) ||
            matchesDomainSet(reqHost, customBlockedDomains)

        val patternBlocked = !isSameOrigin && blockedUrlPatterns.any { lowerUrl.contains(it) }

        val blocked = domainBlocked || patternBlocked
        if (blocked) {
            _totalBlocked.value = counter.incrementAndGet()
        }
        return blocked
    }

    fun shouldBlockPopupOrRedirect(targetUrl: String, currentPageUrl: String?, hasUserGesture: Boolean): Boolean {
        if (!_isEnabled.value || isSiteWhitelisted(currentPageUrl)) return false

        val lower = targetUrl.lowercase()
        // Block app-hijack schemes & ad-intent links
        if (lower.startsWith("intent:") || lower.startsWith("market:") ||
            lower.startsWith("tel:") || lower.startsWith("whatsapp:") ||
            lower.startsWith("tg:")
        ) {
            _totalBlocked.value = counter.incrementAndGet()
            return true
        }

        val targetHost = extractHost(targetUrl) ?: return true
        if (matchesDomainSet(targetHost, blockedDomains) || matchesDomainSet(targetHost, customBlockedDomains)) {
            _totalBlocked.value = counter.incrementAndGet()
            return true
        }

        val currentHost = extractHost(currentPageUrl)
        if (currentHost != null && !targetHost.endsWith(currentHost)) {
            if (!hasUserGesture) {
                _totalBlocked.value = counter.incrementAndGet()
                return true
            }
            if (lower.contains("click") || lower.contains("redirect") || lower.contains("promo") ||
                lower.contains("offer") || lower.contains("bet") || lower.contains("casino") ||
                lower.contains("aff") || lower.contains("bonus") || lower.contains("download-app")
            ) {
                _totalBlocked.value = counter.incrementAndGet()
                return true
            }
        }
        return false
    }

    fun emptyBlockedResponse(): WebResourceResponse =
        WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))

    /** Aggressive ad-blocker JS: kills popups, transparent click-hijack overlays, betting banners & dynamic ad iframes. */
    val cosmeticHideCssJs: String = """
        (function(){
          if(!window.__wtAdShieldInstalled){
            window.__wtAdShieldInstalled = true;
            window.open = function() { return null; };

            // Block suspicious target=_blank ad hijacks while preserving normal video links
            document.addEventListener('click', function(e) {
              try {
                const a = e.target && e.target.closest ? e.target.closest('a') : null;
                if (a && a.href) {
                  const href = a.href.toLowerCase();
                  const bad = /(1xbet|melbet|linebet|mostbet|bet365|casino|popads|adsterra|propeller|clickadu|monetag|exoclick|redirect|promo)/i;
                  if (bad.test(href)) {
                    e.preventDefault();
                    e.stopPropagation();
                    return false;
                  }
                }
              } catch(err) {}
            }, true);

            // Strip invisible click-jacking overlays placed over video players
            const nukeOverlays = () => {
              try {
                const vw = window.innerWidth || 360;
                const vh = window.innerHeight || 640;
                document.querySelectorAll('div, a, section').forEach(el => {
                  if (el.querySelector && el.querySelector('video')) return;
                  const st = window.getComputedStyle(el);
                  if (!st) return;
                  const z = parseInt(st.zIndex || '0', 10);
                  if ((st.position === 'fixed' || st.position === 'absolute') && z >= 999) {
                    const r = el.getBoundingClientRect();
                    const coversLargeArea = (r.width >= vw * 0.7 && r.height >= vh * 0.45);
                    const isInvisibleTrap = (parseFloat(st.opacity) < 0.15 || st.backgroundColor === 'rgba(0, 0, 0, 0)' || st.backgroundColor === 'transparent');
                    if (coversLargeArea && isInvisibleTrap && (el.innerText || '').trim().length < 20) {
                      el.style.setProperty('display', 'none', 'important');
                      el.style.setProperty('pointer-events', 'none', 'important');
                    }
                  }
                });
              } catch(err) {}
            };

            let nukeTimer = null;
            const scheduleNuke = () => {
              if (nukeTimer) return;
              nukeTimer = setTimeout(() => { nukeTimer = null; nukeOverlays(); }, 450);
            };
            nukeOverlays();
            if (document.documentElement) {
              new MutationObserver(scheduleNuke).observe(document.documentElement, { childList: true, subtree: true });
            }
          }

          if(document.getElementById('wt-cosmetic-css')) return;
          const style = document.createElement('style');
          style.id = 'wt-cosmetic-css';
          style.textContent = `
            ins.adsbygoogle, [id^="google_ads_iframe"], .ad-banner, .pop-overlay,
            .ads-container, .ad-wrapper, .floating-ad, .sticky-ad, .sticky-footer-ad,
            .ad-box, .banner-ads, .ads-block, .advertisement,
            div[class*="ad-container"]:not(:has(video)),
            div[id*="ad-overlay"]:not(:has(video)),
            div[class*="ads-"]:not(:has(video)),
            iframe[src*="doubleclick"], iframe[src*="adsterra"], iframe[src*="exoclick"],
            iframe[src*="propeller"], iframe[src*="clickadu"], iframe[src*="popads"],
            a[href*="1xbet"], a[href*="melbet"], a[href*="bet365"], a[href*="linebet"], a[href*="mostbet"] {
              display: none !important;
              visibility: hidden !important;
              pointer-events: none !important;
              height: 0 !important;
              max-height: 0 !important;
            }
          `;
          (document.head || document.documentElement).appendChild(style);
        })();
    """.trimIndent()

    private fun extractHost(url: String?): String? =
        runCatching { Uri.parse(url).host?.lowercase()?.removePrefix("www.") }.getOrNull()

    private fun matchesDomainSet(host: String, set: Set<String>): Boolean {
        var current = host
        while (current.contains(".")) {
            if (set.contains(current)) return true
            current = current.substringAfter(".")
        }
        return false
    }
}
