package com.personal.watchtranslate.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.personal.watchtranslate.data.model.*
import com.personal.watchtranslate.ui.theme.*
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

@Composable
fun FloatingTranslationControls(
    isEnabled: Boolean,
    isPaused: Boolean,
    status: EngineStatus,
    errorDetail: String?,
    activeEngineInfo: String,
    audioLevel: Float,
    videoDetected: Boolean,
    currentStyle: TranslationStyle,
    sourceLanguage: SourceLanguage,
    subtitleStyle: SubtitleStyleConfig,
    hasActiveCue: Boolean,
    onStart: () -> Unit,
    onPauseToggle: () -> Unit,
    onStop: () -> Unit,
    onStyleSelected: (TranslationStyle) -> Unit,
    onSourceLanguageSelected: (SourceLanguage) -> Unit,
    onUpdateSubtitleStyle: ((SubtitleStyleConfig) -> SubtitleStyleConfig) -> Unit,
    onResetSync: () -> Unit,
    onLoadLocalSubtitle: () -> Unit,
    onExplainCurrent: () -> Unit,
    modifier: Modifier = Modifier
) {
    var expanded by remember { mutableStateOf(false) }
    var offsetX by remember { mutableFloatStateOf(20f) }
    var offsetY by remember { mutableFloatStateOf(120f) }
    var pillDimmed by remember { mutableStateOf(false) }

    LaunchedEffect(isEnabled, expanded, isPaused) {
        if (isEnabled && !expanded && !isPaused) {
            pillDimmed = false
            delay(4000L)
            pillDimmed = true
        } else {
            pillDimmed = false
        }
    }

    val pillAlpha by animateFloatAsState(
        targetValue = if (pillDimmed) 0.42f else 1f,
        label = "PillAlpha"
    )

    val density = LocalDensity.current

    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        val maxW = with(density) { maxWidth.toPx() }
        val maxH = with(density) { maxHeight.toPx() }
        val panelWidthPx = with(density) { (if (expanded) 316.dp else 130.dp).toPx() }
        val panelHeightPx = with(density) { (if (expanded) 420.dp else 46.dp).toPx() }

        val safeX = offsetX.coerceIn(8f, (maxW - panelWidthPx - 8f).coerceAtLeast(8f))
        val safeY = offsetY.coerceIn(16f, (maxH - panelHeightPx - 16f).coerceAtLeast(16f))

        Box(
            modifier = Modifier
                .offset { IntOffset(safeX.roundToInt(), safeY.roundToInt()) }
                .pointerInput(maxW, maxH, expanded) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        pillDimmed = false
                        offsetX = (offsetX.coerceIn(8f, (maxW - panelWidthPx - 8f).coerceAtLeast(8f)) + dragAmount.x)
                            .coerceIn(8f, (maxW - panelWidthPx - 8f).coerceAtLeast(8f))
                        offsetY = (offsetY.coerceIn(16f, (maxH - panelHeightPx - 16f).coerceAtLeast(16f)) + dragAmount.y)
                            .coerceIn(16f, (maxH - panelHeightPx - 16f).coerceAtLeast(16f))
                    }
                }
        ) {
            if (!expanded) {
                Surface(
                    onClick = {
                        pillDimmed = false
                        expanded = true
                    },
                    shape = CircleShape,
                    color = CharcoalSurface.copy(alpha = 0.92f),
                    shadowElevation = 8.dp,
                    modifier = Modifier.alpha(pillAlpha)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .background(
                                if (isEnabled && !isPaused) Brush.horizontalGradient(listOf(ElectricPurple, VividBlue))
                                else Brush.horizontalGradient(listOf(ElevatedCharcoal, ElevatedCharcoal))
                            )
                            .padding(horizontal = 13.dp, vertical = 9.dp),
                        horizontalArrangement = Arrangement.spacedBy(7.dp)
                    ) {
                        if (isEnabled && !isPaused && audioLevel > 0.04f) {
                            Box(
                                modifier = Modifier
                                    .size(7.dp)
                                    .clip(CircleShape)
                                    .background(SuccessGreen)
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Rounded.Translate,
                                contentDescription = "AI Translate",
                                tint = Color.White,
                                modifier = Modifier.size(17.dp)
                            )
                        }
                        Text(
                            text = when {
                                isEnabled && isPaused -> "متوقف"
                                isEnabled -> "AI Live"
                                videoDetected -> "ترجمة"
                                else -> "AI"
                            },
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            } else {
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = CharcoalSurface.copy(alpha = 0.97f),
                    shadowElevation = 14.dp,
                    modifier = Modifier
                        .width(314.dp)
                        .heightIn(max = maxHeight - 36.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .verticalScroll(rememberScrollState())
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(9.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(9.dp)
                                        .clip(CircleShape)
                                        .background(
                                            when {
                                                status.isError -> AlertAmber
                                                isEnabled && !isPaused -> SuccessGreen
                                                else -> MutedSlate
                                            }
                                        )
                                )
                                Text("WatchTranslate Pro", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            }
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                if (activeEngineInfo.isNotBlank()) {
                                    Surface(color = ElevatedCharcoal, shape = RoundedCornerShape(8.dp)) {
                                        Text(
                                            text = activeEngineInfo,
                                            fontSize = 10.sp,
                                            color = VividBlue,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                                IconButton(onClick = { expanded = false }, modifier = Modifier.size(28.dp)) {
                                    Icon(Icons.Rounded.Close, contentDescription = "Collapse", tint = MutedSlate)
                                }
                            }
                        }

                        Text(
                            text = if (status.isError && !errorDetail.isNullOrBlank()) "${status.message}\n$errorDetail" else status.message,
                            color = if (status.isError) AlertAmber else MutedSlate,
                            fontSize = 11.5.sp
                        )

                        if (isEnabled && !isPaused && status == EngineStatus.LIVE_AUDIO_ACTIVE) {
                            LinearProgressIndicator(
                                progress = { audioLevel.coerceIn(0.03f, 1f) },
                                color = SuccessGreen,
                                trackColor = ElevatedCharcoal,
                                modifier = Modifier.fillMaxWidth().height(3.dp).clip(CircleShape)
                            )
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                            if (!isEnabled) {
                                Button(
                                    onClick = {
                                        onStart()
                                        expanded = false
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = ElectricPurple),
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Icon(Icons.Rounded.PlayArrow, null, modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text("تشغيل الترجمة")
                                }
                            } else {
                                FilledTonalButton(
                                    onClick = onPauseToggle,
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Icon(if (isPaused) Icons.Rounded.PlayArrow else Icons.Rounded.Pause, null)
                                    Spacer(Modifier.width(4.dp))
                                    Text(if (isPaused) "استئناف" else "إيقاف مؤقت", fontSize = 12.sp)
                                }
                                OutlinedButton(
                                    onClick = onStop,
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Icon(Icons.Rounded.Stop, null)
                                    Spacer(Modifier.width(4.dp))
                                    Text("إنهاء", fontSize = 12.sp)
                                }
                            }
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                            TranslationStyle.entries.forEach { style ->
                                FilterChip(
                                    selected = style == currentStyle,
                                    onClick = { onStyleSelected(style) },
                                    label = {
                                        Text(
                                            when (style) {
                                                TranslationStyle.NATURAL_ARABIC -> "طبيعي"
                                                TranslationStyle.MSA -> "فصحى"
                                                TranslationStyle.ENGLISH -> "EN"
                                            },
                                            fontSize = 11.sp
                                        )
                                    },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }

                        Text("لغة الفيلم (لأدق تزامن)", fontSize = 11.sp, color = MutedSlate)
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(5.dp),
                            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())
                        ) {
                            SourceLanguage.entries.forEach { lang ->
                                FilterChip(
                                    selected = lang == sourceLanguage,
                                    onClick = { onSourceLanguageSelected(lang) },
                                    label = { Text(lang.shortLabel, fontSize = 11.sp) }
                                )
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("تزامن: ${subtitleStyle.delayOffsetMs}ms", fontSize = 11.5.sp, color = MutedSlate)
                            SmallSyncChip("تصفير") { onResetSync() }
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            SmallSyncChip("-1s", Modifier.weight(1f)) { onUpdateSubtitleStyle { it.copy(delayOffsetMs = it.delayOffsetMs - 1000) } }
                            SmallSyncChip("-0.25s", Modifier.weight(1f)) { onUpdateSubtitleStyle { it.copy(delayOffsetMs = it.delayOffsetMs - 250) } }
                            SmallSyncChip("+0.25s", Modifier.weight(1f)) { onUpdateSubtitleStyle { it.copy(delayOffsetMs = it.delayOffsetMs + 250) } }
                            SmallSyncChip("+1s", Modifier.weight(1f)) { onUpdateSubtitleStyle { it.copy(delayOffsetMs = it.delayOffsetMs + 1000) } }
                        }

                        Text("حجم الخط: ${subtitleStyle.fontSizeSp.toInt()}sp (اسحب الترجمة بإيدك لمكانها)", fontSize = 10.5.sp, color = MutedSlate)
                        Slider(
                            value = subtitleStyle.fontSizeSp,
                            onValueChange = { sz -> onUpdateSubtitleStyle { it.copy(fontSizeSp = sz) } },
                            valueRange = 14f..34f,
                            modifier = Modifier.height(26.dp)
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            FilterChip(
                                selected = subtitleStyle.netflixStyle,
                                onClick = { onUpdateSubtitleStyle { it.copy(netflixStyle = !it.netflixStyle) } },
                                label = { Text("Netflix", fontSize = 11.sp) },
                                modifier = Modifier.weight(1f)
                            )
                            FilterChip(
                                selected = subtitleStyle.useYellowText,
                                onClick = { onUpdateSubtitleStyle { it.copy(useYellowText = !it.useYellowText) } },
                                label = { Text(if (subtitleStyle.useYellowText) "أصفر" else "أبيض", fontSize = 11.sp) },
                                modifier = Modifier.weight(1f)
                            )
                            FilterChip(
                                selected = subtitleStyle.ultraFastSync,
                                onClick = { onUpdateSubtitleStyle { it.copy(ultraFastSync = !it.ultraFastSync) } },
                                label = { Text("سريع", fontSize = 11.sp) },
                                modifier = Modifier.weight(1f)
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedButton(
                                onClick = {
                                    expanded = false
                                    onLoadLocalSubtitle()
                                },
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text("ملف SRT", fontSize = 11.sp)
                            }
                            TextButton(
                                onClick = { onUpdateSubtitleStyle { it.copy(showOriginalText = !it.showOriginalText) } },
                                contentPadding = PaddingValues(horizontal = 6.dp)
                            ) {
                                Text(if (subtitleStyle.showOriginalText) "إخفاء الأصل" else "إظهار الأصل", fontSize = 11.sp)
                            }
                            FilledTonalButton(
                                onClick = {
                                    expanded = false
                                    onExplainCurrent()
                                },
                                enabled = hasActiveCue,
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.Rounded.AutoAwesome, null, modifier = Modifier.size(14.dp))
                                Spacer(Modifier.width(3.dp))
                                Text("شرح", fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SmallSyncChip(label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(8.dp),
        color = ElevatedCharcoal,
        modifier = modifier
    ) {
        Box(contentAlignment = Alignment.Center, modifier = Modifier.padding(horizontal = 6.dp, vertical = 5.dp)) {
            Text(label, fontSize = 11.sp, color = SoftWhite)
        }
    }
}
