package com.personal.watchtranslate.ai

import java.util.ArrayDeque

data class ContextLine(
    val source: String,
    val translated: String,
    val speaker: String? = null
)

class DialogueContextManager(private val maxHistory: Int = 10) {
    private val history = ArrayDeque<ContextLine>(maxHistory + 1)
    @Volatile var mediaTitle: String = ""

    @Synchronized
    fun record(source: String, translated: String, speaker: String? = null) {
        if (history.size >= maxHistory) history.removeFirst()
        history.addLast(ContextLine(source, translated, speaker))
    }

    @Synchronized
    fun buildContextPromptBlock(): String {
        val sb = StringBuilder()
        if (mediaTitle.isNotBlank()) {
            sb.append("Current video/show title: ").append(mediaTitle).append("\n")
        }
        if (history.isNotEmpty()) {
            sb.append("Recent dialogue context (for pronouns, tone, character names, and continuity):\n")
            history.forEach { line ->
                val spk = line.speaker?.let { "[$it] " } ?: ""
                sb.append("- ").append(spk).append(line.source).append(" => ").append(line.translated).append("\n")
            }
        }
        return sb.toString()
    }

    @Synchronized
    fun reset() {
        history.clear()
    }
}
