package com.personal.watchtranslate.ui

import android.app.Application
import android.content.Intent
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.personal.watchtranslate.ai.*
import com.personal.watchtranslate.audio.AudioCaptureBus
import com.personal.watchtranslate.audio.AudioCaptureService
import com.personal.watchtranslate.browser.AdBlockerEngine
import com.personal.watchtranslate.data.local.AppDatabase
import com.personal.watchtranslate.data.local.LlmProvider
import com.personal.watchtranslate.data.local.SecureKeyStore
import com.personal.watchtranslate.data.model.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicLong

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val appContext = application.applicationContext
    val db = AppDatabase.getInstance(appContext)
    val dao = db.browserDao()
    val keyStore = SecureKeyStore(appContext)
    val adBlocker = AdBlockerEngine(appContext, dao, viewModelScope)

    private val contextManager = DialogueContextManager()
    val translationEngine = TranslationEngine(keyStore, dao, contextManager)
    val syncEngine = SubtitleSyncEngine()
    private val sttEngine = DeepgramStreamingSttEngine()

    private val subtitleFetchClient = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .build()

    private val _tabs = MutableStateFlow(listOf(BrowserTab()))
    val tabs = _tabs.asStateFlow()

    private val _activeTabIndex = MutableStateFlow(0)
    val activeTabIndex = _activeTabIndex.asStateFlow()

    val currentTab: StateFlow<BrowserTab> = combine(_tabs, _activeTabIndex) { list, idx ->
        list.getOrElse(idx) { list.first() }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, BrowserTab())

    private val _videoState = MutableStateFlow(VideoPlaybackState())
    val videoState = _videoState.asStateFlow()

    private val _engineStatus = MutableStateFlow(EngineStatus.IDLE)
    val engineStatus = _engineStatus.asStateFlow()

    private val _lastErrorDetail = MutableStateFlow<String?>(null)
    val lastErrorDetail = _lastErrorDetail.asStateFlow()

    private val _activeEngineInfo = MutableStateFlow("")
    val activeEngineInfo = _activeEngineInfo.asStateFlow()

    private val _isTranslationEnabled = MutableStateFlow(false)
    val isTranslationEnabled = _isTranslationEnabled.asStateFlow()

    private val _isTranslationPaused = MutableStateFlow(false)
    val isTranslationPaused = _isTranslationPaused.asStateFlow()

    private val _translationStyle = MutableStateFlow(keyStore.savedTranslationStyle)
    val translationStyle = _translationStyle.asStateFlow()

    private val _translationMode = MutableStateFlow(keyStore.savedTranslationMode)
    val translationMode = _translationMode.asStateFlow()

    private val _sourceLanguage = MutableStateFlow(keyStore.savedSourceLanguage)
    val sourceLanguage = _sourceLanguage.asStateFlow()

    private val _subtitleStyle = MutableStateFlow(keyStore.loadSubtitleStyle())
    val subtitleStyle = _subtitleStyle.asStateFlow()

    private val _explanationLoading = MutableStateFlow(false)
    val explanationLoading = _explanationLoading.asStateFlow()

    private val _currentExplanation = MutableStateFlow<SubtitleExplanation?>(null)
    val currentExplanation = _currentExplanation.asStateFlow()

    val audioLevel = AudioCaptureBus.audioLevel

    val bookmarks = dao.observeBookmarks().stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val history = dao.observeHistory().stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val translationHistory = dao.observeTranslationHistory().stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    private val websiteRawCues = mutableListOf<RawCaptionCue>()
    private val translatedCueStarts = ConcurrentHashMap.newKeySet<Long>()
    private val fetchedSubtitleUrls = ConcurrentHashMap.newKeySet<String>()
    private var lastBatchJob: Job? = null
    private var isLocalSubtitleLoaded: Boolean = false

    private val liveSeqCounter = AtomicLong(0L)
    private val pendingTextBuilder = StringBuilder()
    private var pendingStartMs: Long = 0L
    private var pendingEndMs: Long = 0L
    private var pendingSpeakerId: Int? = null
    private var coalesceFlushJob: Job? = null

    private var lastSpeakerId: Int? = null
    private var lastSegmentEpochMs: Long = 0L
    private var silentFrameCount: Int = 0

    init {
        observeLiveAudioPipeline()
        viewModelScope.launch {
            while (isActive) {
                delay(250)
                if (_isTranslationEnabled.value && !_isTranslationPaused.value) {
                    syncEngine.onWallClockTick()
                }
            }
        }
    }

    private fun observeLiveAudioPipeline() {
        viewModelScope.launch {
            AudioCaptureBus.audioFrames.collect { frame ->
                if (_isTranslationEnabled.value && !_isTranslationPaused.value &&
                    (_engineStatus.value == EngineStatus.LIVE_AUDIO_ACTIVE ||
                        _engineStatus.value == EngineStatus.RECONNECTING ||
                        _engineStatus.value == EngineStatus.DRM_OR_SILENCE)
                ) {
                    sttEngine.sendPcmChunk(frame.pcm16Bytes)
                    if (frame.rmsEnergy < 75.0) {
                        silentFrameCount++
                        if (silentFrameCount >= 16) {
                            syncEngine.onAudioSilenceDetected()
                        }
                    } else {
                        silentFrameCount = 0
                        if (_engineStatus.value == EngineStatus.DRM_OR_SILENCE) {
                            _engineStatus.value = EngineStatus.LIVE_AUDIO_ACTIVE
                        }
                    }
                }
            }
        }

        viewModelScope.launch {
            var wasCapturing = false
            AudioCaptureBus.isCapturing.collect { capturing ->
                if (wasCapturing && !capturing && _isTranslationEnabled.value &&
                    (_engineStatus.value == EngineStatus.LIVE_AUDIO_ACTIVE || _engineStatus.value == EngineStatus.RECONNECTING)
                ) {
                    sttEngine.stop()
                    _isTranslationEnabled.value = false
                    _isTranslationPaused.value = false
                    _engineStatus.value = EngineStatus.IDLE
                }
                wasCapturing = capturing
            }
        }

        viewModelScope.launch {
            AudioCaptureBus.drmSilenceDetected.collect { silence ->
                if (silence && _videoState.value.isPlaying && _engineStatus.value == EngineStatus.LIVE_AUDIO_ACTIVE) {
                    _engineStatus.value = EngineStatus.DRM_OR_SILENCE
                }
            }
        }

        viewModelScope.launch {
            sttEngine.connectionState.collect { state ->
                if (!_isTranslationEnabled.value || _isTranslationPaused.value) return@collect
                if (websiteRawCues.isNotEmpty() && _translationMode.value != TranslationMode.LIVE_AUDIO) return@collect
                when (state) {
                    SttConnectionState.CONNECTED -> {
                        _lastErrorDetail.value = null
                        _engineStatus.value = EngineStatus.LIVE_AUDIO_ACTIVE
                    }
                    SttConnectionState.RECONNECTING -> {
                        _engineStatus.value = EngineStatus.RECONNECTING
                    }
                    else -> {}
                }
            }
        }

        viewModelScope.launch {
            sttEngine.utteranceEnded.collect {
                flushPendingSpeechBuffer()
            }
        }

        viewModelScope.launch {
            sttEngine.segments.collect { seg ->
                if (!_isTranslationEnabled.value || _isTranslationPaused.value || !seg.isFinal) return@collect
                handleIncomingFinalSegment(seg)
            }
        }

        viewModelScope.launch {
            sttEngine.errors.collect { errMsg ->
                _lastErrorDetail.value = errMsg
                if (_isTranslationEnabled.value) {
                    _engineStatus.value = EngineStatus.NETWORK_ERROR
                }
            }
        }
    }

    private fun handleIncomingFinalSegment(seg: RecognizedSpeechSegment) {
        val clean = seg.text.trim()
        if (clean.isEmpty()) return

        if (pendingTextBuilder.isNotEmpty() && seg.speakerId != null && pendingSpeakerId != null && seg.speakerId != pendingSpeakerId) {
            flushPendingSpeechBuffer()
        }

        if (pendingTextBuilder.isEmpty()) {
            pendingStartMs = seg.startOffsetMs
            pendingSpeakerId = seg.speakerId
        } else {
            pendingTextBuilder.append(" ")
        }
        pendingTextBuilder.append(clean)
        pendingEndMs = seg.endOffsetMs

        val combined = pendingTextBuilder.toString().trim()
        val wordCount = combined.split(Regex("\\s+")).size
        val endsWithPunctuation = combined.endsWith(".") || combined.endsWith("?") ||
            combined.endsWith("!") || combined.endsWith("؟")

        val shouldFlushImmediately = seg.speechFinal ||
            endsWithPunctuation ||
            wordCount >= 7 ||
            combined.length >= 48

        coalesceFlushJob?.cancel()
        if (shouldFlushImmediately) {
            flushPendingSpeechBuffer()
        } else {
            coalesceFlushJob = viewModelScope.launch {
                delay(220L)
                flushPendingSpeechBuffer()
            }
        }
    }

    private fun flushPendingSpeechBuffer() {
        coalesceFlushJob?.cancel()
        coalesceFlushJob = null
        val text = pendingTextBuilder.toString().trim()
        if (text.isEmpty()) return

        val startMs = pendingStartMs
        val endMs = pendingEndMs
        val spkId = pendingSpeakerId
        pendingTextBuilder.clear()

        val now = System.currentTimeMillis()
        val speakerChanged = spkId != null && lastSpeakerId != null &&
            spkId != lastSpeakerId && (now - lastSegmentEpochMs) < 3500L
        lastSpeakerId = spkId
        lastSegmentEpochMs = now

        val speakerLabel = spkId?.let { "Speaker ${it + 1}" }
        val seqId = liveSeqCounter.incrementAndGet()
        val videoTimeSnapshot = _videoState.value.currentTimeMs
        val styleSnapshot = _translationStyle.value
        val ultraFastSnapshot = _subtitleStyle.value.ultraFastSync

        viewModelScope.launch {
            val res = translationEngine.translateLine(text, styleSnapshot, speakerLabel, ultraFastSnapshot)
            res.onSuccess { outcome ->
                if (!_isTranslationEnabled.value || _isTranslationPaused.value) return@onSuccess
                val displaySub = if (speakerChanged && !outcome.text.startsWith("-")) "- ${outcome.text}" else outcome.text
                syncEngine.publishLiveCue(
                    sequenceId = seqId,
                    sttStartOffsetMs = startMs,
                    sttEndOffsetMs = endMs,
                    sourceText = text,
                    translatedText = displaySub,
                    speakerLabel = speakerLabel,
                    currentVideoTimeMs = videoTimeSnapshot
                )
                _activeEngineInfo.value = "${outcome.engineName} • ${outcome.latencyMs}ms"
                if (_engineStatus.value == EngineStatus.NETWORK_ERROR) {
                    _engineStatus.value = EngineStatus.LIVE_AUDIO_ACTIVE
                    _lastErrorDetail.value = null
                }
                logTranslationHistory(text, displaySub)
            }.onFailure { err ->
                _lastErrorDetail.value = "Translation: ${err.localizedMessage ?: "Error"}"
                _engineStatus.value = EngineStatus.NETWORK_ERROR
            }
        }
    }

    fun onSubtitleUrlIntercepted(subUrl: String, referer: String?, userAgent: String?) {
        if (isLocalSubtitleLoaded) return
        if (!fetchedSubtitleUrls.add(subUrl)) return

        viewModelScope.launch(Dispatchers.IO) {
            runCatching {
                val reqBuilder = Request.Builder().url(subUrl)
                if (!referer.isNullOrBlank()) reqBuilder.addHeader("Referer", referer)
                if (!userAgent.isNullOrBlank()) reqBuilder.addHeader("User-Agent", userAgent)
                subtitleFetchClient.newCall(reqBuilder.build()).execute().use { resp ->
                    if (!resp.isSuccessful) return@use
                    val body = resp.body?.string().orEmpty()
                    if (body.length < 15) return@use
                    val parsed = SubtitleParser.parseAuto(body)
                    if (parsed.size >= 3) {
                        withContext(Dispatchers.Main) {
                            installParsedWebsiteCues(parsed, sourceLabel = "Captions Synced")
                        }
                    }
                }
            }
        }
    }

    fun loadLocalSubtitleContent(content: String, fileName: String) {
        val parsed = SubtitleParser.parseAuto(content)
        if (parsed.isEmpty()) {
            _lastErrorDetail.value = "الملف ($fileName) لا يحتوي على ترجمة صالحة"
            return
        }
        isLocalSubtitleLoaded = true
        websiteRawCues.clear()
        websiteRawCues.addAll(parsed)
        translatedCueStarts.clear()
        syncEngine.clearAll()
        _lastErrorDetail.value = null
        _isTranslationEnabled.value = true
        _isTranslationPaused.value = false
        _engineStatus.value = EngineStatus.LOCAL_SUBTITLE_ACTIVE
        _activeEngineInfo.value = "SRT: ${parsed.size} سطر"
        scheduleLookaheadCaptionTranslation(_videoState.value.currentTimeMs)
    }

    private fun installParsedWebsiteCues(parsed: List<RawCaptionCue>, sourceLabel: String) {
        if (isLocalSubtitleLoaded) return
        if (parsed.size <= websiteRawCues.size && websiteRawCues.isNotEmpty()) return
        websiteRawCues.clear()
        websiteRawCues.addAll(parsed)
        translatedCueStarts.clear()
        _videoState.value = _videoState.value.copy(hasAccessibleCaptions = true)
        _activeEngineInfo.value = "$sourceLabel (${parsed.size})"
        if (_isTranslationEnabled.value && _translationMode.value != TranslationMode.LIVE_AUDIO) {
            _engineStatus.value = EngineStatus.CAPTIONS_ACTIVE
            scheduleLookaheadCaptionTranslation(_videoState.value.currentTimeMs)
        }
    }

    fun navigateTo(rawInput: String) {
        val trimmed = rawInput.trim()
        if (trimmed.isEmpty()) return
        val resolvedUrl = when {
            trimmed == "about:home" -> "about:home"
            trimmed.startsWith("http://") || trimmed.startsWith("https://") -> trimmed
            trimmed.contains(".") && !trimmed.contains(" ") -> "https://$trimmed"
            else -> "https://www.google.com/search?q=${URLEncoder.encode(trimmed, "UTF-8")}"
        }
        updateCurrentTab { it.copy(url = resolvedUrl) }
        resetPageTranslationState()
    }

    fun onPageMetadataUpdated(url: String, title: String) {
        updateCurrentTab { it.copy(url = url, title = title.ifBlank { url }) }
        contextManager.mediaTitle = title
        val tab = currentTab.value
        if (!tab.isPrivate && url.startsWith("http")) {
            viewModelScope.launch(Dispatchers.IO) {
                dao.insertHistory(HistoryEntity(url = url, title = title.ifBlank { url }))
            }
        }
    }

    fun addNewTab(isPrivate: Boolean = false) {
        val updated = _tabs.value + BrowserTab(isPrivate = isPrivate)
        _tabs.value = updated
        _activeTabIndex.value = updated.lastIndex
        resetPageTranslationState()
    }

    fun selectTab(index: Int) {
        if (index in _tabs.value.indices) {
            _activeTabIndex.value = index
            resetPageTranslationState()
        }
    }

    fun closeTab(index: Int) {
        val list = _tabs.value.toMutableList()
        if (list.size <= 1) {
            list[0] = BrowserTab()
            _tabs.value = list
            _activeTabIndex.value = 0
        } else {
            list.removeAt(index)
            _tabs.value = list
            _activeTabIndex.value = _activeTabIndex.value.coerceAtMost(list.lastIndex)
        }
        resetPageTranslationState()
    }

    fun toggleDesktopMode() {
        updateCurrentTab { it.copy(isDesktopMode = !it.isDesktopMode) }
    }

    fun toggleBookmarkCurrentPage() {
        val tab = currentTab.value
        if (!tab.url.startsWith("http")) return
        viewModelScope.launch(Dispatchers.IO) {
            val exists = bookmarks.value.any { it.url == tab.url }
            if (exists) dao.deleteBookmark(tab.url)
            else dao.upsertBookmark(BookmarkEntity(url = tab.url, title = tab.title))
        }
    }

    fun clearAllBrowsingData() {
        viewModelScope.launch(Dispatchers.IO) {
            dao.clearHistory()
            dao.clearTranslationCache()
            dao.clearTranslationHistory()
        }
    }

    private fun updateCurrentTab(transform: (BrowserTab) -> BrowserTab) {
        val idx = _activeTabIndex.value
        val list = _tabs.value.toMutableList()
        if (idx in list.indices) {
            list[idx] = transform(list[idx])
            _tabs.value = list
        }
    }

    fun onJsBridgeEvent(type: String, payloadJson: String) {
        runCatching {
            val json = JSONObject(payloadJson)
            when (type) {
                "VIDEO_STATE" -> {
                    val state = VideoPlaybackState(
                        detected = json.optBoolean("detected"),
                        isPlaying = json.optBoolean("isPlaying"),
                        currentTimeMs = json.optLong("currentTimeMs"),
                        durationMs = json.optLong("durationMs"),
                        playbackRate = json.optDouble("playbackRate", 1.0).toFloat(),
                        hasAccessibleCaptions = json.optBoolean("hasAccessibleCaptions") || websiteRawCues.isNotEmpty(),
                        pageTitle = json.optString("pageTitle"),
                        pageUrl = json.optString("pageUrl")
                    )
                    _videoState.value = state
                    if (state.pageTitle.isNotBlank()) contextManager.mediaTitle = state.pageTitle
                }
                "TIME_TICK" -> {
                    val currentMs = json.optLong("currentTimeMs")
                    val rate = json.optDouble("playbackRate", 1.0).toFloat()
                    val isPlaying = json.optBoolean("isPlaying")
                    val hasCaps = json.optBoolean("hasAccessibleCaptions")
                    _videoState.value = _videoState.value.copy(
                        detected = true,
                        isPlaying = isPlaying,
                        currentTimeMs = currentMs,
                        playbackRate = rate,
                        hasAccessibleCaptions = hasCaps || websiteRawCues.isNotEmpty()
                    )
                    if (_isTranslationEnabled.value && !_isTranslationPaused.value) {
                        syncEngine.onVideoTimeUpdate(currentMs, rate)
                        if (websiteRawCues.isNotEmpty() && _translationMode.value != TranslationMode.LIVE_AUDIO) {
                            scheduleLookaheadCaptionTranslation(currentMs)
                        }
                    }
                }
                "VIDEO_SEEKING", "VIDEO_SEEKED" -> {
                    val pos = json.optLong("currentTimeMs")
                    syncEngine.onSeek(pos)
                    if (websiteRawCues.isNotEmpty()) scheduleLookaheadCaptionTranslation(pos)
                }
                "RAW_SUBTITLE_FILE" -> {
                    val parsed = SubtitleParser.parseAuto(json.optString("content"))
                    if (parsed.isNotEmpty()) {
                        installParsedWebsiteCues(parsed, sourceLabel = "Captions Synced")
                    }
                }
                "TRACK_CUES" -> {
                    val arr = json.getJSONArray("cues")
                    val parsed = (0 until arr.length()).map { i ->
                        val o = arr.getJSONObject(i)
                        RawCaptionCue(o.getLong("startMs"), o.getLong("endMs"), o.getString("text"))
                    }
                    if (parsed.isNotEmpty()) {
                        installParsedWebsiteCues(parsed, sourceLabel = "Track Synced")
                    }
                }
                "ACTIVE_CUES" -> {
                    if (!_isTranslationEnabled.value || _isTranslationPaused.value) return
                    val arr = json.getJSONArray("cues")
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        val startMs = o.getLong("startMs")
                        val endMs = o.getLong("endMs")
                        val text = o.getString("text")
                        if (translatedCueStarts.add(startMs)) {
                            viewModelScope.launch {
                                translationEngine.translateLine(text, _translationStyle.value, ultraFast = _subtitleStyle.value.ultraFastSync)
                                    .onSuccess { outcome ->
                                        syncEngine.addCaptionCue(
                                            SubtitleCue(
                                                startMs = startMs, endMs = endMs,
                                                sourceText = text, translatedText = outcome.text,
                                                isFromWebsiteCaption = true
                                            )
                                        )
                                        _activeEngineInfo.value = "${outcome.engineName} • ${outcome.latencyMs}ms"
                                    }
                            }
                        }
                    }
                }
            }
        }
    }

    private fun scheduleLookaheadCaptionTranslation(currentMs: Long) {
        if (lastBatchJob?.isActive == true) return
        val upcoming = websiteRawCues
            .filter { it.endMs >= currentMs - 500L && !translatedCueStarts.contains(it.startMs) }
            .take(16)
        if (upcoming.isEmpty()) return

        upcoming.forEach { translatedCueStarts.add(it.startMs) }
        lastBatchJob = viewModelScope.launch {
            val res = translationEngine.translateBatch(
                lines = upcoming.map { it.text },
                style = _translationStyle.value,
                ultraFast = _subtitleStyle.value.ultraFastSync
            )
            res.onSuccess { (translatedList, engineName) ->
                upcoming.forEachIndexed { idx, raw ->
                    val tr = translatedList.getOrElse(idx) { raw.text }
                    syncEngine.addCaptionCue(
                        SubtitleCue(
                            startMs = raw.startMs,
                            endMs = raw.endMs,
                            sourceText = raw.text,
                            translatedText = tr,
                            isFromWebsiteCaption = true
                        )
                    )
                }
                _activeEngineInfo.value = "$engineName • متزامن 100%"
                _engineStatus.value = if (isLocalSubtitleLoaded) EngineStatus.LOCAL_SUBTITLE_ACTIVE else EngineStatus.CAPTIONS_ACTIVE
            }.onFailure { err ->
                upcoming.forEach { translatedCueStarts.remove(it.startMs) }
                _lastErrorDetail.value = err.localizedMessage
                _engineStatus.value = EngineStatus.NETWORK_ERROR
            }
        }
    }

    fun requestStartTranslation(): Boolean {
        if (!keyStore.hasTranslationKey()) {
            _engineStatus.value = EngineStatus.NO_API_KEY
            return false
        }
        _lastErrorDetail.value = null
        _isTranslationEnabled.value = true
        _isTranslationPaused.value = false

        val canUseCaptions = websiteRawCues.isNotEmpty() || _videoState.value.hasAccessibleCaptions
        if (canUseCaptions && _translationMode.value != TranslationMode.LIVE_AUDIO) {
            _engineStatus.value = if (isLocalSubtitleLoaded) EngineStatus.LOCAL_SUBTITLE_ACTIVE else EngineStatus.CAPTIONS_ACTIVE
            scheduleLookaheadCaptionTranslation(_videoState.value.currentTimeMs)
            return false
        }

        if (_translationMode.value == TranslationMode.SUBTITLE_ONLY) {
            _engineStatus.value = EngineStatus.DETECTING_VIDEO
            return false
        }

        if (!keyStore.hasLiveSttKey()) {
            _engineStatus.value = EngineStatus.NO_DEEPGRAM_KEY
            return false
        }

        if (AudioCaptureBus.isCapturing.value) {
            startLiveSttStream()
            return false
        }
        return true
    }

    fun onMediaProjectionGranted(resultCode: Int, data: Intent) {
        val serviceIntent = Intent(appContext, AudioCaptureService::class.java).apply {
            action = AudioCaptureService.ACTION_START
            putExtra(AudioCaptureService.EXTRA_RESULT_CODE, resultCode)
            putExtra(AudioCaptureService.EXTRA_RESULT_DATA, data)
        }
        appContext.startForegroundService(serviceIntent)
        startLiveSttStream()
    }

    private fun startLiveSttStream() {
        sttEngine.start(
            apiKey = keyStore.deepgramApiKey,
            languageCode = _sourceLanguage.value.deepgramCode,
            ultraFast = _subtitleStyle.value.ultraFastSync
        )
        syncEngine.anchorLiveStream(sttEngine.getStreamStartEpochMs(), _videoState.value.currentTimeMs)
        _engineStatus.value = EngineStatus.LIVE_AUDIO_ACTIVE
    }

    fun togglePauseTranslation() {
        val paused = !_isTranslationPaused.value
        _isTranslationPaused.value = paused
        if (paused) {
            pendingTextBuilder.clear()
            coalesceFlushJob?.cancel()
            _engineStatus.value = EngineStatus.PAUSED
        } else {
            _engineStatus.value = when {
                isLocalSubtitleLoaded -> EngineStatus.LOCAL_SUBTITLE_ACTIVE
                AudioCaptureBus.isCapturing.value -> EngineStatus.LIVE_AUDIO_ACTIVE
                else -> EngineStatus.CAPTIONS_ACTIVE
            }
        }
    }

    fun stopTranslation() {
        _isTranslationEnabled.value = false
        _isTranslationPaused.value = false
        _lastErrorDetail.value = null
        _activeEngineInfo.value = ""
        _engineStatus.value = EngineStatus.IDLE
        pendingTextBuilder.clear()
        coalesceFlushJob?.cancel()
        sttEngine.stop()
        appContext.startService(
            Intent(appContext, AudioCaptureService::class.java).apply {
                action = AudioCaptureService.ACTION_STOP
            }
        )
        syncEngine.clearAll()
    }

    fun setTranslationStyle(style: TranslationStyle) {
        _translationStyle.value = style
        keyStore.savedTranslationStyle = style
        translatedCueStarts.clear()
        syncEngine.clearAll()
        if (_isTranslationEnabled.value && websiteRawCues.isNotEmpty()) {
            scheduleLookaheadCaptionTranslation(_videoState.value.currentTimeMs)
        }
    }

    fun setTranslationMode(mode: TranslationMode) {
        _translationMode.value = mode
        keyStore.savedTranslationMode = mode
    }

    fun setSourceLanguage(lang: SourceLanguage) {
        _sourceLanguage.value = lang
        keyStore.savedSourceLanguage = lang
        if (_isTranslationEnabled.value && !_isTranslationPaused.value && AudioCaptureBus.isCapturing.value) {
            startLiveSttStream()
        }
    }

    fun updateSubtitleStyle(transform: (SubtitleStyleConfig) -> SubtitleStyleConfig) {
        val prev = _subtitleStyle.value
        val updated = transform(prev)
        _subtitleStyle.value = updated
        keyStore.saveSubtitleStyle(updated)
        syncEngine.updateTimingControls(updated.delayOffsetMs, updated.speedMultiplier)
        if (prev.ultraFastSync != updated.ultraFastSync &&
            _isTranslationEnabled.value && !_isTranslationPaused.value && AudioCaptureBus.isCapturing.value
        ) {
            startLiveSttStream()
        }
    }

    fun resetSynchronization() {
        updateSubtitleStyle { it.copy(delayOffsetMs = 0L, speedMultiplier = 1.0f) }
        syncEngine.resetSync()
    }

    fun requestExplainSubtitle(cue: SubtitleCue) {
        _explanationLoading.value = true
        _currentExplanation.value = null
        viewModelScope.launch {
            translationEngine.explainSubtitle(cue.sourceText, cue.translatedText)
                .onSuccess { _currentExplanation.value = it }
            _explanationLoading.value = false
        }
    }

    fun dismissExplanation() {
        _currentExplanation.value = null
        _explanationLoading.value = false
    }

    fun saveApiSettings(provider: LlmProvider, geminiKey: String, groqKey: String, openAiKey: String, deepgramKey: String) {
        keyStore.llmProvider = provider
        keyStore.geminiApiKey = geminiKey
        keyStore.groqApiKey = groqKey
        keyStore.openAiApiKey = openAiKey
        keyStore.deepgramApiKey = deepgramKey
        if ((_engineStatus.value == EngineStatus.NO_API_KEY || _engineStatus.value == EngineStatus.NO_DEEPGRAM_KEY) &&
            keyStore.hasTranslationKey()
        ) {
            _engineStatus.value = EngineStatus.IDLE
        }
    }

    private fun logTranslationHistory(source: String, translated: String) {
        if (currentTab.value.isPrivate) return
        viewModelScope.launch(Dispatchers.IO) {
            dao.insertTranslationHistory(
                TranslationHistoryEntity(
                    pageTitle = _videoState.value.pageTitle.ifBlank { currentTab.value.title },
                    pageUrl = currentTab.value.url,
                    sourceSnippet = source,
                    translatedSnippet = translated,
                    style = _translationStyle.value.arabicLabel
                )
            )
        }
    }

    private fun resetPageTranslationState() {
        isLocalSubtitleLoaded = false
        websiteRawCues.clear()
        translatedCueStarts.clear()
        fetchedSubtitleUrls.clear()
        pendingTextBuilder.clear()
        coalesceFlushJob?.cancel()
        contextManager.reset()
        syncEngine.clearAll()
        _videoState.value = VideoPlaybackState()
    }

    suspend fun testApiKeys(
        provider: LlmProvider,
        geminiKey: String,
        groqKey: String,
        openAiKey: String,
        deepgramKey: String
    ): String = withContext(Dispatchers.IO) {
        val client = OkHttpClient.Builder()
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .build()
        val lines = mutableListOf<String>()

        when (provider) {
            LlmProvider.GEMINI -> {
                val key = geminiKey.trim()
                if (key.isBlank()) {
                    lines.add("Gemini: ⚠️ لم يتم إدخال المفتاح")
                } else {
                    val res = runCatching {
                        val listUrl = "https://generativelanguage.googleapis.com/v1beta/models?key=$key"
                        val discovered = client.newCall(Request.Builder().url(listUrl).build()).execute().use { resp ->
                            if (!resp.isSuccessful) error("HTTP ${resp.code}")
                            val models = JSONObject(resp.body?.string().orEmpty()).optJSONArray("models") ?: JSONArray()
                            val valid = mutableListOf<String>()
                            for (i in 0 until models.length()) {
                                val m = models.getJSONObject(i)
                                val name = m.optString("name").removePrefix("models/")
                                val methods = m.optJSONArray("supportedGenerationMethods")?.toString().orEmpty()
                                if (methods.contains("generateContent") && name.contains("gemini", ignoreCase = true) &&
                                    !name.contains("vision") && !name.contains("tts") && !name.contains("image")
                                ) {
                                    valid.add(name)
                                }
                            }
                            valid
                        }
                        val toTry = (listOf("gemini-2.5-flash-lite", "gemini-2.0-flash-lite", "gemini-2.0-flash", "gemini-flash-latest") + discovered).distinct()
                        val body = JSONObject().put(
                            "contents",
                            JSONArray().put(
                                JSONObject().put("parts", JSONArray().put(JSONObject().put("text", "OK")))
                            )
                        ).toString()

                        var workingResult: String? = null
                        var lastErr = "لا يوجد موديل متاح"
                        for (model in toTry.take(8)) {
                            val testUrl = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$key"
                            client.newCall(
                                Request.Builder().url(testUrl).post(body.toRequestBody("application/json; charset=utf-8".toMediaType())).build()
                            ).execute().use { resp ->
                                if (resp.isSuccessful) {
                                    workingResult = "Gemini: ✅ شغال بنجاح ($model)"
                                } else {
                                    lastErr = when (resp.code) {
                                        400, 403 -> "المفتاح غير صحيح أو غير مفعّل (${resp.code})"
                                        429 -> "الحد المجاني خلص (429) — جرّب Groq أو Google مجاني"
                                        503 -> "ضغط مؤقت على سيرفر جوجل (503)"
                                        else -> "خطأ (${resp.code}) على $model"
                                    }
                                }
                            }
                            if (workingResult != null) break
                        }
                        workingResult ?: "Gemini: ❌ $lastErr"
                    }.getOrElse { "Gemini: ❌ خطأ (${it.localizedMessage})" }
                    lines.add(res)
                }
            }
            LlmProvider.GOOGLE_FREE -> {
                val res = runCatching {
                    val req = Request.Builder()
                        .url("https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=ar&dt=t&q=Hello")
                        .addHeader("User-Agent", "Mozilla/5.0")
                        .build()
                    client.newCall(req).execute().use { resp ->
                        if (resp.isSuccessful) "Google (مجاني): ✅ شغال بنجاح بدون مفتاح"
                        else "Google (مجاني): ❌ خطأ (${resp.code})"
                    }
                }.getOrElse { "Google (مجاني): ❌ فشل الاتصال (${it.localizedMessage})" }
                lines.add(res)
            }
            LlmProvider.GROQ -> {
                val key = groqKey.trim()
                if (key.isBlank()) {
                    lines.add("Groq: ⚠️ لم يتم إدخال المفتاح")
                } else {
                    val res = runCatching {
                        val groqModels = listOf("llama-3.1-8b-instant", "llama-3.3-70b-versatile")
                        var okMsg: String? = null
                        var lastErr = "فشل الاتصال"
                        for (m in groqModels) {
                            val body = JSONObject()
                                .put("model", m)
                                .put("max_tokens", 5)
                                .put("messages", JSONArray().put(
                                    JSONObject().put("role", "user").put("content", "OK")
                                ))
                                .toString()
                                .toRequestBody("application/json; charset=utf-8".toMediaType())
                            val req = Request.Builder()
                                .url("https://api.groq.com/openai/v1/chat/completions")
                                .addHeader("Authorization", "Bearer $key")
                                .post(body)
                                .build()
                            client.newCall(req).execute().use { resp ->
                                if (resp.isSuccessful) okMsg = "Groq: ✅ شغال بنجاح ($m)"
                                else lastErr = when (resp.code) {
                                    401 -> "المفتاح غير صحيح (401)"
                                    429 -> "الحد المجاني ممتلئ مؤقتاً (429)"
                                    else -> "خطأ (${resp.code}) على $m"
                                }
                            }
                            if (okMsg != null) break
                        }
                        okMsg ?: "Groq: ❌ $lastErr"
                    }.getOrElse { "Groq: ❌ فشل الاتصال (${it.localizedMessage})" }
                    lines.add(res)
                }
            }
            LlmProvider.OPENAI -> {
                val key = openAiKey.trim()
                if (key.isBlank()) {
                    lines.add("OpenAI: ⚠️ لم يتم إدخال المفتاح")
                } else {
                    val res = runCatching {
                        val req = Request.Builder()
                            .url("https://api.openai.com/v1/models")
                            .addHeader("Authorization", "Bearer $key")
                            .build()
                        client.newCall(req).execute().use { resp ->
                            if (resp.isSuccessful) "OpenAI: ✅ شغال بنجاح"
                            else "OpenAI: ❌ خطأ (${resp.code}) - المفتاح غير صحيح أو منتهي"
                        }
                    }.getOrElse { "OpenAI: ❌ فشل الاتصال (${it.localizedMessage})" }
                    lines.add(res)
                }
            }
        }

        val dgKey = deepgramKey.trim()
        if (dgKey.isBlank()) {
            lines.add("Deepgram: ⚠️ لم يتم إدخال المفتاح (مطلوب للترجمة الصوتية فقط)")
        } else {
            val res = runCatching {
                val req = Request.Builder()
                    .url("https://api.deepgram.com/v1/projects")
                    .addHeader("Authorization", "Token $dgKey")
                    .build()
                client.newCall(req).execute().use { resp ->
                    if (resp.isSuccessful) "Deepgram: ✅ شغال بنجاح"
                    else "Deepgram: ❌ خطأ (${resp.code}) - المفتاح غير صحيح"
                }
            }.getOrElse { "Deepgram: ❌ فشل الاتصال (${it.localizedMessage})" }
            lines.add(res)
        }

        lines.joinToString("\n")
    }
}
