package com.personal.watchtranslate.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

enum class TranslationStyle(val displayName: String, val arabicLabel: String) {
    NATURAL_ARABIC("Natural Arabic", "عربي طبيعي سلس"),
    MSA("Modern Standard Arabic", "فصحى سينمائية"),
    ENGLISH("English", "إنجليزي")
}

enum class SourceLanguage(val deepgramCode: String, val shortLabel: String, val displayLabel: String) {
    AUTO("multi", "تلقائي", "تلقائي (متعدد اللغات)"),
    ENGLISH("en", "EN", "إنجليزي (أدق وأسرع للأفلام)"),
    TURKISH("tr", "TR", "تركي"),
    KOREAN("ko", "KO", "كوري"),
    JAPANESE("ja", "JA", "ياباني"),
    SPANISH("es", "ES", "إسباني"),
    FRENCH("fr", "FR", "فرنسي"),
    GERMAN("de", "DE", "ألماني")
}

enum class TranslationMode(val label: String) {
    AUTO("تلقائي (ملف الترجمة أولاً ← ثم الصوت)"),
    SUBTITLE_ONLY("ترجمة الموقع / ملف SRT فقط"),
    LIVE_AUDIO("ترجمة الصوت المباشر بالذكاء الاصطناعي")
}

enum class EngineStatus(val message: String, val isError: Boolean = false) {
    IDLE("جاهز للتشغيل"),
    DETECTING_VIDEO("جاري البحث عن الفيديو والترجمة..."),
    CAPTIONS_ACTIVE("ترجمة متزامنة مع الفيديو (دقة 100%)"),
    LOCAL_SUBTITLE_ACTIVE("ملف الترجمة المحلي متزامن"),
    LIVE_AUDIO_ACTIVE("ترجمة الصوت المباشر شغالة"),
    RECONNECTING("جاري إعادة الاتصال تلقائياً..."),
    PAUSED("الترجمة متوقفة مؤقتاً"),
    DRM_OR_SILENCE("لا يوجد صوت أو محمي بـ DRM — تأكد أن الفيديو غير صامت", isError = true),
    NO_API_KEY("أضف مفتاح API أو اختر Google (مجاني) من الإعدادات", isError = true),
    NO_DEEPGRAM_KEY("أضف مفتاح Deepgram في الإعدادات للترجمة الصوتية المباشرة", isError = true),
    NETWORK_ERROR("مشكلة مؤقتة في الشبكة — جاري إعادة المحاولة...", isError = true)
}

data class SubtitleCue(
    val id: String = UUID.randomUUID().toString(),
    val startMs: Long,
    val endMs: Long,
    val sourceText: String,
    val translatedText: String,
    val speakerLabel: String? = null,
    val isFromWebsiteCaption: Boolean = false
)

data class SubtitleExplanation(
    val original: String,
    val translation: String,
    val meaningInContext: String,
    val slangOrIdiomNotes: String,
    val naturalArabicVersion: String,
    val alternatives: List<String>,
    val pronunciationGuide: String
)

data class SubtitleStyleConfig(
    val fontSizeSp: Float = 21f,
    val textColorHex: Long = 0xFFFFFFFF,
    val bgOpacity: Float = 0.72f,
    val verticalPositionBias: Float = 0.85f,
    val delayOffsetMs: Long = 0L,
    val speedMultiplier: Float = 1.0f,
    val showOriginalText: Boolean = false,
    val netflixStyle: Boolean = true,
    val useYellowText: Boolean = false,
    val ultraFastSync: Boolean = true
)

data class VideoPlaybackState(
    val detected: Boolean = false,
    val isPlaying: Boolean = false,
    val currentTimeMs: Long = 0L,
    val durationMs: Long = 0L,
    val playbackRate: Float = 1.0f,
    val hasAccessibleCaptions: Boolean = false,
    val pageTitle: String = "",
    val pageUrl: String = ""
)

data class BrowserTab(
    val id: String = UUID.randomUUID().toString(),
    val url: String = "about:home",
    val title: String = "Home",
    val isPrivate: Boolean = false,
    val isDesktopMode: Boolean = false,
    val blockedCount: Int = 0
)

@Entity(tableName = "bookmarks")
data class BookmarkEntity(
    @PrimaryKey val url: String,
    val title: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "history")
data class HistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val url: String,
    val title: String,
    val visitedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "translation_cache")
data class TranslationCacheEntity(
    @PrimaryKey val cacheKey: String,
    val sourceText: String,
    val translatedText: String,
    val style: String,
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "translation_history")
data class TranslationHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val pageTitle: String,
    val pageUrl: String,
    val sourceSnippet: String,
    val translatedSnippet: String,
    val style: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "adblock_rules")
data class AdBlockRuleEntity(
    @PrimaryKey val domain: String,
    val isWhitelist: Boolean
)
