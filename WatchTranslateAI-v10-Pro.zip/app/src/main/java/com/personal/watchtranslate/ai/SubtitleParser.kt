package com.personal.watchtranslate.ai

import org.json.JSONObject

data class RawCaptionCue(val startMs: Long, val endMs: Long, val text: String)

object SubtitleParser {
    private val timeRegex = Regex("""(\d{1,2}:)?(\d{1,2}):(\d{2})[.,](\d{2,3})\s*-->\s*(\d{1,2}:)?(\d{1,2}):(\d{2})[.,](\d{2,3})""")
    private val xmlTextRegex = Regex("""<text\s+[^>]*start="([0-9.]+)"[^>]*(?:dur="([0-9.]+)")?[^>]*>([\s\S]*?)</text>""")

    fun parseAuto(content: String): List<RawCaptionCue> {
        val trimmed = content.trim()
        if (trimmed.isEmpty()) return emptyList()
        return when {
            trimmed.startsWith("{") && trimmed.contains("\"events\"") -> parseYouTubeJson3(trimmed)
            trimmed.startsWith("<") && trimmed.contains("<text") -> parseTimedTextXml(trimmed)
            else -> parseVttOrSrt(trimmed)
        }.sortedBy { it.startMs }
    }

    fun parseVttOrSrt(content: String): List<RawCaptionCue> {
        val result = mutableListOf<RawCaptionCue>()
        val normalized = content.replace("\uFEFF", "").replace("\r\n", "\n").replace("\r", "\n")
        val blocks = normalized.split(Regex("\n{2,}"))
        for (block in blocks) {
            val lines = block.lines().map { it.trim() }.filter { it.isNotEmpty() }
            val timingIdx = lines.indexOfFirst { timeRegex.containsMatchIn(it) }
            if (timingIdx == -1) continue
            val match = timeRegex.find(lines[timingIdx]) ?: continue

            val startMs = toMs(match.groupValues[1], match.groupValues[2], match.groupValues[3], match.groupValues[4])
            val endMs = toMs(match.groupValues[5], match.groupValues[6], match.groupValues[7], match.groupValues[8])
            val text = cleanText(lines.drop(timingIdx + 1).joinToString(" "))
            if (text.isNotEmpty() && endMs > startMs) {
                result.add(RawCaptionCue(startMs, endMs, text))
            }
        }
        return result
    }

    private fun parseYouTubeJson3(content: String): List<RawCaptionCue> {
        val result = mutableListOf<RawCaptionCue>()
        runCatching {
            val events = JSONObject(content).optJSONArray("events") ?: return emptyList()
            for (i in 0 until events.length()) {
                val ev = events.getJSONObject(i)
                val startMs = ev.optLong("tStartMs", -1L)
                val durMs = ev.optLong("dDurationMs", 2500L)
                if (startMs < 0) continue
                val segs = ev.optJSONArray("segs") ?: continue
                val sb = StringBuilder()
                for (j in 0 until segs.length()) {
                    sb.append(segs.getJSONObject(j).optString("utf8", ""))
                }
                val text = cleanText(sb.toString())
                if (text.isNotEmpty()) {
                    result.add(RawCaptionCue(startMs, startMs + durMs.coerceAtLeast(1200L), text))
                }
            }
        }
        return result
    }

    private fun parseTimedTextXml(content: String): List<RawCaptionCue> {
        val result = mutableListOf<RawCaptionCue>()
        xmlTextRegex.findAll(content).forEach { m ->
            val startSec = m.groupValues[1].toDoubleOrNull() ?: return@forEach
            val durSec = m.groupValues[2].toDoubleOrNull() ?: 2.5
            val text = cleanText(m.groupValues[3])
            if (text.isNotEmpty()) {
                val startMs = (startSec * 1000).toLong()
                val endMs = startMs + (durSec * 1000).toLong().coerceAtLeast(1200L)
                result.add(RawCaptionCue(startMs, endMs, text))
            }
        }
        return result
    }

    private fun cleanText(raw: String): String {
        return raw
            .replace(Regex("\\{\\\\[^}]*\\}"), "")
            .replace(Regex("<[^>]*>"), "")
            .replace("&amp;", "&")
            .replace("&quot;", "\"")
            .replace("&#39;", "'")
            .replace("&apos;", "'")
            .replace("&lt;", "<")
            .replace("&gt;", ">")
            .replace("&nbsp;", " ")
            .replace(Regex("[\n\t]+"), " ")
            .replace(Regex("\\s{2,}"), " ")
            .trim()
    }

    private fun toMs(h: String, m: String, s: String, msRaw: String): Long {
        val hours = h.removeSuffix(":").toLongOrNull() ?: 0L
        val ms = if (msRaw.length == 2) msRaw.toLong() * 10L else msRaw.toLong()
        return hours * 3_600_000L + m.toLong() * 60_000L + s.toLong() * 1000L + ms
    }
}
