package com.personal.watchtranslate.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.personal.watchtranslate.data.local.LlmProvider
import com.personal.watchtranslate.data.model.BrowserTab
import com.personal.watchtranslate.data.model.SourceLanguage
import com.personal.watchtranslate.data.model.TranslationMode
import com.personal.watchtranslate.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun SettingsDialog(
    viewModel: MainViewModel,
    currentMode: TranslationMode,
    currentSourceLang: SourceLanguage,
    adBlockerEnabled: Boolean,
    onDismiss: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var provider by remember { mutableStateOf(viewModel.keyStore.llmProvider) }
    var geminiKey by remember { mutableStateOf(viewModel.keyStore.geminiApiKey) }
    var groqKey by remember { mutableStateOf(viewModel.keyStore.groqApiKey) }
    var openAiKey by remember { mutableStateOf(viewModel.keyStore.openAiApiKey) }
    var deepgramKey by remember { mutableStateOf(viewModel.keyStore.deepgramApiKey) }
    var customBlockDomain by remember { mutableStateOf("") }
    var statusMessage by remember { mutableStateOf("") }
    var isTestingKeys by remember { mutableStateOf(false) }
    var keyTestResult by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = CharcoalSurface,
        title = { Text("Settings & API (v10 Pro)") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("محرك الترجمة الأساسي (مع تحويل تلقائي عند الضغط)", fontSize = 11.5.sp, color = MutedSlate)
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    LlmProvider.entries.chunked(2).forEach { rowItems ->
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            rowItems.forEach { p ->
                                FilterChip(
                                    selected = provider == p,
                                    onClick = { provider = p },
                                    label = { Text(p.label, fontSize = 11.5.sp) },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }

                OutlinedTextField(
                    value = groqKey,
                    onValueChange = { groqKey = it },
                    label = { Text("Groq API Key (الأسرع للأفلام)") },
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true
                )
                OutlinedTextField(
                    value = geminiKey,
                    onValueChange = { geminiKey = it },
                    label = { Text("Gemini API Key") },
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true
                )
                OutlinedTextField(
                    value = openAiKey,
                    onValueChange = { openAiKey = it },
                    label = { Text("OpenAI API Key (اختياري)") },
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true
                )
                OutlinedTextField(
                    value = deepgramKey,
                    onValueChange = { deepgramKey = it },
                    label = { Text("Deepgram API Key (للترجمة الصوتية المباشرة)") },
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true
                )

                FilledTonalButton(
                    onClick = {
                        scope.launch {
                            isTestingKeys = true
                            keyTestResult = "جاري فحص المفاتيح..."
                            keyTestResult = viewModel.testApiKeys(provider, geminiKey, groqKey, openAiKey, deepgramKey)
                            isTestingKeys = false
                        }
                    },
                    enabled = !isTestingKeys,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    if (isTestingKeys) {
                        CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                        Spacer(Modifier.width(8.dp))
                        Text("جاري الاختبار...")
                    } else {
                        Text("اختبار المفاتيح (Test API Keys)")
                    }
                }

                if (keyTestResult.isNotBlank()) {
                    Surface(color = ElevatedCharcoal, shape = RoundedCornerShape(10.dp)) {
                        Text(
                            text = keyTestResult,
                            color = SoftWhite,
                            fontSize = 12.sp,
                            modifier = Modifier.fillMaxWidth().padding(10.dp)
                        )
                    }
                }

                HorizontalDivider()
                Text("وضع الترجمة", fontSize = 12.sp, color = MutedSlate)
                TranslationMode.entries.forEach { mode ->
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth().clickable { viewModel.setTranslationMode(mode) }
                    ) {
                        RadioButton(selected = currentMode == mode, onClick = { viewModel.setTranslationMode(mode) })
                        Text(mode.label, fontSize = 12.5.sp)
                    }
                }

                Text("لغة الفيلم الافتراضية", fontSize = 12.sp, color = MutedSlate)
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    SourceLanguage.entries.chunked(4).forEach { row ->
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                            row.forEach { lang ->
                                FilterChip(
                                    selected = currentSourceLang == lang,
                                    onClick = { viewModel.setSourceLanguage(lang) },
                                    label = { Text(lang.shortLabel, fontSize = 11.sp) },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }

                HorizontalDivider()
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("مانع الإعلانات القوي (Ad Blocker)")
                    Switch(checked = adBlockerEnabled, onCheckedChange = { viewModel.adBlocker.setEnabled(it) })
                }

                OutlinedTextField(
                    value = customBlockDomain,
                    onValueChange = { customBlockDomain = it },
                    label = { Text("حظر موقع إعلانات (مثال: ads.site.com)") },
                    singleLine = true
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        viewModel.adBlocker.addCustomBlockedDomain(customBlockDomain)
                        customBlockDomain = ""
                        statusMessage = "تمت إضافة الموقع لقائمة الحظر."
                    }) { Text("إضافة") }

                    OutlinedButton(onClick = {
                        scope.launch {
                            statusMessage = "جاري تحديث قائمة الحظر..."
                            val res = viewModel.adBlocker.updateBlocklistFromUrl()
                            statusMessage = res.fold(
                                onSuccess = { "تمت إضافة $it دومين إعلاني." },
                                onFailure = { "فشل التحديث: ${it.message}" }
                            )
                        }
                    }) { Text("تحديث القائمة") }
                }

                TextButton(onClick = {
                    viewModel.clearAllBrowsingData()
                    statusMessage = "تم مسح السجل والكاش المحلي."
                }) { Text("مسح السجل وكاش الترجمة", color = AlertAmber) }

                if (statusMessage.isNotBlank()) {
                    Text(statusMessage, color = SuccessGreen, fontSize = 12.sp)
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                viewModel.saveApiSettings(provider, geminiKey, groqKey, openAiKey, deepgramKey)
                onDismiss()
            }) { Text("حفظ") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}

@Composable
fun TabsDialog(
    tabs: List<BrowserTab>,
    onSelect: (Int) -> Unit,
    onClose: (Int) -> Unit,
    onNewTab: (Boolean) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = CharcoalSurface,
        title = { Text("التبويبات (${tabs.size})") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { onNewTab(false) }) { Text("+ تبويب جديد") }
                    OutlinedButton(onClick = { onNewTab(true) }) { Text("+ خاص") }
                }
                LazyColumn(modifier = Modifier.heightIn(max = 260.dp)) {
                    items(tabs.indices.toList()) { idx ->
                        val tab = tabs[idx]
                        Row(
                            modifier = Modifier.fillMaxWidth().clickable { onSelect(idx) }.padding(vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                (if (tab.isPrivate) "[خاص] " else "") + tab.title,
                                maxLines = 1,
                                modifier = Modifier.weight(1f)
                            )
                            TextButton(onClick = { onClose(idx) }) { Text("إغلاق") }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("تم") } }
    )
}

@Composable
fun SimpleListDialog(
    title: String,
    items: List<Pair<String, String>>,
    onItemClick: (String) -> Unit,
    onClear: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = CharcoalSurface,
        title = { Text(title) },
        text = {
            if (items.isEmpty()) {
                Text("لا يوجد سجل حتى الآن.", color = MutedSlate)
            } else {
                LazyColumn(modifier = Modifier.heightIn(max = 320.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(items) { (label, url) ->
                        Column(modifier = Modifier.fillMaxWidth().clickable { onItemClick(url) }.padding(vertical = 4.dp)) {
                            Text(label, fontSize = 13.sp, color = SoftWhite)
                            Text(url, fontSize = 11.sp, color = MutedSlate, maxLines = 1)
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("إغلاق") } },
        dismissButton = { TextButton(onClick = onClear) { Text("مسح الكل", color = AlertAmber) } }
    )
}
