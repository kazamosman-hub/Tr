package com.personal.watchtranslate

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.os.Message
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.*
import android.widget.FrameLayout
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.personal.watchtranslate.ui.*
import com.personal.watchtranslate.ui.theme.*

class MainActivity : ComponentActivity() {
    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)

        setContent {
            WatchTranslateTheme {
                val isTranslating by viewModel.isTranslationEnabled.collectAsState()
                DisposableEffect(isTranslating) {
                    if (isTranslating) {
                        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                    } else {
                        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                    }
                    onDispose {
                        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                    }
                }

                WatchTranslateRoot(
                    viewModel = viewModel,
                    onFullscreenChanged = { isFullscreen -> setImmersiveFullscreen(isFullscreen) }
                )
            }
        }
    }

    private fun setImmersiveFullscreen(enabled: Boolean) {
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        if (enabled) {
            controller.hide(WindowInsetsCompat.Type.systemBars())
            controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        } else {
            controller.show(WindowInsetsCompat.Type.systemBars())
        }
    }
}

@Composable
fun WatchTranslateRoot(
    viewModel: MainViewModel,
    onFullscreenChanged: (Boolean) -> Unit
) {
    val context = LocalContext.current
    val currentTab by viewModel.currentTab.collectAsState()
    val tabs by viewModel.tabs.collectAsState()
    val bookmarks by viewModel.bookmarks.collectAsState()
    val history by viewModel.history.collectAsState()
    val translationHistory by viewModel.translationHistory.collectAsState()
    val videoState by viewModel.videoState.collectAsState()
    val engineStatus by viewModel.engineStatus.collectAsState()
    val lastErrorDetail by viewModel.lastErrorDetail.collectAsState()
    val activeEngineInfo by viewModel.activeEngineInfo.collectAsState()
    val audioLevel by viewModel.audioLevel.collectAsState()
    val isTranslationEnabled by viewModel.isTranslationEnabled.collectAsState()
    val isTranslationPaused by viewModel.isTranslationPaused.collectAsState()
    val translationStyle by viewModel.translationStyle.collectAsState()
    val translationMode by viewModel.translationMode.collectAsState()
    val sourceLanguage by viewModel.sourceLanguage.collectAsState()
    val subtitleStyle by viewModel.subtitleStyle.collectAsState()
    val activeCue by viewModel.syncEngine.activeCue.collectAsState()
    val adBlockerEnabled by viewModel.adBlocker.isEnabled.collectAsState()
    val totalBlockedAds by viewModel.adBlocker.totalBlocked.collectAsState()
    val explanationLoading by viewModel.explanationLoading.collectAsState()
    val currentExplanation by viewModel.currentExplanation.collectAsState()

    var webViewRef by remember { mutableStateOf<WebView?>(null) }
    var fullscreenCustomView by remember { mutableStateOf<View?>(null) }
    var fullscreenCallback by remember { mutableStateOf<WebChromeClient.CustomViewCallback?>(null) }

    var showSettingsDialog by remember { mutableStateOf(false) }
    var showTabsDialog by remember { mutableStateOf(false) }
    var showHistoryDialog by remember { mutableStateOf(false) }
    var showTranslationHistoryDialog by remember { mutableStateOf(false) }

    val mediaProjectionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val data = result.data
        if (result.resultCode == Activity.RESULT_OK && data != null) {
            viewModel.onMediaProjectionGranted(result.resultCode, data)
        }
    }

    val localSubtitlePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            runCatching {
                val text = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }.orEmpty()
                if (text.isNotBlank()) {
                    viewModel.loadLocalSubtitleContent(text, uri.lastPathSegment ?: "subtitle.srt")
                }
            }
        }
    }

    val launchMediaProjection = {
        val mgr = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjectionLauncher.launch(mgr.createScreenCaptureIntent())
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { grantedMap ->
        if (grantedMap[Manifest.permission.RECORD_AUDIO] == true) {
            launchMediaProjection()
        }
    }

    val startTranslationFlow = {
        val needsProjection = viewModel.requestStartTranslation()
        if (needsProjection) {
            val hasAudioPerm = ContextCompat.checkSelfPermission(
                context, Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
            if (hasAudioPerm) {
                launchMediaProjection()
            } else {
                val perms = buildList {
                    add(Manifest.permission.RECORD_AUDIO)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        add(Manifest.permission.POST_NOTIFICATIONS)
                    }
                }.toTypedArray()
                permissionLauncher.launch(perms)
            }
        }
    }

    BackHandler(enabled = fullscreenCustomView != null || webViewRef?.canGoBack() == true || currentTab.url != "about:home") {
        when {
            fullscreenCustomView != null -> {
                fullscreenCallback?.onCustomViewHidden()
                fullscreenCustomView = null
                onFullscreenChanged(false)
            }
            webViewRef?.canGoBack() == true -> webViewRef?.goBack()
            else -> viewModel.navigateTo("about:home")
        }
    }

    Box(modifier = Modifier.fillMaxSize().background(DeepBlack)) {
        Column(modifier = Modifier.fillMaxSize()) {
            if (fullscreenCustomView == null && currentTab.url != "about:home") {
                BrowserTopBar(
                    currentUrl = currentTab.url,
                    isPrivate = currentTab.isPrivate,
                    isDesktopMode = currentTab.isDesktopMode,
                    isBookmarked = bookmarks.any { it.url == currentTab.url },
                    isWhitelisted = viewModel.adBlocker.isSiteWhitelisted(currentTab.url),
                    tabCount = tabs.size,
                    onSubmitUrl = { viewModel.navigateTo(it) },
                    onBack = { webViewRef?.goBack() },
                    onForward = { webViewRef?.goForward() },
                    onRefresh = { webViewRef?.reload() },
                    onHome = { viewModel.navigateTo("about:home") },
                    onToggleBookmark = { viewModel.toggleBookmarkCurrentPage() },
                    onToggleDesktop = {
                        viewModel.toggleDesktopMode()
                        webViewRef?.reload()
                    },
                    onToggleWhitelist = {
                        viewModel.adBlocker.toggleSiteWhitelist(currentTab.url)
                        webViewRef?.reload()
                    },
                    onOpenTabs = { showTabsDialog = true },
                    onOpenHistory = { showHistoryDialog = true },
                    onOpenSettings = { showSettingsDialog = true }
                )
            }

            if (currentTab.url == "about:home") {
                HomeScreen(
                    bookmarks = bookmarks,
                    recentHistory = history,
                    adBlockerEnabled = adBlockerEnabled,
                    totalBlockedAds = totalBlockedAds,
                    aiTranslationReady = viewModel.keyStore.hasTranslationKey(),
                    onNavigate = { viewModel.navigateTo(it) },
                    onToggleAdBlocker = { viewModel.adBlocker.setEnabled(it) },
                    onOpenSettings = { showSettingsDialog = true },
                    onOpenTranslationHistory = { showTranslationHistoryDialog = true }
                )
            } else {
                IntegratedBrowserWebView(
                    url = currentTab.url,
                    isPrivate = currentTab.isPrivate,
                    isDesktopMode = currentTab.isDesktopMode,
                    viewModel = viewModel,
                    onWebViewReady = { webViewRef = it },
                    onEnterFullscreen = { view, callback ->
                        fullscreenCustomView = view
                        fullscreenCallback = callback
                        onFullscreenChanged(true)
                    },
                    onExitFullscreen = {
                        fullscreenCustomView = null
                        fullscreenCallback = null
                        onFullscreenChanged(false)
                    },
                    modifier = Modifier.weight(1f).fillMaxWidth()
                )
            }
        }

        fullscreenCustomView?.let { customView ->
            AndroidView(
                factory = { ctx ->
                    FrameLayout(ctx).apply {
                        setBackgroundColor(android.graphics.Color.BLACK)
                        (customView.parent as? ViewGroup)?.removeView(customView)
                        addView(customView, FrameLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                        ))
                    }
                },
                modifier = Modifier.fillMaxSize()
            )
        }

        if (currentTab.url != "about:home" && isTranslationEnabled) {
            SubtitleOverlay(
                activeCue = activeCue,
                style = subtitleStyle,
                onDragVerticalBias = { newBias ->
                    viewModel.updateSubtitleStyle { it.copy(verticalPositionBias = newBias) }
                },
                onLongPressCue = { cue ->
                    webViewRef?.evaluateJavascript("window.__watchTranslatePause && window.__watchTranslatePause();", null)
                    viewModel.requestExplainSubtitle(cue)
                }
            )
        }

        if (currentTab.url != "about:home") {
            FloatingTranslationControls(
                isEnabled = isTranslationEnabled,
                isPaused = isTranslationPaused,
                status = engineStatus,
                errorDetail = lastErrorDetail,
                activeEngineInfo = activeEngineInfo,
                audioLevel = audioLevel,
                videoDetected = videoState.detected,
                currentStyle = translationStyle,
                sourceLanguage = sourceLanguage,
                subtitleStyle = subtitleStyle,
                hasActiveCue = activeCue != null,
                onStart = startTranslationFlow,
                onPauseToggle = { viewModel.togglePauseTranslation() },
                onStop = { viewModel.stopTranslation() },
                onStyleSelected = { viewModel.setTranslationStyle(it) },
                onSourceLanguageSelected = { viewModel.setSourceLanguage(it) },
                onUpdateSubtitleStyle = { viewModel.updateSubtitleStyle(it) },
                onResetSync = { viewModel.resetSynchronization() },
                onLoadLocalSubtitle = { localSubtitlePicker.launch(arrayOf("*/*")) },
                onExplainCurrent = {
                    activeCue?.let { cue ->
                        webViewRef?.evaluateJavascript("window.__watchTranslatePause && window.__watchTranslatePause();", null)
                        viewModel.requestExplainSubtitle(cue)
                    }
                }
            )
        }

        AiExplanationBottomSheet(
            isLoading = explanationLoading,
            explanation = currentExplanation,
            onDismiss = {
                viewModel.dismissExplanation()
                webViewRef?.evaluateJavascript("window.__watchTranslatePlay && window.__watchTranslatePlay();", null)
            }
        )

        if (showSettingsDialog) {
            SettingsDialog(
                viewModel = viewModel,
                currentMode = translationMode,
                currentSourceLang = sourceLanguage,
                adBlockerEnabled = adBlockerEnabled,
                onDismiss = { showSettingsDialog = false }
            )
        }

        if (showTabsDialog) {
            TabsDialog(
                tabs = tabs,
                onSelect = { viewModel.selectTab(it); showTabsDialog = false },
                onClose = { viewModel.closeTab(it) },
                onNewTab = { isPriv -> viewModel.addNewTab(isPriv); showTabsDialog = false },
                onDismiss = { showTabsDialog = false }
            )
        }

        if (showHistoryDialog) {
            SimpleListDialog(
                title = "سجل التصفح",
                items = history.map { it.title to it.url },
                onItemClick = { url -> viewModel.navigateTo(url); showHistoryDialog = false },
                onClear = { viewModel.clearAllBrowsingData() },
                onDismiss = { showHistoryDialog = false }
            )
        }

        if (showTranslationHistoryDialog) {
            SimpleListDialog(
                title = "سجل الترجمة",
                items = translationHistory.map { "${it.translatedSnippet}\n(${it.sourceSnippet})" to it.pageUrl },
                onItemClick = { url -> if (url.startsWith("http")) viewModel.navigateTo(url); showTranslationHistoryDialog = false },
                onClear = { viewModel.clearAllBrowsingData() },
                onDismiss = { showTranslationHistoryDialog = false }
            )
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun IntegratedBrowserWebView(
    url: String,
    isPrivate: Boolean,
    isDesktopMode: Boolean,
    viewModel: MainViewModel,
    onWebViewReady: (WebView) -> Unit,
    onEnterFullscreen: (View, WebChromeClient.CustomViewCallback) -> Unit,
    onExitFullscreen: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val bridgeScript = remember {
        context.assets.open("video_bridge.js").bufferedReader().use { it.readText() }
    }
    var lastRequestedUrl by remember { mutableStateOf("") }

    AndroidView(
        factory = { ctx ->
            WebView(ctx).apply {
                settings.apply {
                    javaScriptEnabled = true
                    domStorageEnabled = !isPrivate
                    mediaPlaybackRequiresUserGesture = false
                    allowFileAccess = false
                    setSupportMultipleWindows(true)
                    javaScriptCanOpenWindowsAutomatically = false
                    builtInZoomControls = true
                    displayZoomControls = false
                    useWideViewPort = true
                    loadWithOverviewMode = true
                    mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                }
                CookieManager.getInstance().setAcceptThirdPartyCookies(this, !isPrivate)

                addJavascriptInterface(object {
                    @JavascriptInterface
                    fun onJsEvent(type: String, payload: String) {
                        viewModel.onJsBridgeEvent(type, payload)
                    }
                }, "WatchTranslateBridge")

                webViewClient = object : WebViewClient() {
                    override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest): WebResourceResponse? {
                        val reqUrl = request.url.toString()
                        val pageUrl = viewModel.currentTab.value.url
                        if (viewModel.adBlocker.shouldBlockRequest(reqUrl, pageUrl)) {
                            return viewModel.adBlocker.emptyBlockedResponse()
                        }

                        val lower = reqUrl.lowercase()
                        if (lower.contains(".vtt") || lower.contains(".srt") ||
                            lower.contains("/api/timedtext") || lower.contains("timedtext?")
                        ) {
                            val referer = request.requestHeaders["Referer"] ?: pageUrl
                            val ua = request.requestHeaders["User-Agent"]
                            viewModel.onSubtitleUrlIntercepted(reqUrl, referer, ua)
                        }

                        return super.shouldInterceptRequest(view, request)
                    }

                    override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest): Boolean {
                        val target = request.url.toString()
                        val pageUrl = viewModel.currentTab.value.url
                        if (viewModel.adBlocker.shouldBlockPopupOrRedirect(target, pageUrl, request.hasGesture())) {
                            return true
                        }
                        return false
                    }

                    override fun onPageCommitVisible(view: WebView?, url: String?) {
                        super.onPageCommitVisible(view, url)
                        if (viewModel.adBlocker.isEnabled.value && !viewModel.adBlocker.isSiteWhitelisted(url)) {
                            view?.evaluateJavascript(viewModel.adBlocker.cosmeticHideCssJs, null)
                        }
                    }

                    override fun onPageFinished(view: WebView?, loadedUrl: String?) {
                        super.onPageFinished(view, loadedUrl)
                        if (loadedUrl != null) {
                            lastRequestedUrl = loadedUrl
                            viewModel.onPageMetadataUpdated(loadedUrl, view?.title.orEmpty())
                        }
                        view?.evaluateJavascript(bridgeScript, null)
                        if (viewModel.adBlocker.isEnabled.value && !viewModel.adBlocker.isSiteWhitelisted(loadedUrl)) {
                            view?.evaluateJavascript(viewModel.adBlocker.cosmeticHideCssJs, null)
                        }
                    }
                }

                webChromeClient = object : WebChromeClient() {
                    override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
                        if (view != null && callback != null) onEnterFullscreen(view, callback)
                    }

                    override fun onHideCustomView() {
                        onExitFullscreen()
                    }

                    override fun onCreateWindow(
                        view: WebView?, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message?
                    ): Boolean {
                        if (!isUserGesture && viewModel.adBlocker.isEnabled.value) return false
                        val hitUrl = view?.hitTestResult?.extra ?: return false
                        if (viewModel.adBlocker.shouldBlockPopupOrRedirect(hitUrl, view.url, isUserGesture)) {
                            return false
                        }
                        view.loadUrl(hitUrl)
                        return false
                    }
                }

                onWebViewReady(this)
                lastRequestedUrl = url
                loadUrl(url)
            }
        },
        update = { wv ->
            val desktopUa = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36"
            wv.settings.userAgentString = if (isDesktopMode) desktopUa else null
            if (url != lastRequestedUrl && url.startsWith("http")) {
                lastRequestedUrl = url
                wv.loadUrl(url)
            }
        },
        modifier = modifier
    )
}

@Composable
private fun BrowserTopBar(
    currentUrl: String,
    isPrivate: Boolean,
    isDesktopMode: Boolean,
    isBookmarked: Boolean,
    isWhitelisted: Boolean,
    tabCount: Int,
    onSubmitUrl: (String) -> Unit,
    onBack: () -> Unit,
    onForward: () -> Unit,
    onRefresh: () -> Unit,
    onHome: () -> Unit,
    onToggleBookmark: () -> Unit,
    onToggleDesktop: () -> Unit,
    onToggleWhitelist: () -> Unit,
    onOpenTabs: () -> Unit,
    onOpenHistory: () -> Unit,
    onOpenSettings: () -> Unit
) {
    var input by remember(currentUrl) { mutableStateOf(currentUrl) }
    var menuExpanded by remember { mutableStateOf(false) }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(CharcoalSurface)
            .statusBarsPadding()
            .padding(horizontal = 8.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        IconButton(onClick = onHome, modifier = Modifier.size(34.dp)) {
            Icon(Icons.Rounded.Home, null, tint = if (isPrivate) ElectricPurple else SoftWhite)
        }
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = ElevatedCharcoal,
            modifier = Modifier.weight(1f).height(40.dp)
        ) {
            Box(
                contentAlignment = Alignment.CenterStart,
                modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp)
            ) {
                BasicTextField(
                    value = input,
                    onValueChange = { input = it },
                    singleLine = true,
                    textStyle = TextStyle(color = SoftWhite, fontSize = 13.sp),
                    cursorBrush = SolidColor(ElectricPurple),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                    keyboardActions = KeyboardActions(onGo = { onSubmitUrl(input) }),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
        TextButton(onClick = onOpenTabs, contentPadding = PaddingValues(0.dp), modifier = Modifier.size(36.dp)) {
            Text("$tabCount", color = SoftWhite)
        }
        Box {
            IconButton(onClick = { menuExpanded = true }, modifier = Modifier.size(34.dp)) {
                Icon(Icons.Rounded.MoreVert, null, tint = SoftWhite)
            }
            DropdownMenu(expanded = menuExpanded, onDismissRequest = { menuExpanded = false }) {
                DropdownMenuItem(text = { Text("رجوع") }, onClick = { menuExpanded = false; onBack() })
                DropdownMenuItem(text = { Text("تقدم") }, onClick = { menuExpanded = false; onForward() })
                DropdownMenuItem(text = { Text("تحديث") }, onClick = { menuExpanded = false; onRefresh() })
                DropdownMenuItem(
                    text = { Text(if (isBookmarked) "إزالة من المفضلة" else "حفظ في المفضلة") },
                    onClick = { menuExpanded = false; onToggleBookmark() }
                )
                DropdownMenuItem(
                    text = { Text(if (isDesktopMode) "وضع الموبايل" else "وضع الكمبيوتر") },
                    onClick = { menuExpanded = false; onToggleDesktop() }
                )
                DropdownMenuItem(
                    text = { Text(if (isWhitelisted) "تفعيل مانع الإعلانات هنا" else "إيقاف مانع الإعلانات هنا") },
                    onClick = { menuExpanded = false; onToggleWhitelist() }
                )
                DropdownMenuItem(text = { Text("السجل") }, onClick = { menuExpanded = false; onOpenHistory() })
                DropdownMenuItem(text = { Text("الإعدادات والمفاتيح (v10 Pro)") }, onClick = { menuExpanded = false; onOpenSettings() })
            }
        }
    }
}
