(function() {
  if (window.__watchTranslateInjected) return;
  window.__watchTranslateInjected = true;

  let activeVideo = null;
  let lastReportedTime = -1;
  let attachedTracks = new WeakSet();
  let seenSubtitleUrls = new Set();

  function postEvent(type, payload) {
    try {
      if (window.WatchTranslateBridge) {
        window.WatchTranslateBridge.onJsEvent(type, JSON.stringify(payload));
      }
    } catch (e) {}
  }

  function collectVideos(root, list) {
    if (!root) return;
    try {
      const vids = root.querySelectorAll ? root.querySelectorAll('video') : [];
      for (let i = 0; i < vids.length; i++) list.push(vids[i]);

      const all = root.querySelectorAll ? root.querySelectorAll('*') : [];
      for (let i = 0; i < all.length; i++) {
        if (all[i].shadowRoot) collectVideos(all[i].shadowRoot, list);
      }

      const frames = root.querySelectorAll ? root.querySelectorAll('iframe') : [];
      for (let i = 0; i < frames.length; i++) {
        try {
          const doc = frames[i].contentDocument || (frames[i].contentWindow && frames[i].contentWindow.document);
          if (doc) collectVideos(doc, list);
        } catch (e) {}
      }
    } catch (e) {}
  }

  function findPrimaryVideo() {
    const videos = [];
    collectVideos(document, videos);
    if (videos.length === 0) return null;
    const playing = videos.find(v => !v.paused && !v.ended && v.readyState > 1);
    if (playing) return playing;
    return videos.sort((a, b) => (b.clientWidth * b.clientHeight) - (a.clientWidth * a.clientHeight))[0];
  }

  function extractTextTracks(video) {
    if (!video || !video.textTracks) return false;
    let found = false;
    for (let i = 0; i < video.textTracks.length; i++) {
      const track = video.textTracks[i];
      if (track.kind === 'subtitles' || track.kind === 'captions' || track.kind === '') {
        found = true;
        if (track.mode === 'disabled') {
          track.mode = 'hidden';
        }
        if (!attachedTracks.has(track)) {
          attachedTracks.add(track);
          const emitCues = () => {
            if (!track.cues || track.cues.length === 0) return;
            const cues = [];
            for (let j = 0; j < track.cues.length; j++) {
              const c = track.cues[j];
              const cleanText = (c.text || '').replace(/<[^>]*>/g, '').trim();
              if (cleanText) {
                cues.push({
                  startMs: Math.round(c.startTime * 1000),
                  endMs: Math.round(c.endTime * 1000),
                  text: cleanText
                });
              }
            }
            if (cues.length > 0) {
              postEvent('TRACK_CUES', { language: track.language || 'auto', cues: cues });
            }
          };
          track.addEventListener('cuechange', () => {
            if (track.activeCues && track.activeCues.length > 0) {
              const active = Array.from(track.activeCues).map(c => ({
                startMs: Math.round(c.startTime * 1000),
                endMs: Math.round(c.endTime * 1000),
                text: (c.text || '').replace(/<[^>]*>/g, '').trim()
              })).filter(c => c.text.length > 0);
              if (active.length > 0) {
                postEvent('ACTIVE_CUES', { cues: active });
              }
            }
          });
          setTimeout(emitCues, 500);
          setTimeout(emitCues, 1800);
        }
      }
    }
    try {
      const trackEls = video.querySelectorAll('track[src]');
      trackEls.forEach(t => {
        const src = t.src;
        if (src && !seenSubtitleUrls.has(src)) {
          seenSubtitleUrls.add(src);
          found = true;
          fetch(src).then(r => r.text()).then(body => {
            if (body && body.length > 10) {
              postEvent('RAW_SUBTITLE_FILE', { url: src, content: body });
            }
          }).catch(() => {});
        }
      });
    } catch (e) {}
    return found;
  }

  function bindVideo(video) {
    if (!video || video === activeVideo) return;
    activeVideo = video;

    const sendState = (eventName) => {
      if (!activeVideo) return;
      const hasTracks = extractTextTracks(activeVideo);
      postEvent(eventName, {
        detected: true,
        isPlaying: !activeVideo.paused && !activeVideo.ended,
        currentTimeMs: Math.round((activeVideo.currentTime || 0) * 1000),
        durationMs: Math.round((activeVideo.duration || 0) * 1000),
        playbackRate: activeVideo.playbackRate || 1.0,
        hasAccessibleCaptions: hasTracks,
        pageTitle: document.title || '',
        pageUrl: location.href
      });
    };

    ['play', 'pause', 'ratechange', 'loadedmetadata', 'playing'].forEach(ev => {
      video.addEventListener(ev, () => sendState('VIDEO_STATE'), { passive: true });
    });
    video.addEventListener('seeking', () => sendState('VIDEO_SEEKING'), { passive: true });
    video.addEventListener('seeked', () => sendState('VIDEO_SEEKED'), { passive: true });

    sendState('VIDEO_STATE');
  }

  function isSubtitleResponse(url, contentType) {
    const u = (url || '').toLowerCase();
    const ct = (contentType || '').toLowerCase();
    return /\.(vtt|srt)(\?|$|#)/i.test(u) ||
      u.includes('/api/timedtext') ||
      u.includes('timedtext?') ||
      ct.includes('text/vtt') ||
      ct.includes('application/x-subrip');
  }

  const origFetch = window.fetch;
  if (origFetch) {
    window.fetch = async function(...args) {
      const response = await origFetch.apply(this, args);
      try {
        const url = typeof args[0] === 'string' ? args[0] : (args[0] && args[0].url) || '';
        const ct = response.headers ? (response.headers.get('content-type') || '') : '';
        if (isSubtitleResponse(url, ct)) {
          response.clone().text().then(body => {
            if (body && body.length > 10) {
              postEvent('RAW_SUBTITLE_FILE', { url: url, content: body });
            }
          }).catch(() => {});
        }
      } catch (e) {}
      return response;
    };
  }

  const origXhrOpen = XMLHttpRequest.prototype.open;
  const origXhrSend = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function(method, url) {
    this.__wtUrl = typeof url === 'string' ? url : '';
    return origXhrOpen.apply(this, arguments);
  };
  XMLHttpRequest.prototype.send = function() {
    this.addEventListener('load', function() {
      try {
        const url = this.__wtUrl || this.responseURL || '';
        const ct = this.getResponseHeader ? (this.getResponseHeader('content-type') || '') : '';
        if (isSubtitleResponse(url, ct) && typeof this.responseText === 'string' && this.responseText.length > 10) {
          postEvent('RAW_SUBTITLE_FILE', { url: url, content: this.responseText });
        }
      } catch (e) {}
    });
    return origXhrSend.apply(this, arguments);
  };

  setInterval(() => {
    const candidate = findPrimaryVideo();
    if (candidate && candidate !== activeVideo) {
      bindVideo(candidate);
    }
    if (activeVideo) {
      const nowMs = Math.round((activeVideo.currentTime || 0) * 1000);
      if (Math.abs(nowMs - lastReportedTime) >= 60 || !activeVideo.paused) {
        lastReportedTime = nowMs;
        postEvent('TIME_TICK', {
          isPlaying: !activeVideo.paused && !activeVideo.ended,
          currentTimeMs: nowMs,
          playbackRate: activeVideo.playbackRate || 1.0,
          hasAccessibleCaptions: extractTextTracks(activeVideo)
        });
      }
    }
  }, 100);

  window.__watchTranslatePause = () => { if (activeVideo && !activeVideo.paused) activeVideo.pause(); };
  window.__watchTranslatePlay = () => { if (activeVideo && activeVideo.paused) activeVideo.play(); };
})();
